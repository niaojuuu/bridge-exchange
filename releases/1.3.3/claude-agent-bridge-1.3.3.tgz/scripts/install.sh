#!/bin/bash
# Install claude-agent-bridge as a per-user service (DESIGN §10.2/§10.3):
#   macOS : LaunchAgent  ~/Library/LaunchAgents/com.yxfsoft.claude-agent-bridge.plist (from launchd/)
#   Linux : systemd unit ~/.config/systemd/user/claude-agent-bridge.service (from systemd/)
#           without systemd (e.g. a container) the service is just started in the background
# Both: checks the software it needs (offers to install what is missing), builds if needed,
# links bin/claude-agent onto PATH, prints the web console login link.
# Linux: also builds sshfs 3.7.6 into vendor/sshfs (remote directories; checksum-pinned source).
#
#   scripts/install.sh                   check dependencies (ask before installing missing ones), install
#   scripts/install.sh --check           only check dependencies, change nothing (exit 1 if a required one is missing)
#   scripts/install.sh --install-deps    install missing packages without asking (sudo + the system package manager)
#   scripts/install.sh --check --install-deps   only install missing packages, leave the service alone
#   scripts/install.sh --no-install-deps never install packages, only report them
#   scripts/install.sh --no-sshfs        do not build sshfs (remote directories stay unavailable)
#   SSHFS_TARBALL=/path/sshfs-3.7.6.tar.xz scripts/install.sh   build from a local copy (offline server)
set -euo pipefail

LABEL="com.yxfsoft.claude-agent-bridge"
UNIT="claude-agent-bridge.service"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
USER_NAME="$(id -un)"
UID_NUM="$(id -u)"
HOME_DIR="${HOME:-$(eval echo "~$USER_NAME")}"
PORT="${BRIDGE_PORT:-7788}"
OS="$(uname -s)"

say() { printf '\033[1;34m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33mwarning:\033[0m %s\n' "$*" >&2; }
die() { printf '\033[1;31merror:\033[0m %s\n' "$*" >&2; exit 1; }

INSTALL_DEPS=ask
CHECK_ONLY=0
NO_SSHFS=0
for arg in "$@"; do
  case "$arg" in
    --install-deps) INSTALL_DEPS=yes ;;
    --no-install-deps) INSTALL_DEPS=no ;;
    --check) CHECK_ONLY=1 ;;
    --no-sshfs) NO_SSHFS=1 ;;
    -h|--help) awk 'NR > 1 && /^#/ { sub(/^# ?/, ""); print; next } NR > 1 { exit }' "$0"; exit 0 ;;
    *) die "unknown option: $arg (see --help)" ;;
  esac
done

case "$OS" in
  Darwin)
    LOG_DIR="$HOME_DIR/Library/Logs/claude-agent-bridge"
    DATA_DIR="$HOME_DIR/Library/Application Support/claude-agent-bridge"
    ;;
  Linux)
    DATA_DIR="$HOME_DIR/.claude-agent-bridge"
    LOG_DIR="$DATA_DIR/logs"
    ;;
  *) die "unsupported OS $OS; run: node dist/cli.js serve" ;;
esac

# ---- dependencies ------------------------------------------------------------------
# required    : the service (or this script) does not work without it
# recommended : one feature is missing without it (named next to it); the install goes on
# optional    : only for a side task
PM=""
for pm in apt-get dnf yum zypper apk pacman brew; do
  if command -v "$pm" >/dev/null 2>&1; then PM="$pm"; break; fi
done

# Tool → package name(s) for this package manager.
pkg_for() {
  case "$1:$PM" in
    bwrap:*) echo bubblewrap ;;
    ps:dnf | ps:yum | ps:pacman) echo procps-ng ;;
    ps:*) echo procps ;;
    fusermount3:*) echo fuse3 ;;
    sshfs-build:apt-get) echo "build-essential meson ninja-build pkg-config libfuse3-dev libglib2.0-dev xz-utils" ;;
    sshfs-build:dnf | sshfs-build:yum) echo "gcc meson ninja-build pkgconf-pkg-config fuse3-devel glib2-devel xz" ;;
    sshfs-build:zypper) echo "gcc meson ninja pkgconf fuse3-devel glib2-devel xz" ;;
    sshfs-build:apk) echo "build-base meson ninja pkgconf fuse3-dev glib-dev xz" ;;
    sshfs-build:pacman) echo "base-devel meson ninja fuse3 glib2 xz" ;;
    *) echo "$1" ;;
  esac
}

# ---- sshfs for remote directories (Linux) ---------------------------------------------
# 3.7.6 fixed CVE-2026-47187: a rogue SFTP server (here: whatever a user connects) could make
# programs on this machine read / write local files through symlinks. Distributions still ship
# older versions, so it is built from the release tarball, checked against this checksum.
SSHFS_VERSION=3.7.6
SSHFS_SHA256=6a1bcb31450a077e9cb1b7ff158c71de34db697c3c0da6cb362502131e495893
SSHFS_URL="https://github.com/libfuse/sshfs/releases/download/sshfs-$SSHFS_VERSION/sshfs-$SSHFS_VERSION.tar.xz"
SSHFS_BIN="$ROOT/vendor/sshfs/bin/sshfs"

sshfs_ok() { [[ -x "$SSHFS_BIN" ]] && "$SSHFS_BIN" --version 2>&1 | grep -q "SSHFS version $SSHFS_VERSION"; }

sshfs_build_missing() {
  local m=() t
  for t in cc meson ninja pkg-config xz; do command -v "$t" >/dev/null 2>&1 || m+=("$t"); done
  if command -v pkg-config >/dev/null 2>&1; then
    pkg-config --exists fuse3 || m+=(libfuse3-dev)
    pkg-config --exists glib-2.0 || m+=(glib2-dev)
  fi
  echo "${m[*]+"${m[*]}"}"
}

sha256_of() {
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | awk '{print $1}'; else shasum -a 256 "$1" | awk '{print $1}'; fi
}

build_sshfs() {
  sshfs_ok && return 0
  local missing tmp tarball sum
  missing="$(sshfs_build_missing)"
  if [[ -n "$missing" ]]; then warn "cannot build sshfs $SSHFS_VERSION: missing $missing"; return 1; fi
  tmp="$(mktemp -d)"
  tarball="${SSHFS_TARBALL:-}"
  [[ -z "$tarball" && -f "$ROOT/vendor/sshfs-$SSHFS_VERSION.tar.xz" ]] && tarball="$ROOT/vendor/sshfs-$SSHFS_VERSION.tar.xz"
  if [[ -z "$tarball" ]]; then
    say "downloading $SSHFS_URL"
    if ! curl -fsSL "$SSHFS_URL" -o "$tmp/sshfs.tar.xz"; then
      warn "download failed (offline? put the tarball at vendor/sshfs-$SSHFS_VERSION.tar.xz or set SSHFS_TARBALL)"
      rm -rf "$tmp"; return 1
    fi
    tarball="$tmp/sshfs.tar.xz"
  fi
  sum="$(sha256_of "$tarball")"
  if [[ "$sum" != "$SSHFS_SHA256" ]]; then warn "sshfs tarball $tarball has checksum $sum, expected $SSHFS_SHA256"; rm -rf "$tmp"; return 1; fi
  say "building sshfs $SSHFS_VERSION into vendor/sshfs (meson + ninja)"
  if ! tar -xJf "$tarball" -C "$tmp" \
    || ! (cd "$tmp/sshfs-$SSHFS_VERSION" && meson setup build --buildtype=release -Db_pie=true >"$tmp/meson.log" 2>&1 && ninja -C build >"$tmp/ninja.log" 2>&1); then
    warn "sshfs build failed; logs: $tmp/meson.log $tmp/ninja.log"
    return 1
  fi
  mkdir -p "$ROOT/vendor/sshfs/bin"
  install -m 0755 "$tmp/sshfs-$SSHFS_VERSION/build/sshfs" "$SSHFS_BIN"
  rm -rf "$tmp"
  sshfs_ok && say "built $SSHFS_BIN"
}

install_cmd() {
  local sudo=""
  if [[ "$(id -u)" -ne 0 && "$PM" != brew ]]; then sudo="sudo "; fi
  case "$PM" in
    apt-get) echo "${sudo}apt-get update && ${sudo}apt-get install -y $*" ;;
    dnf | yum) echo "${sudo}$PM install -y $*" ;;
    zypper) echo "${sudo}zypper install -y $*" ;;
    apk) echo "${sudo}apk add $*" ;;
    pacman) echo "${sudo}pacman -S --needed --noconfirm $*" ;;
    brew) echo "brew install $*" ;;
    *) echo "" ;;
  esac
}

node_hint() {
  if [[ "$OS" == Darwin ]]; then
    echo "install Node 24+: brew install node@24 (then follow brew's PATH note), or nvm (https://github.com/nvm-sh/nvm): nvm install 24"
  else
    echo "install Node 24+ with nvm (https://github.com/nvm-sh/nvm): nvm install 24 — or from https://nodejs.org/ (distribution packages are often older than 24)"
  fi
}

MISSING_REQ=()
MISSING_REC=()
NODE=""
row() { printf '  %-9s %-11s %s\n' "$1" "$2" "$3"; }

check_deps() {
  MISSING_REQ=()
  MISSING_REC=()
  say "checking required software"
  NODE="$(command -v node || true)"
  if [[ -z "$NODE" ]]; then
    row MISSING node "required: runs the service — $(node_hint)"
    MISSING_REQ+=(node)
  else
    local major
    major="$("$NODE" -p 'process.versions.node.split(".")[0]')"
    if (( major >= 24 )); then row ok node "$("$NODE" --version) (>= 24, uses the built-in node:sqlite)"
    else row TOO-OLD node "$("$NODE" --version); required >= 24 — $(node_hint)"; MISSING_REQ+=(node); fi
  fi
  if command -v npm >/dev/null 2>&1; then row ok npm "$(npm --version) (installs dependencies, builds)"
  else row MISSING npm "required: comes with Node — $(node_hint)"; MISSING_REQ+=(npm); fi

  local t why
  for t in git curl; do
    case "$t" in
      git) why="session diffs and working-tree snapshots" ;;
      curl) why="this script waits for the service with it" ;;
    esac
    if command -v "$t" >/dev/null 2>&1; then row ok "$t" "$why"
    else row MISSING "$t" "required: $why"; MISSING_REQ+=("$t"); fi
  done

  if command -v ps >/dev/null 2>&1; then row ok ps "spots Claude sessions still open in a terminal before taking them over"
  else row MISSING ps "recommended: without it a session still open in a terminal is not detected before taking it over"; MISSING_REC+=(ps); fi

  if [[ "$OS" == Linux ]]; then
    # Multi-user: users' Claude Code sessions run in Claude Code's sandbox = bubblewrap + socat on Linux.
    local sbx="multi-user sandbox (users' Claude sessions refuse to start without it; the admin alone does not need it)"
    if command -v bwrap >/dev/null 2>&1; then
      if bwrap --ro-bind / / --dev /dev --unshare-all --die-with-parent true >/dev/null 2>&1; then
        row ok bwrap "$sbx"
      else
        row BROKEN bwrap "installed but cannot create a sandbox here: unprivileged user namespaces are blocked (Ubuntu 23.10+: sudo sysctl -w kernel.apparmor_restrict_unprivileged_userns=0, and add it to /etc/sysctl.d/ to keep it; in Docker allow user namespaces / unconfined seccomp)"
        MISSING_REC+=("bwrap(blocked)")
      fi
    else
      row MISSING bwrap "recommended: $sbx"
      MISSING_REC+=(bwrap)
    fi
    if command -v socat >/dev/null 2>&1; then row ok socat "network proxy of that sandbox"
    else row MISSING socat "recommended: network proxy of the $sbx"; MISSING_REC+=(socat); fi

    # Remote directories: FUSE (fusermount3, /dev/fuse) + sshfs >= 3.7.6, built into vendor/ below.
    local rd="remote directories (folders on users' computers)"
    if command -v fusermount3 >/dev/null 2>&1 || [[ -x /usr/bin/fusermount3 || -x /bin/fusermount3 ]]; then row ok fusermount3 "$rd"
    else row MISSING fusermount3 "recommended: $rd need FUSE (package fuse3)"; MISSING_REC+=(fusermount3); fi
    if [[ ! -e /dev/fuse ]]; then row MISSING /dev/fuse "recommended: $rd — this kernel / container has no FUSE device"; fi
    if (( NO_SSHFS )); then row skipped sshfs "--no-sshfs: $rd stay unavailable"
    elif sshfs_ok; then row ok sshfs "$SSHFS_VERSION in vendor/sshfs, for $rd"
    elif [[ -z "$(sshfs_build_missing)" ]]; then row build sshfs "$SSHFS_VERSION will be built into vendor/sshfs, for $rd"
    else row MISSING sshfs-build "recommended: to build sshfs $SSHFS_VERSION for $rd: $(sshfs_build_missing)"; MISSING_REC+=(sshfs-build); fi
  else
    if [[ -x /usr/bin/sandbox-exec ]]; then row ok sandbox-exec "multi-user sandbox (built into macOS)"
    else row MISSING sandbox-exec "multi-user sandbox: /usr/bin/sandbox-exec is part of macOS; users' sessions will refuse to start"; fi
    row n/a sshfs "remote directories need a Linux server"
  fi

  if command -v claude >/dev/null 2>&1; then row ok claude "$(claude --version 2>/dev/null | head -1) (optional: \`claude setup-token\`)"
  else row optional claude "only to run \`claude setup-token\` here; any machine with a browser will do (npm install -g @anthropic-ai/claude-code)"; fi
}

check_deps

# Packages a package manager can install (Node is left to nvm / nodejs.org: distro packages lag behind).
PKGS=()
# (${a[@]+"${a[@]}"}: an empty array under set -u is an error in macOS's bash 3.2)
for t in ${MISSING_REQ[@]+"${MISSING_REQ[@]}"} ${MISSING_REC[@]+"${MISSING_REC[@]}"}; do
  case "$t" in node | npm | "bwrap(blocked)") ;; *) PKGS+=("$(pkg_for "$t")") ;; esac
done
if (( ${#PKGS[@]} )); then
  if [[ "$OS" == Darwin && " ${PKGS[*]} " == *" git "* && "$PM" != brew ]]; then
    warn "git is missing: run xcode-select --install (or install Homebrew, then brew install git)"
  fi
  CMD="$(install_cmd "${PKGS[@]}")"
  if [[ -z "$CMD" ]]; then
    warn "missing: ${PKGS[*]} — install them with your system's package manager"
  else
    DO=no
    if [[ "$INSTALL_DEPS" == yes ]]; then
      DO=yes
    elif [[ "$INSTALL_DEPS" == ask && "$CHECK_ONLY" -eq 0 && -t 0 ]]; then
      read -r -p "Install the missing packages now? ($CMD) [y/N] " ans || ans=""
      [[ "$ans" =~ ^[Yy] ]] && DO=yes
    fi
    if [[ "$DO" == yes ]]; then
      say "$CMD"
      bash -c "$CMD" || warn "package installation failed"
      check_deps
    else
      say "to install the missing packages: $CMD   (or re-run: scripts/install.sh --install-deps)"
    fi
  fi
fi

if [[ "$OS" == Linux ]] && (( ! NO_SSHFS )) && { (( ! CHECK_ONLY )) || [[ "$INSTALL_DEPS" == yes ]]; }; then
  if ! build_sshfs; then
    warn "remote directories stay unavailable until sshfs $SSHFS_VERSION is built (re-run scripts/install.sh)"
  elif (( CHECK_ONLY )); then
    say "sshfs is ready; restart the service so it picks it up"
  fi
fi

if (( CHECK_ONLY )); then
  if (( ${#MISSING_REQ[@]} )); then die "required software missing: ${MISSING_REQ[*]}"; fi
  (( ${#MISSING_REC[@]} )) && warn "recommended software missing: ${MISSING_REC[*]} (see above for what does not work without it)"
  say "check only: the service was not installed or touched"
  exit 0
fi
(( ${#MISSING_REQ[@]} )) && die "required software missing: ${MISSING_REQ[*]} (see above for how to install it)"
(( ${#MISSING_REC[@]} )) && warn "continuing without: ${MISSING_REC[*]} (see above for what does not work without it)"

if [[ ! -d "$ROOT/node_modules" || ! -f "$ROOT/dist/cli.js" ]]; then
  say "building (npm ci && npm run build)"
  (cd "$ROOT" && npm ci && npm run build)
fi

say "creating data/log dirs"
mkdir -p "$DATA_DIR" "$LOG_DIR"
chmod 700 "$DATA_DIR"
# Pre-create the 0600 env file so later appends/edits never inherit a 0644 umask.
if [[ ! -f "$DATA_DIR/env" ]]; then
  ( umask 077; printf '# claude-agent-bridge subprocess env (0600). Managed by `claude-agent auth set-token`.\n' > "$DATA_DIR/env" )
fi
for f in "$DATA_DIR/env" "$DATA_DIR/token" "$DATA_DIR/config.json"; do
  [[ -f "$f" ]] && chmod 600 "$f"
done
chmod +x "$ROOT/scripts/serve.sh" "$ROOT/bin/claude-agent"

# ---- CLI symlink -----------------------------------------------------------------
BIN_DIR=""
for d in /opt/homebrew/bin /usr/local/bin; do
  if [[ -d "$d" && -w "$d" ]]; then BIN_DIR="$d"; break; fi
done
if [[ -z "$BIN_DIR" && "$OS" == "Linux" ]]; then
  BIN_DIR="$HOME_DIR/.local/bin"
  mkdir -p "$BIN_DIR"
fi
if [[ -n "$BIN_DIR" ]]; then
  ln -sfn "$ROOT/bin/claude-agent" "$BIN_DIR/claude-agent"
  say "linked $BIN_DIR/claude-agent -> $ROOT/bin/claude-agent"
  case ":$PATH:" in *":$BIN_DIR:"*) ;; *) say "note: $BIN_DIR is not on PATH; add: export PATH=\"$BIN_DIR:\$PATH\"" ;; esac
else
  say "no writable /opt/homebrew/bin or /usr/local/bin; add to PATH: export PATH=\"$ROOT/bin:\$PATH\""
fi

wait_health() {
  say "waiting for http://127.0.0.1:$PORT/health"
  for _ in $(seq 1 40); do
    if curl -fs "http://127.0.0.1:$PORT/health" >/dev/null 2>&1; then return 0; fi
    sleep 0.5
  done
  echo "service did not come up; check $LOG_DIR/serve.err.log" >&2
  tail -n 30 "$LOG_DIR/serve.err.log" 2>/dev/null || true
  exit 1
}

MANAGE=""
if [[ "$OS" == "Darwin" ]]; then
  # ---- launchd --------------------------------------------------------------------
  PLIST_DST="$HOME_DIR/Library/LaunchAgents/$LABEL.plist"
  mkdir -p "$HOME_DIR/Library/LaunchAgents"
  say "writing $PLIST_DST"
  sed \
    -e "s#/Users/moby/src/claude-agent-bridge#$ROOT#g" \
    -e "s#/Users/moby/Library/Logs/claude-agent-bridge#$LOG_DIR#g" \
    -e "s#<string>/Users/moby</string>#<string>$HOME_DIR</string>#g" \
    -e "s#<key>BRIDGE_PORT</key><string>7788</string>#<key>BRIDGE_PORT</key><string>$PORT</string>#g" \
    "$ROOT/launchd/$LABEL.plist" > "$PLIST_DST"
  plutil -lint "$PLIST_DST" >/dev/null
  if launchctl print "gui/$UID_NUM/$LABEL" >/dev/null 2>&1; then
    say "agent already loaded; bootout + bootstrap to pick up changes"
    launchctl bootout "gui/$UID_NUM/$LABEL" 2>/dev/null || true
    sleep 1
  fi
  say "launchctl bootstrap gui/$UID_NUM $PLIST_DST"
  launchctl bootstrap "gui/$UID_NUM" "$PLIST_DST"
  launchctl kickstart -k "gui/$UID_NUM/$LABEL"
  wait_health
  MANAGE="  restart : launchctl kickstart -k gui/$UID_NUM/$LABEL
  stop    : launchctl bootout gui/$UID_NUM/$LABEL"
elif [[ -d /run/systemd/system ]]; then
  # ---- systemd --user -------------------------------------------------------------
  UNIT_DIR="${XDG_CONFIG_HOME:-$HOME_DIR/.config}/systemd/user"
  mkdir -p "$UNIT_DIR"
  # The unit's PATH must find this node (nvm / fnm installs live outside /usr/bin).
  UNIT_PATH="$(dirname "$NODE"):$HOME_DIR/.local/bin:/usr/local/bin:/usr/bin:/bin"
  say "writing $UNIT_DIR/$UNIT"
  sed \
    -e "s#@ROOT@#$ROOT#g" \
    -e "s#@LOG_DIR@#$LOG_DIR#g" \
    -e "s#@PORT@#$PORT#g" \
    -e "s#@PATH@#$UNIT_PATH#g" \
    "$ROOT/systemd/$UNIT" > "$UNIT_DIR/$UNIT"
  systemctl --user daemon-reload
  systemctl --user enable "$UNIT" >/dev/null
  systemctl --user restart "$UNIT"
  wait_health
  if ! loginctl show-user "$USER_NAME" --property=Linger 2>/dev/null | grep -q 'Linger=yes'; then
    say "note: the service stops when you log out. To keep it running: sudo loginctl enable-linger $USER_NAME"
  fi
  MANAGE="  status  : systemctl --user status $UNIT
  restart : systemctl --user restart $UNIT
  stop    : systemctl --user stop $UNIT"
else
  # ---- no service manager (containers, Codespaces, WSL without systemd) -----------
  say "systemd is not running here; starting the service in the background instead (it will not restart on its own)"
  if curl -fs "http://127.0.0.1:$PORT/health" >/dev/null 2>&1; then
    "$NODE" "$ROOT/dist/cli.js" serve --stop >/dev/null 2>&1 || true
    sleep 1
  fi
  BRIDGE_PORT="$PORT" nohup "$ROOT/scripts/serve.sh" >>"$LOG_DIR/serve.log" 2>>"$LOG_DIR/serve.err.log" </dev/null &
  wait_health
  MANAGE="  start   : BRIDGE_PORT=$PORT nohup $ROOT/scripts/serve.sh >>$LOG_DIR/serve.log 2>&1 &   (e.g. from a devcontainer postStartCommand)
  stop    : claude-agent serve --stop"
fi

cat <<EOF

installed.
$MANAGE
  logs    : $LOG_DIR/{serve.log,serve.err.log,bridge.log}
  data    : $DATA_DIR/{bridge.db,token,env,config.json,guardrails.json}

next:
  claude setup-token            # one-time browser flow (Pro/Max/Team/Enterprise), or log in with \`claude\` once
  claude-agent auth set-token   # paste the token → 0600 env file, service reloads
  claude-agent doctor
  claude-agent web              # web console URL + one-click login link
EOF

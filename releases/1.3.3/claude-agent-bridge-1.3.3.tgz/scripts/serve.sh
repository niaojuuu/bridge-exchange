#!/bin/bash
# Service entry point for launchd (macOS) and systemd --user (Linux) (DESIGN §10.3).
# Sources the 0600 env file so the OAuth token never sits in the plist / unit,
# then execs the bridge service.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export PATH="/opt/homebrew/bin:/usr/local/bin:${PATH:-/usr/bin:/bin:/usr/sbin:/sbin}"
export HOME="${HOME:-$(eval echo "~$(id -un)")}"

# Same defaults as resolvePaths() in src/core/config.ts.
if [[ "$(uname -s)" == "Darwin" ]]; then
  BRIDGE_HOME="${BRIDGE_HOME:-$HOME/Library/Application Support/claude-agent-bridge}"
  LOG_DIR="${BRIDGE_LOG_DIR:-$HOME/Library/Logs/claude-agent-bridge}"
else
  BRIDGE_HOME="${BRIDGE_HOME:-$HOME/.claude-agent-bridge}"
  LOG_DIR="${BRIDGE_LOG_DIR:-$BRIDGE_HOME/logs}"
fi
mkdir -p "$BRIDGE_HOME" "$LOG_DIR"
chmod 700 "$BRIDGE_HOME" 2>/dev/null || true

ENV_FILE="$BRIDGE_HOME/env"
# Secret files are 0600 no matter how they were (re)created (hand edits, shell redirection).
for f in "$ENV_FILE" "$BRIDGE_HOME/token" "$BRIDGE_HOME/config.json"; do
  [[ -f "$f" ]] && chmod 600 "$f" 2>/dev/null || true
done
if [[ -f "$ENV_FILE" ]]; then
  # KEY=VALUE lines; comments allowed. Values are exported into the service env
  # (the bridge re-reads this file itself for subprocesses and on `auth reload`).
  set -a
  # shellcheck disable=SC1090
  source "$ENV_FILE"
  set +a
fi

# Never let the service inherit API-key billing paths (the bridge strips these
# from subprocesses too; this is belt-and-braces for the service itself).
unset ANTHROPIC_API_KEY ANTHROPIC_AUTH_TOKEN CLAUDE_CODE_USE_BEDROCK CLAUDE_CODE_USE_VERTEX CLAUDE_CODE_USE_FOUNDRY

export BRIDGE_PORT="${BRIDGE_PORT:-7788}"
# Asynchronous file operations share libuv's thread pool (4 threads by default). One on a remote
# directory whose computer just went to sleep holds its thread until the mount is dropped
# (mount_heartbeat_s); a bigger pool keeps everyone else's file operations going meanwhile.
export UV_THREADPOOL_SIZE="${UV_THREADPOOL_SIZE:-16}"

NODE="$(command -v node || true)"
if [[ -z "$NODE" ]]; then
  echo "serve.sh: node not found on PATH ($PATH)" >&2
  exit 78
fi
MAJOR="$("$NODE" -p 'process.versions.node.split(".")[0]')"
if (( MAJOR < 24 )); then
  echo "serve.sh: Node >= 24 required (found $("$NODE" --version))" >&2
  exit 78
fi

cd "$ROOT"
if [[ ! -f dist/cli.js ]]; then
  echo "serve.sh: dist/cli.js missing — run: npm ci && npm run build" >&2
  exit 78
fi

exec "$NODE" dist/cli.js serve

#!/bin/bash
# Stop and remove the per-user service (launchd on macOS, systemd --user on Linux)
# and the CLI symlink. Data dir and transcripts are kept (pass --purge to delete
# the data dir too).
set -euo pipefail
LABEL="com.yxfsoft.claude-agent-bridge"
UNIT="claude-agent-bridge.service"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
UID_NUM="$(id -u)"
HOME_DIR="${HOME:-$(eval echo "~$(id -un)")}"

if [[ "$(uname -s)" == "Darwin" ]]; then
  DATA_DIR="$HOME_DIR/Library/Application Support/claude-agent-bridge"
  launchctl bootout "gui/$UID_NUM/$LABEL" 2>/dev/null || true
  rm -f "$HOME_DIR/Library/LaunchAgents/$LABEL.plist"
else
  DATA_DIR="$HOME_DIR/.claude-agent-bridge"
  UNIT_FILE="${XDG_CONFIG_HOME:-$HOME_DIR/.config}/systemd/user/$UNIT"
  if [[ -d /run/systemd/system && -f "$UNIT_FILE" ]]; then
    systemctl --user disable --now "$UNIT" 2>/dev/null || true
    rm -f "$UNIT_FILE"
    systemctl --user daemon-reload 2>/dev/null || true
  fi
  # Started without a service manager: ask it to stop.
  node "$ROOT/dist/cli.js" serve --stop >/dev/null 2>&1 || true
fi
for d in /opt/homebrew/bin /usr/local/bin "$HOME_DIR/.local/bin"; do
  [[ -L "$d/claude-agent" ]] && rm -f "$d/claude-agent" && echo "removed $d/claude-agent"
done
if [[ "${1:-}" == "--purge" ]]; then
  rm -rf "$DATA_DIR"
  echo "purged data dir"
fi
echo "uninstalled"

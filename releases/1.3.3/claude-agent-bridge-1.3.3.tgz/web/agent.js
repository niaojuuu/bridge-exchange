'use strict';
/*
 * The local agent's link, kept by this page (CODE-GUIDE §14.3). The agent is a program the user runs on their
 * own computer (`node cab-agent.mjs`); it listens on 127.0.0.1 and only for consoles it was paired with. This page
 * connects to it and to the bridge (WebSocket /agent/connect, with a ticket asked for with the login) and passes
 * messages between them: the agent's resources and the results of calls go to the bridge, calls go to the agent.
 * The page decides nothing: what may run is the agent's to say, and changes are allowed in its own window.
 *
 * States: off · connecting · no_agent (nothing listening: not started?) · refused (the pairing code was not taken)
 * · online · replaced (another page took over) · failed.
 *
 * Exposes `CabAgent` (Link). No dependencies; also loaded by the tests in Node.
 */
(function (global) {
  const BACKOFF_S = [1, 2, 4, 8, 15, 30];
  const PROTOCOL = 1;
  const CLOSE_REPLACED = 4002;
  const CLOSE_REVOKED = 4007;
  const CLOSE_REFUSED = 4401;

  class Link {
    /**
     * opts: port, token (the pairing code), origin (this console, http(s)://…), fetch (for the ticket; sends the
     * login cookie), onchange(state, detail), onconfirm(resource, text): the agent asks its user to allow something;
     * agentSocket(url) / bridgeSocket(url): make the WebSockets (tests).
     */
    constructor(opts) {
      this.o = opts;
      this.state = 'off';
      this.detail = '';
      this.agent = null; // { version, config_path, resources }
      this.stopped = true;
      this.a = null; // WebSocket to the agent
      this.b = null; // WebSocket to the bridge
      this.aReady = false;
      this.aTry = 0;
      this.bTry = 0;
      this.aTimer = null;
      this.bTimer = null;
      this.lastError = null;
    }

    set(state, detail = '') {
      if (this.state === state && this.detail === detail) return;
      this.state = state;
      this.detail = detail;
      try { this.o.onchange && this.o.onchange(state, detail); } catch (e) { /* the page's problem */ }
    }

    start() {
      if (!this.stopped) return;
      this.stopped = false;
      this.set('connecting');
      this.connectBridge();
      this.connectAgent();
    }

    stop() {
      this.stopped = true;
      clearTimeout(this.aTimer);
      clearTimeout(this.bTimer);
      const a = this.a, b = this.b;
      this.a = null;
      this.b = null;
      this.aReady = false;
      this.agent = null;
      try { a && a.close(1000, 'stopped from the page'); } catch (e) { /* closing */ }
      try { b && b.close(1000, 'stopped from the page'); } catch (e) { /* closing */ }
      this.set('off');
    }

    /** Tell the bridge how the agent is. */
    report() {
      if (!this.b || this.b.readyState !== 1) return;
      const m = this.aReady && this.agent
        ? { t: 'agent', online: true, version: this.agent.version, config_path: this.agent.config_path, resources: this.agent.resources }
        : { t: 'agent', online: false, error: this.lastError || undefined };
      this.b.send(JSON.stringify(m));
    }

    // ---- the agent, on this computer ---------------------------------------------------------------------

    connectAgent() {
      if (this.stopped) return;
      const url = `ws://127.0.0.1:${this.o.port}/`;
      let ws;
      try { ws = this.o.agentSocket ? this.o.agentSocket(url) : new WebSocket(url); } catch (e) { return this.retryAgent('no_agent', String(e && e.message || e)); }
      this.a = ws;
      ws.onopen = () => { ws.send(JSON.stringify({ t: 'hello', token: this.o.token, protocol: PROTOCOL })); };
      ws.onmessage = (ev) => {
        let m;
        try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : ''); } catch (e) { return; }
        if (m.t === 'hello') {
          this.aReady = true;
          this.aTry = 0;
          this.lastError = null;
          this.agent = { version: String(m.version || ''), config_path: String(m.config_path || ''), resources: Array.isArray(m.resources) ? m.resources : [] };
          this.set('online', this.agent.version);
          this.report();
        } else if (m.t === 'resources' && this.agent) {
          this.agent.resources = Array.isArray(m.resources) ? m.resources : [];
          try { this.o.onchange && this.o.onchange(this.state, this.detail); } catch (e) { /* the page's problem */ }
          this.report();
        } else if (m.t === 'confirming') {
          try { this.o.onconfirm && this.o.onconfirm(String(m.resource || ''), String(m.text || '')); } catch (e) { /* the page's problem */ }
          if (this.b && this.b.readyState === 1) this.b.send(JSON.stringify({ t: 'confirming', id: m.id }));
        } else if (m.t === 'result') {
          if (this.b && this.b.readyState === 1) this.b.send(JSON.stringify(m));
        }
      };
      ws.onclose = (ev) => {
        if (this.a !== ws) return;
        const was = this.aReady;
        this.a = null;
        this.aReady = false;
        this.agent = null;
        if (this.stopped) return;
        if (ev.code === CLOSE_REPLACED) { this.stop(); return this.set('replaced', '另一个页面（或标签页）连上了本机助手'); }
        if (ev.code === CLOSE_REFUSED) { this.lastError = 'the local agent did not accept the pairing code'; this.report(); return this.retryAgent('refused', '本机助手没认这个配对码：重新复制配对命令，在你电脑上运行一次', 30); }
        this.lastError = was ? 'the local agent went away' : 'no local agent listening';
        this.report();
        this.retryAgent('no_agent', was ? '本机助手断开了' : `没找到本机助手（127.0.0.1:${this.o.port}）：它在运行吗？`);
      };
      ws.onerror = () => { /* onclose follows */ };
    }

    retryAgent(state, detail, fixedS) {
      this.set(state, detail);
      if (this.stopped) return;
      const wait = fixedS || BACKOFF_S[Math.min(this.aTry++, BACKOFF_S.length - 1)];
      clearTimeout(this.aTimer);
      this.aTimer = setTimeout(() => this.connectAgent(), wait * 1000);
    }

    // ---- the bridge ---------------------------------------------------------------------------------------

    async connectBridge() {
      if (this.stopped) return;
      let t;
      try {
        const res = await this.o.fetch('/agent/ticket', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json' }, body: '{}' });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          const msg = (data.error && data.error.message) || `HTTP ${res.status}`;
          if (res.status === 401 || res.status === 503 && /turned off/.test(msg)) { this.stopped = true; return this.set('failed', res.status === 401 ? '登录已失效：重新登录' : '这台服务器没有开放本机助手'); }
          return this.retryBridge();
        }
        t = data;
      } catch (e) { return this.retryBridge(); }
      if (this.stopped) return;
      const ws = this.o.bridgeSocket ? this.o.bridgeSocket(`${this.o.origin.replace(/^http/i, 'ws')}${t.connect}`) : new WebSocket(`${this.o.origin.replace(/^http/i, 'ws')}${t.connect}`);
      this.b = ws;
      ws.onopen = () => { this.bTry = 0; this.report(); };
      ws.onmessage = (ev) => {
        let m;
        try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : ''); } catch (e) { return; }
        if (m.t !== 'call') return;
        if (this.a && this.aReady && this.a.readyState === 1) this.a.send(JSON.stringify(m));
        else ws.send(JSON.stringify({ t: 'result', id: m.id, ok: false, error: "the local agent is not connected to the user's browser right now" }));
      };
      ws.onclose = (ev) => {
        if (this.b !== ws) return;
        this.b = null;
        if (this.stopped) return;
        if (ev.code === CLOSE_REPLACED) { this.stop(); return this.set('replaced', '另一个页面接管了本机助手'); }
        if (ev.code === CLOSE_REVOKED) { this.stop(); return this.set('failed', ev.reason || '权限被收回'); }
        this.retryBridge();
      };
      ws.onerror = () => { /* onclose follows */ };
    }

    retryBridge() {
      if (this.stopped) return;
      const wait = BACKOFF_S[Math.min(this.bTry++, BACKOFF_S.length - 1)];
      clearTimeout(this.bTimer);
      this.bTimer = setTimeout(() => { void this.connectBridge(); }, wait * 1000);
    }
  }

  /** A pairing code: 24 random bytes, base64url (only its hash is kept by the agent). */
  function newCode() {
    const b = new Uint8Array(24);
    (global.crypto || globalThis.crypto).getRandomValues(b);
    let s = '';
    for (const x of b) s += String.fromCharCode(x);
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  global.CabAgent = { Link, newCode, PROTOCOL };
})(typeof window !== 'undefined' ? window : globalThis);

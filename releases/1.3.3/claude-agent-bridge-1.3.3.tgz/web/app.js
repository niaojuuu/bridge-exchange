'use strict';
/*
 * Claude Code web console. Plain browser JS, no build step, served from the
 * bridge itself (same origin, cookie auth). Talks to the bridge HTTP API:
 *   GET  /sessions                       sidebar + status (polled)
 *   GET  /sessions/:id/history           full conversation from Claude Code's transcript
 *   GET  /sessions/:id/events/stream     live events (SSE)
 *   POST /sessions/:id/messages|input|interrupt|cancel|resume, PATCH/DELETE /sessions/:id
 *   GET  /claude-sessions                resumable sessions on this machine (terminal ones too)
 *   GET  /fs/list, /fs/download          file manager: browse; download a file, or a folder as .zip
 *   GET  /fs/preview                     a file shown in the page (images, audio, video, PDF, STL, text)
 *   PUT  /fs/file, POST /fs/exists|mkdir upload files / folders (raw body, one request per file)
 *   GET  /web/me                         who is logged in: the admin, or a user confined to their directory
 *   GET|POST /users, POST /users/:name/token, DELETE /users/:name   user management (admin)
 *   GET /mounts, DELETE /mounts/:id      remote directories: folders on the users' computers
 *   POST /mounts/ticket + WebSocket /mounts/connect     a folder shared from this page (web/remote.js)
 *   POST /sessions/:id/mail              "after this step": read after Claude's next tool call (projects mailbox)
 * Projects (roles, board, inbox, missions) are drawn by web/projects.js, which uses this file's helpers.
 */

// ---- helpers ------------------------------------------------------------------

const $ = (sel, root = document) => root.querySelector(sel);
const enc = encodeURIComponent;

function el(tag, attrs = {}, ...children) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k === 'html') e.innerHTML = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'dataset') Object.assign(e.dataset, v);
    else e.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) if (c !== null && c !== undefined && c !== false) e.append(c instanceof Node ? c : String(c));
  return e;
}

class ApiError extends Error {
  constructor(status, code, message, hint) {
    super(message);
    this.status = status;
    this.code = code;
    this.hint = hint;
  }
}

async function api(method, path, body) {
  const opts = { method, credentials: 'same-origin', headers: {} };
  if (body !== undefined) {
    opts.headers['content-type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  let res;
  try {
    res = await fetch(path, opts);
  } catch (e) {
    throw new ApiError(0, 'unreachable', '连不上服务（服务停了，或者端口转发断了）');
  }
  const ct = res.headers.get('content-type') || '';
  const data = ct.includes('json') ? await res.json().catch(() => null) : await res.text();
  if (res.status === 401 && !path.startsWith('/web/')) {
    showLogin();
    throw new ApiError(401, 'unauthorized', '登录已失效，请重新登录');
  }
  if (!res.ok) {
    const err = (data && data.error) || {};
    throw new ApiError(res.status, err.code, err.message || `HTTP ${res.status}`, err.hint);
  }
  return data;
}

function errText(e) {
  if (!(e instanceof ApiError)) return String(e && e.message ? e.message : e);
  // The page is read from disk on every load, the server code only on (re)start: a new page on an old service.
  if (e.status === 404 && /^no route /.test(e.message)) return `服务端还是旧版本，没有这个功能：重新编译并重启服务后再刷新页面（npm run build，然后重启 claude-agent-bridge；或者 claude-agent upgrade）。\n${e.message}`;
  const map = {
    cwd_busy: '这个目录下已经有会话在运行。可以勾选“允许共用目录”，或者等它结束。',
    session_held: '这个会话正被终端里的 claude 占用，先在终端退出它再接管。',
    name_taken: '名称已被占用，换一个。',
    cwd_missing: '目录不存在或无法访问。',
    invalid_state: '当前状态不允许这个操作。',
    file_exists: '同名的文件或文件夹已经存在。',
    forbidden: '没有权限（超出了你能访问的范围）。',
    remote_offline: '这个远程目录现在没有连接：在那台电脑的浏览器里重新共享这个文件夹，连上后就能继续。',
    out_of_view: '这个会话的目录，管理员现在看不到（服务器 config.json 的 admin_view_*），所以不能接着用：在弹出的对话框里把它转给目录所在的用户，或者打开对应的 admin_view_* 后重启服务。',
    remote_unavailable: '这台服务器用不了远程目录。',
    agent_unavailable: '这台服务器没有开放本机助手。',
    mount_limit: '同时连接的远程目录到上限了，先断开一个。',
    no_account: '没有能用的 Claude 账号：管理员把账号都分给了别的用户。请管理员在“Claude 账号”→“谁能用”里给你分一个（或设为所有用户都能用）。',
  };
  if (e.code === 'out_of_view' && typeof checkOutOfView === 'function') setTimeout(() => checkOutOfView(true), 0);
  return (map[e.code] ? `${map[e.code]}\n` : '') + e.message + (e.hint ? `\n提示：${e.hint}` : '');
}

let toastTimer = null;
function toast(msg, isError = false) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = 'toast' + (isError ? ' error' : '');
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, isError ? 7000 : 3000);
}

function fmtTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const now = new Date();
  const hm = d.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
  if (d.toDateString() === now.toDateString()) return hm;
  return `${d.getMonth() + 1}-${d.getDate()} ${hm}`;
}

function fmtAgo(iso) {
  if (!iso) return '';
  const s = Math.max(0, Math.round((Date.now() - Date.parse(iso)) / 1000));
  if (s < 60) return `${s} 秒前`;
  if (s < 3600) return `${Math.floor(s / 60)} 分钟前`;
  if (s < 86400) return `${Math.floor(s / 3600)} 小时前`;
  return `${Math.floor(s / 86400)} 天前`;
}

function fmtDuration(s) {
  if (s === null || s === undefined) return '';
  if (s < 60) return `${s} 秒`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m} 分 ${s % 60} 秒`;
  return `${Math.floor(m / 60)} 小时 ${m % 60} 分`;
}

const basename = (p) => (p || '').replace(/\/+$/, '').split('/').pop() || p || '';

const STATE_LABEL = {
  created: '新建', running: '运行中', waiting_input: '等你回答', idle: '空闲',
  dormant: '休眠', cancelled: '已关闭', failed: '失败',
};
const BUSY_LABEL = {
  turn: 'Claude 正在工作', subagents: '主回答已出，子任务还在运行', question: 'Claude 在等你回答问题', queued: '排队中，等待空闲名额',
  quota: '能用的 Claude 账号额度都用完了，等恢复后自动接着做',
  no_account: '没有能用的 Claude 账号（管理员把账号都分给了别人），等管理员分一个后自动接着做',
};

// ---- markdown (escape everything, then add a small safe subset of tags) ---------

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function fmtInline(t) {
  t = esc(t);
  t = t.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, (_m, a, u) => `<a href="${u}" target="_blank" rel="noopener noreferrer">${a}</a>`);
  t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  t = t.replace(/(^|[^*\w])\*([^*\s][^*]*?)\*(?!\w)/g, '$1<em>$2</em>');
  return t;
}

function inline(s) {
  let out = '';
  let last = 0;
  const re = /`([^`]+)`/g;
  let m;
  while ((m = re.exec(s))) {
    out += fmtInline(s.slice(last, m.index)) + `<code>${esc(m[1])}</code>`;
    last = re.lastIndex;
  }
  return out + fmtInline(s.slice(last));
}

const splitRow = (s) => s.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((c) => c.trim());
const BLOCK_START = /^\s*(```|~~~|#{1,6}\s|>|([-*+]|\d+[.)])\s)/;

function md(src) {
  const lines = String(src).replace(/\r\n?/g, '\n').split('\n');
  let html = '';
  let i = 0;
  while (i < lines.length) {
    const l = lines[i];
    const fence = /^\s*(```|~~~)/.exec(l);
    if (fence) {
      const buf = [];
      i++;
      while (i < lines.length && !lines[i].trim().startsWith(fence[1])) buf.push(lines[i++]);
      i++;
      html += `<pre><code>${esc(buf.join('\n'))}</code></pre>`;
      continue;
    }
    if (!l.trim()) { i++; continue; }
    const h = /^(#{1,6})\s+(.*)$/.exec(l);
    if (h) {
      const lvl = Math.min(h[1].length, 4);
      html += `<h${lvl}>${inline(h[2])}</h${lvl}>`;
      i++;
      continue;
    }
    if (/^\s*(\*\s*){3,}$|^\s*(-\s*){3,}$|^\s*(_\s*){3,}$/.test(l)) { html += '<hr>'; i++; continue; }
    if (/^\s*>/.test(l)) {
      const buf = [];
      while (i < lines.length && /^\s*>/.test(lines[i])) buf.push(lines[i++].replace(/^\s*> ?/, ''));
      html += `<blockquote>${md(buf.join('\n'))}</blockquote>`;
      continue;
    }
    if (/^\s*\|.*\|\s*$/.test(l) && i + 1 < lines.length && /^\s*\|?\s*:?-{2,}/.test(lines[i + 1])) {
      const head = splitRow(l);
      const rows = [];
      i += 2;
      while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) rows.push(splitRow(lines[i++]));
      html += `<table><thead><tr>${head.map((c) => `<th>${inline(c)}</th>`).join('')}</tr></thead><tbody>${rows.map((r) => `<tr>${r.map((c) => `<td>${inline(c)}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
      continue;
    }
    const lm = /^(\s*)([-*+]|\d+[.)])\s+/.exec(l);
    if (lm) {
      const ordered = /\d/.test(lm[2]);
      const items = [];
      while (i < lines.length) {
        const m2 = /^(\s*)([-*+]|\d+[.)])\s+(.*)$/.exec(lines[i]);
        if (m2) { items.push(m2[3]); i++; }
        else if (items.length && lines[i].trim() && /^\s{2,}/.test(lines[i])) { items[items.length - 1] += '\n' + lines[i].trim(); i++; }
        else break;
      }
      const tag = ordered ? 'ol' : 'ul';
      html += `<${tag}>${items.map((x) => `<li>${x.split('\n').map(inline).join('<br>')}</li>`).join('')}</${tag}>`;
      continue;
    }
    const buf = [lines[i++]];
    while (i < lines.length && lines[i].trim() && !BLOCK_START.test(lines[i])) buf.push(lines[i++]);
    html += `<p>${buf.map(inline).join('<br>')}</p>`;
  }
  return html;
}

// ---- state ----------------------------------------------------------------------

const S = {
  me: null,           // GET /web/me: { admin, name, root }
  sessions: [],
  current: null,      // session id
  status: null,       // SessionStatus of the current session
  es: null,           // EventSource
  mode: 'events',     // 'history' (rendered from Claude Code's transcript) | 'events' (bridge event log)
  tools: new Map(),   // tool_use_id → tool element
  questionCards: new Map(),
  startedTurns: new Set(),
  lastTurnEnd: null,
  reloadTimer: null,
  catalog: null,
  attachments: [],    // { path, url }
  pollTimer: null,
  tasksOpen: false,   // the background-task list under the status bar is expanded
  hist: null,         // the transcript part on screen: { id, start, end, loading } (item positions, oldest = 0)
  histMark: null,     // hidden node after the last transcript item; what is drawn live goes after it
  sink: null,         // while drawing a page off-screen: where add* put their elements
  toolResults: new Map(), // tool_use_id → result that came before its tool call was drawn (an older page)
};

// ---- auth ----------------------------------------------------------------------

function showLogin() {
  $('#app').hidden = true;
  $('#login').hidden = false;
  // Whoever logs in next (maybe another user) starts clean.
  if (S.current) closeSession();
  S.me = null;
  F.path = null;
  F.want = '';
  closeStream();
  clearInterval(S.pollTimer);
  $('#login-token').focus();
}

async function login(token) {
  await api('POST', '/web/login', { token });
}

async function boot() {
  const m = /[#&]token=([^&]+)/.exec(location.hash);
  if (m) {
    history.replaceState(null, '', location.pathname + location.search);
    try { await login(decodeURIComponent(m[1])); } catch (e) { /* fall through to the login form */ }
  }
  let me = { authenticated: false };
  try { me = await api('GET', '/web/me'); } catch (e) { toast(errText(e), true); }
  if (!me.authenticated) return showLogin();
  startApp();
}

$('#login-form').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const err = $('#login-error');
  err.hidden = true;
  try {
    await login($('#login-token').value);
    $('#login-token').value = '';
    startApp();
  } catch (e) {
    err.textContent = e.status === 401 ? '令牌不对' : errText(e);
    err.hidden = false;
  }
});

$('#btn-logout').addEventListener('click', async () => {
  stopAllShares();
  stopAgent();
  try { await api('POST', '/web/logout', {}); } catch (e) { /* ignore */ }
  showLogin();
});

async function startApp() {
  $('#login').hidden = true;
  $('#app').hidden = false;
  try { S.me = await api('GET', '/web/me'); } catch (e) { S.me = null; }
  renderIdentity();
  refreshSessions().then(() => {
    const h = new URLSearchParams(location.hash.slice(1));
    const want = h.get('s');
    if (want && S.sessions.some((s) => s.id === want)) openSession(want);
    else if (h.get('p') && typeof openProject === 'function') openProject(h.get('p'));
  });
  refreshHealth();
  resumeShares();
  startAgent();
  checkOutOfView(false);
  clearInterval(S.pollTimer);
  let tick = 0;
  S.pollTimer = setInterval(() => {
    if (document.hidden) return;
    refreshSessions();
    if (++tick % 12 === 0) refreshHealth();
  }, 2500);
}

function renderIdentity() {
  const me = S.me || {};
  const el2 = $('#me');
  el2.textContent = me.admin ? '管理员' : me.name ? `用户 ${me.name} · ${me.root}` : '';
  el2.title = me.admin ? '管理员：不受目录限制，可以管理用户' : me.root ? `只能使用 ${me.root}` : '';
  $('#btn-users').hidden = !me.admin;
  $('#btn-usage').hidden = !me.admin;
  $('#btn-accounts').hidden = !me.admin;
}

const isAdmin = () => !!(S.me && S.me.admin);

async function refreshHealth() {
  try {
    const h = await api('GET', '/health');
    const auth = h.auth || {};
    const s = $('#health');
    s.textContent = `${auth.status === 'ok' ? '✓ 已登录 Claude' : `⚠ Claude 认证：${auth.status || '未知'}`} · v${h.version}${h.sdk === 'fake' ? ' · 测试 SDK' : ''}`;
    s.title = auth.warning || '';
  } catch (e) { /* shown elsewhere */ }
}

// ---- sidebar --------------------------------------------------------------------

async function refreshSessions() {
  let list;
  if (typeof refreshProjects === 'function') refreshProjects();
  try { list = await api('GET', '/sessions'); } catch (e) { return; }
  list.sort((a, b) => (b.updated_at || '').localeCompare(a.updated_at || ''));
  S.sessions = list;
  renderSidebar();
  if (S.current) {
    const st = list.find((s) => s.id === S.current);
    if (st) updateStatus(st);
    else { toast('当前会话已被删除'); closeSession(); }
  }
}

function displayName(st) {
  return st.name || `未命名 ${st.id.slice(0, 8)}`;
}

function sessionItem(st, label) {
  const sub = [basename(st.cwd), STATE_LABEL[st.state] || st.state, fmtAgo(st.updated_at)].filter(Boolean).join(' · ');
  return el('li', { class: st.id === S.current ? 'active' : '', title: st.cwd, onclick: () => { openSession(st.id); closeSidebarMobile(); } },
    el('div', { class: 's-top' },
      el('span', { class: `dot ${st.state}` }),
      el('span', { class: 's-name', text: label || displayName(st) }),
      isAdmin() && st.owner ? el('span', { class: 'owner', text: st.owner, title: `用户 ${st.owner} 的会话` }) : null,
      st.pending_question ? el('span', { class: 'badge waiting_input', text: '待回答' }) : null),
    el('div', { class: 's-sub', text: sub }));
}

function renderSidebar() {
  const ul = $('#session-list');
  // projects group their sessions under them (web/projects.js); plain sessions follow
  if (typeof renderGroupedSidebar === 'function') return renderGroupedSidebar(ul, sessionItem);
  ul.replaceChildren(...S.sessions.map((st) => sessionItem(st)));
  if (!S.sessions.length) ul.append(el('li', { class: 'muted small', text: '还没有会话' }));
}

function uniqueName(base) {
  base = String(base || '').replace(/[\\/\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 40) || '会话';
  let name = base;
  for (let i = 2; S.sessions.some((s) => s.name === name); i++) name = `${base} ${i}`;
  return name;
}

const sidebar = $('#sidebar');
function closeSidebarMobile() { sidebar.classList.remove('open'); }
for (const id of ['#btn-open-sidebar', '#btn-open-sidebar-empty']) $(id).addEventListener('click', () => sidebar.classList.add('open'));
$('#btn-close-sidebar').addEventListener('click', closeSidebarMobile);

// ---- chat: open / close -----------------------------------------------------------

function closeStream() {
  if (S.es) { S.es.close(); S.es = null; }
}

function closeSession() {
  closeStream();
  if (typeof leaveProject === 'function') leaveProject();
  S.current = null;
  S.status = null;
  $('#chat').hidden = true;
  $('#empty').hidden = false;
  history.replaceState(null, '', location.pathname);
  renderSidebar();
}

function resetMessages() {
  $('#messages').replaceChildren();
  S.tools.clear();
  S.questionCards.clear();
  S.toolResults.clear();
  S.hist = null;
  S.histMark = null;
}

async function openSession(id) {
  if (S.current === id && S.es) return;
  closeStream();
  S.current = id;
  S.status = null;
  S.startedTurns = new Set();
  S.lastTurnEnd = null;
  S.attachments = [];
  renderAttachments();
  resetMessages();
  $('#busy').hidden = true;
  $('#empty').hidden = true;
  if (typeof leaveProject === 'function') leaveProject();
  $('#chat').hidden = false;
  history.replaceState(null, '', `${location.pathname}#s=${id}`);
  renderSidebar();
  try {
    updateStatus(await api('GET', `/sessions/${enc(id)}`));
  } catch (e) {
    toast(errText(e), true);
    return closeSession();
  }
  loadModels();
  const hist = await loadHistory(id);
  if (S.current !== id) return;
  // Without a Claude Code transcript (brand-new session, or the test SDK) replay the bridge's own event log.
  startStream(id, hist && hist.found ? hist.next_seq : 0);
  $('#input').focus();
}

/**
 * A long conversation is shown a page at a time: the newest HIST_FIRST items when it opens, HIST_PAGE older ones
 * each time the view nears the top, and after every turn only what was added (drawing hundreds of messages at once
 * is what made opening a long session slow).
 */
const HIST_FIRST = 80;
const HIST_PAGE = 100;

/** Where history items are drawn: the message list, or an off-screen fragment while a page is prepared. */
const histSink = () => S.sink || $('#messages');

function renderItems(items) {
  for (const it of items) {
    if (it.kind === 'user') {
      const m = addUser(it.text, { ts: it.ts });
      if (it.via === 'step') setMeta(m, `${fmtTime(it.ts)} · 干活中途读到`);
    }
    else if (it.kind === 'assistant') addAssistant(it.text, it.ts);
    else if (it.kind === 'tool_use') addTool(it.tool, it.text, it.tool_use_id);
    else if (it.kind === 'tool_result') setToolResult(it.tool_use_id, !it.is_error, it.text);
  }
}

/** Draw items into a fragment (not on screen yet). */
function renderPage(items) {
  S.sink = document.createDocumentFragment();
  try { renderItems(items); return S.sink; } finally { S.sink = null; }
}

/** Open a session's conversation: the newest page. */
async function loadHistory(id) {
  let h;
  try { h = await api('GET', `/sessions/${enc(id)}/history?limit=${HIST_FIRST}`); } catch (e) { return null; }
  if (S.current !== id) return null;
  if (!h.found) { S.mode = 'events'; return h; }
  S.mode = 'history';
  const box = $('#messages');
  const stick = nearBottom();
  resetMessages();
  box.append(el('div', { id: 'older', class: 'msg notice older', onclick: () => loadOlder() }));
  box.append(renderPage(h.items));
  S.histMark = el('div', { class: 'hist-mark', hidden: true });
  box.append(S.histMark);
  S.hist = { id, start: h.start, end: h.end, loading: false };
  afterHistory(stick);
  updateOlder();
  void fillView();
  return h;
}

/** After a turn: add what the transcript gained, in place of what was drawn live meanwhile. */
async function refreshHistory(id) {
  const hs = S.hist;
  if (!hs || hs.id !== id || S.mode !== 'history' || !S.histMark) return loadHistory(id);
  let h;
  try { h = await api('GET', `/sessions/${enc(id)}/history?after=${hs.end}&limit=1000`); } catch (e) { return null; }
  if (S.current !== id || S.hist !== hs) return null;
  // the transcript is not what was shown (another copy, or far more than one turn added): draw it again
  if (!h.found || h.start !== hs.end || h.end < h.total) return loadHistory(id);
  const stick = nearBottom();
  while (S.histMark.nextSibling) S.histMark.nextSibling.remove();
  for (const [k, v] of S.tools) if (!v.isConnected) S.tools.delete(k);
  for (const [k, v] of S.questionCards) if (!v.isConnected) S.questionCards.delete(k);
  S.histMark.before(renderPage(h.items));
  hs.end = h.end;
  afterHistory(stick);
  return h;
}

function afterHistory(stick) {
  for (const t of S.tools.values()) if (t.dataset.done !== '1') markToolPending(t, S.status && S.status.state === 'running');
  if (S.lastTurnEnd) renderTurnEnd(S.lastTurnEnd);
  if (S.status && S.status.pending_question) ensureQuestion(S.status.pending_question);
  if (stick) scrollBottom(true);
}

/** The next older page, put above what is shown without moving the view. */
async function loadOlder() {
  const hs = S.hist;
  if (!hs || hs.loading || hs.start <= 0) return;
  hs.loading = true;
  updateOlder();
  let h;
  try {
    h = await api('GET', `/sessions/${enc(hs.id)}/history?before=${hs.start}&limit=${HIST_PAGE}`);
  } catch (e) {
    hs.loading = false;
    updateOlder(errText(e));
    return;
  }
  hs.loading = false;
  if (S.hist !== hs) return;
  if (!h.found || h.end !== hs.start) return updateOlder();
  const frag = renderPage(h.items);
  const tools = [...frag.querySelectorAll('details.tool')];
  const box = $('#messages');
  const height = box.scrollHeight;
  const top = box.scrollTop;
  $('#older').after(frag);
  box.scrollTop = top + (box.scrollHeight - height);
  hs.start = h.start;
  for (const t of tools) if (t.dataset.done !== '1') markToolPending(t, false);
  updateOlder();
}

function updateOlder(err) {
  const o = $('#older');
  const hs = S.hist;
  if (!o || !hs) return;
  o.hidden = hs.start <= 0 && !err;
  o.classList.toggle('error', !!err);
  o.textContent = err ? `更早的记录没加载出来：${err}（点这里重试）`
    : hs.loading ? '正在加载更早的记录…'
    : `↑ 往上滚动加载更早的记录（还有 ${hs.start} 条）`;
}

/** A first page too short to scroll cannot be scrolled up: fetch older pages until there is something to scroll. */
async function fillView() {
  const box = $('#messages');
  for (let i = 0; i < 5 && S.hist && S.hist.start > 0 && box.scrollHeight <= box.clientHeight + 100; i++) {
    const hs = S.hist;
    await loadOlder();
    if (S.hist !== hs) return;
  }
}

$('#messages').addEventListener('scroll', () => {
  if (S.hist && S.hist.start > 0 && !S.hist.loading && $('#messages').scrollTop < 400) loadOlder();
}, { passive: true });

function scheduleReload() {
  clearTimeout(S.reloadTimer);
  const id = S.current;
  // Claude Code writes its transcript as it goes; give the last lines a moment to land.
  S.reloadTimer = setTimeout(() => { if (S.current === id) refreshHistory(id); }, 700);
}

// ---- chat: live events -------------------------------------------------------------

const STREAM_TYPES = [
  'turn.started', 'assistant.text', 'tool.use', 'tool.result', 'question.asked', 'question.answered',
  'turn.completed', 'turn.failed', 'turn.interrupted', 'permission.denied', 'session.failed', 'session.cancelled',
  'session.resumed', 'auth.error', 'stall.warning', 'compact', 'subagent.started', 'log', 'mail.delivered',
];

function startStream(id, since) {
  closeStream();
  const es = new EventSource(`/sessions/${enc(id)}/events/stream?since=${since}`);
  S.es = es;
  for (const t of STREAM_TYPES) {
    es.addEventListener(t, (msg) => {
      if (S.current !== id || S.es !== es) return;
      let ev;
      try { ev = JSON.parse(msg.data); } catch (e) { return; }
      const stick = nearBottom();
      onEvent(ev);
      if (stick) scrollBottom();
    });
  }
}

let refreshTimer = null;
/** Lifecycle events change the status bar; don't wait for the next poll. */
function refreshSoon() {
  clearTimeout(refreshTimer);
  refreshTimer = setTimeout(refreshSessions, 150);
}

const LIFECYCLE = new Set(['turn.started', 'question.asked', 'question.answered', 'turn.completed', 'turn.failed', 'turn.interrupted', 'session.failed', 'session.cancelled', 'session.resumed']);

function onEvent(ev) {
  if (LIFECYCLE.has(ev.type)) refreshSoon();
  switch (ev.type) {
    case 'turn.started': {
      S.startedTurns.add(ev.turn);
      // "after this step" messages that were merged into this turn: the turn's own bubble shows them
      for (const b of document.querySelectorAll('#messages .msg.user[data-mail]')) {
        if ((ev.text || '').includes(b.querySelector('.bubble').textContent.split('\n[')[0])) b.remove();
      }
      // a message sent while Claude was working that it read and answered within that turn (folded_into)
      const meta = ev.folded_into ? `${fmtTime(ev.ts)} · 在第 ${ev.folded_into} 轮里一起回答了`
        : ev.auto === 'quota' ? `${fmtTime(ev.ts)} · 换账号后自动接着做（不是你发的）` : fmtTime(ev.ts);
      const queued = $(`#messages .msg.user[data-turn="${ev.turn}"]`);
      if (queued) { queued.classList.remove('queued'); setMeta(queued, meta); }
      else {
        const m = addUser(ev.text || ev.text_preview || '', { ts: ev.ts, turn: ev.turn, images: ev.images });
        if (ev.auto) m.classList.add('auto');
        setMeta(m, meta);
      }
      break;
    }
    case 'assistant.text':
      addAssistant(ev.text, ev.ts);
      break;
    case 'tool.use':
      if (!ev.parent_tool_use_id) addTool(ev.tool, ev.input_summary, ev.tool_use_id);
      break;
    case 'tool.result':
      if (!ev.parent_tool_use_id) setToolResult(ev.tool_use_id, ev.ok, ev.excerpt);
      break;
    case 'subagent.started':
      addNotice(`启动子任务：${ev.description || ev.summary || ''}`);
      break;
    case 'mail.delivered': {
      // read after a step, within the turn: the owner's own "after this step" bubbles get their meta; others appear
      const ids = (ev.ids || []).map(String);
      let mine = 0;
      for (const b of document.querySelectorAll('#messages .msg.user[data-mail]')) {
        if (!ids.includes(b.dataset.mail)) continue;
        b.classList.remove('queued');
        setMeta(b, `${fmtTime(ev.ts)} · 做完一步时读到了`);
        delete b.dataset.mail;
        mine++;
      }
      if (mine < ids.length) {
        const m = addUser(ev.text || '', { ts: ev.ts });
        m.classList.add('mail');
        setMeta(m, `${fmtTime(ev.ts)} · 干活中途读到`);
      }
      break;
    }
    case 'question.asked':
      ensureQuestion({ id: ev.question_id, questions: ev.questions, deadline_at: ev.deadline_at });
      break;
    case 'question.answered':
      markQuestionAnswered(ev.question_id, ev.by);
      break;
    case 'turn.completed':
    case 'turn.failed':
    case 'turn.interrupted':
      if (ev.folded_into) break; // its answer is the turn it was folded into; that one already ended
      S.lastTurnEnd = ev;
      for (const t of S.tools.values()) if (t.dataset.done !== '1') markToolPending(t, false);
      renderTurnEnd(ev);
      scheduleReload();
      break;
    case 'permission.denied':
      addNotice(`已拒绝 ${ev.tool}：${ev.reason || ''}${ev.input_summary ? `（${ev.input_summary}）` : ''}`, 'warn');
      break;
    case 'session.failed':
      addNotice(`会话失败：${ev.reason || ''}${ev.error ? ` — ${ev.error}` : ''}`, 'error');
      break;
    case 'session.cancelled':
      addNotice('进程已关闭；再发消息会自动续上');
      break;
    case 'session.resumed':
      addNotice('已续接会话（重新启动了 Claude Code 进程，上下文保留）');
      break;
    case 'auth.error':
      addNotice(`Claude 认证出错：${ev.kind || ev.summary || ''}。在服务器上运行 claude setup-token 和 claude-agent auth set-token`, 'error');
      break;
    case 'stall.warning':
      addNotice(`已经 ${fmtDuration(ev.silent_s)} 没有动静了`, 'warn');
      break;
    case 'compact':
      addNotice('上下文已自动压缩');
      break;
    case 'log':
      if (ev.category === 'quota_continue') {
        addNotice(ev.account_label
          ? `这个 Claude 账号的额度用完了，已换到账号「${ev.account_label}」，带着之前的对话自动接着做`
          : `能用的 Claude 账号额度都用完了，${ev.until ? `约 ${fmtTime(ev.until)} 恢复后` : '等有账号恢复后'}自动接着做`, ev.account_label ? 'warn' : 'warn quota-wait');
      } else if (ev.category === 'quota_wait' && !$('#messages .notice.quota-wait:last-child')) {
        addNotice(ev.no_account
          ? '没有能用的 Claude 账号（管理员把账号都分给了别人），消息先排着，管理员分一个后自动发出'
          : `能用的 Claude 账号额度都用完了，消息先排着，${ev.until ? `约 ${fmtTime(ev.until)} ` : '有账号恢复时'}自动发出`, 'warn quota-wait');
      } else if (ev.category === 'account_switch') {
        addNotice(`改用 Claude 账号「${ev.to_label || ev.to}」（之前是「${ev.from_label || ev.from}」），对话接着来`);
      } else if (ev.category === 'background_lost') {
        const names = (ev.tasks || []).map((t) => t.description || t.task_id).join('、');
        addNotice(`Claude Code 进程关了（${goneReason(ev.reason)}），${(ev.tasks || []).length} 个后台任务跟着停了：${names}`, 'warn');
      }
      break;
  }
}

/** Why a Claude Code process went away, as the bridge records it. */
const GONE_REASON = {
  idle_ttl: '空闲太久，被回收了',
  process_cap: '给别的会话腾位置',
  bridge_shutdown: '服务重启',
  bridge_restart: '服务重启',
  cancelled: '点了关闭进程',
  deleted: '会话删除了',
};
function goneReason(r) {
  if (!r) return '原因不明';
  if (GONE_REASON[r]) return GONE_REASON[r];
  if (r.startsWith('restart')) return `改了设置，重启进程 ${r.slice(7).trim()}`;
  return r;
}

// ---- chat: rendering ------------------------------------------------------------------

function nearBottom() {
  const box = $('#messages');
  return box.scrollHeight - box.scrollTop - box.clientHeight < 80;
}

function scrollBottom(instant) {
  const box = $('#messages');
  requestAnimationFrame(() => box.scrollTo({ top: box.scrollHeight, behavior: instant ? 'auto' : 'smooth' }));
}

function setMeta(msgEl, text) {
  let m = $('.meta', msgEl);
  if (!m) { m = el('div', { class: 'meta' }); msgEl.append(m); }
  m.textContent = text;
}

/** A turn that is a project message (a role, the platform, the owner through the mailbox), not typed here. */
const MAIL_TEXT = /^(【来自 |（你忙的时候项目里来了|（你刚才这一步做完时|（你干活时用户)/;

function addUser(text, { ts, turn, queued, images } = {}) {
  const m = el('div', { class: 'msg user' + (queued ? ' queued' : '') + (MAIL_TEXT.test(text || '') ? ' mail' : ''), dataset: turn ? { turn: String(turn) } : undefined },
    el('div', { class: 'bubble', text: text + (images ? `\n[${images} 张图片]` : '') }));
  setMeta(m, queued ? '排队中…' : fmtTime(ts));
  histSink().append(m);
  return m;
}

function addAssistant(text, ts) {
  const m = el('div', { class: 'msg assistant' }, el('div', { class: 'bubble', html: md(text) }));
  if (ts) m.title = fmtTime(ts);
  histSink().append(m);
}

const TOOL_LABEL = { Bash: '运行命令', Read: '读取', Edit: '编辑', Write: '写入', MultiEdit: '编辑', Glob: '查找文件', Grep: '搜索', Task: '子任务', Agent: '子任务', WebFetch: '抓取网页', WebSearch: '网页搜索', TodoWrite: '待办', NotebookEdit: '编辑笔记本', AskUserQuestion: '提问' };

function addTool(tool, summary, id) {
  const status = el('span', { class: 't-status wait', text: '…' });
  const d = el('details', { class: 'tool msg' },
    el('summary', {},
      el('span', { class: 't-name', text: toolName(tool), title: tool }),
      el('span', { class: 't-sum', text: summary || '' }),
      status));
  d._status = status;
  histSink().append(d);
  if (id) {
    S.tools.set(id, d);
    // its result is on a newer page that is already drawn
    const r = S.toolResults.get(id);
    if (r) { S.toolResults.delete(id); setToolResult(id, r.ok, r.text); }
  }
  return d;
}

function setToolResult(id, ok, text) {
  const d = S.tools.get(id);
  if (!d) {
    if (id && S.sink) S.toolResults.set(id, { ok, text });   // its tool call is on an older page, not drawn yet
    return;
  }
  d.dataset.done = '1';
  d._status.className = `t-status ${ok ? 'ok' : 'err'}`;
  d._status.textContent = ok ? '✓' : '✗ 出错';
  const pre = $('pre', d) || d.appendChild(el('pre'));
  pre.textContent = text || '(无输出)';
}

function markToolPending(d, running) {
  d._status.className = 't-status wait';
  d._status.textContent = running ? '…' : '';
}

function addNotice(text, cls = '') {
  $('#messages').append(el('div', { class: `msg notice ${cls}`, text }));
}

function renderTurnEnd(ev) {
  const r = ev.result || {};
  let text;
  let error = false;
  if (ev.reason === 'rate_limit_rejected' || ev.reason === 'credits_required') {
    error = true;
    text = '这一轮做到一半，Claude 账号的额度用完了';
  } else if (ev.type === 'turn.interrupted') text = '已打断';
  else if (ev.type === 'turn.failed') {
    error = true;
    const errs = (ev.errors || r.errors || []).join('; ');
    text = `本轮失败：${ev.reason || r.subtype || ''}${errs ? ` — ${errs}` : ''}`;
  } else {
    const parts = [];
    if (r.duration_ms) parts.push(`用时 ${fmtDuration(Math.round(r.duration_ms / 1000))}`);
    if (r.total_cost_usd) parts.push(`$${r.total_cost_usd.toFixed(3)}`);
    if (ev.subagents_abandoned) parts.push('部分子任务未完成');
    text = `完成${parts.length ? ' · ' + parts.join(' · ') : ''}`;
  }
  $('#messages').append(el('div', { class: `msg turn-end${error ? ' error' : ''}`, text }));
}

// ---- questions (AskUserQuestion) --------------------------------------------------------

function ensureQuestion(q) {
  if (!q || S.questionCards.has(q.id)) return;
  const fieldsets = (q.questions || []).map((qq, qi) => {
    const name = `q-${q.id}-${qi}`;
    const type = qq.multiSelect ? 'checkbox' : 'radio';
    return el('fieldset', { dataset: { qi: String(qi) } },
      el('legend', { text: `${qq.header ? `【${qq.header}】` : ''}${qq.question}${qq.multiSelect ? '（可多选）' : ''}` }),
      ...(qq.options || []).map((o) => el('label', { class: 'opt' },
        el('input', { type, name, value: o.label }),
        el('span', {}, el('div', { text: o.label }), o.description ? el('div', { class: 'opt-desc', text: o.description }) : null))),
      el('input', { class: 'other', placeholder: '或者自己写答案…' }));
  });
  const deadline = el('span', { class: 'muted small' });
  const card = el('form', { class: 'msg question' },
    el('div', { class: 'q-head' }, 'Claude 在问你 ', deadline),
    ...fieldsets,
    el('div', { class: 'dialog-actions' },
      el('button', { type: 'button', class: 'small', text: '你自己决定吧', onclick: () => answer(q, card, { response: '请你自己选择最合理的方案继续，并在总结里写明你的假设。' }) }),
      el('button', { type: 'submit', class: 'primary small', text: '回答' })));
  card.addEventListener('submit', (ev) => {
    ev.preventDefault();
    const answers = {};
    (q.questions || []).forEach((qq, qi) => {
      const fs = $(`fieldset[data-qi="${qi}"]`, card);
      const other = $('.other', fs).value.trim();
      const picked = [...fs.querySelectorAll('input:checked')].map((i) => i.value);
      if (other) answers[qq.question] = other;
      else if (picked.length) answers[qq.question] = qq.multiSelect ? picked : picked[0];
    });
    if (!Object.keys(answers).length) return toast('先选一个答案', true);
    answer(q, card, { answers });
  });
  if (q.deadline_at) {
    const tick = () => {
      const left = Math.round((Date.parse(q.deadline_at) - Date.now()) / 1000);
      if (!card.isConnected || card.classList.contains('answered')) return clearInterval(timer);
      deadline.textContent = left > 0 ? `（${fmtDuration(left)}后没人回答它会自己决定）` : '';
    };
    const timer = setInterval(tick, 1000);
    tick();
  }
  S.questionCards.set(q.id, card);
  $('#messages').append(card);
  scrollBottom();
}

async function answer(q, card, body) {
  for (const b of card.querySelectorAll('button')) b.disabled = true;
  try {
    await api('POST', `/sessions/${enc(S.current)}/input`, { question_id: q.id, ...body });
    markQuestionAnswered(q.id, 'user');
  } catch (e) {
    for (const b of card.querySelectorAll('button')) b.disabled = false;
    toast(errText(e), true);
  }
}

function markQuestionAnswered(id, by) {
  const card = S.questionCards.get(id);
  if (!card || card.classList.contains('answered')) return;
  card.classList.add('answered');
  for (const i of card.querySelectorAll('input, button')) i.disabled = true;
  $('.q-head', card).textContent = by === 'user' ? '已回答' : by === 'auto' ? '没人回答，Claude 自己做了决定' : '问题已失效';
}

// ---- send mode (while Claude works) -------------------------------------------------------

/**
 * What a message sent while Claude works does (all three keep background commands and agents running):
 * now — like typing into the terminal: a tool call in flight moves to the background and Claude reads the message
 *       at once, within the same turn; while it is writing, the reply stops where it is and the message is answered next;
 * queue — after this turn (straight away when only background work is left of it);
 * interrupt — stop the turn first, then send. Used once: the next message goes back to the remembered mode.
 */
const SEND_MODES = {
  now: { button: '立即发送', hint: '像终端里一样不用等：在跑命令就把命令挪到后台、马上读这条；正在写回答就停在那儿，接着回答这条', body: { send_now: true, start_while_background: true } },
  queue: { button: '排队发送', hint: '等这一轮做完再发（主回答已出、只剩后台任务时直接开始）', body: { start_while_background: true } },
  interrupt: { button: '打断并发送', hint: '先打断当前这一轮，再发这条（只这一次）', body: { interrupt: true } },
  step: { button: '做完这一步再看', hint: '不打断它：手上这一步（一次工具调用）做完时读到这条；这一轮后面没有步骤了，就等这一轮做完再给它。没交出去之前能撤回', mail: true },
};
const SENT_HOW = {
  cut: '已送达：上一轮写到这里就停了，接着回答这条',
  backgrounded: '已送达：手上的命令挪到后台接着跑，Claude 马上读这条',
  after_step: '已送达：手上这一步做完就读这条',
};
const savedSendMode = () => { try { const m = localStorage.getItem('cab.sendMode'); return m === 'queue' || m === 'step' ? m : 'now'; } catch (e) { return 'now'; } };
let sendMode = savedSendMode();

function renderSendMode() {
  $('#sel-send').value = sendMode;
  $('#send-hint').textContent = SEND_MODES[sendMode].hint;
  $('#btn-send').textContent = $('#send-opts').hidden ? '发送' : SEND_MODES[sendMode].button;
}

$('#sel-send').addEventListener('change', (e) => {
  sendMode = SEND_MODES[e.target.value] ? e.target.value : 'now';
  if (sendMode !== 'interrupt') { try { localStorage.setItem('cab.sendMode', sendMode); } catch (err) { /* private mode */ } }
  renderSendMode();
  $('#input').focus();
});

// ---- status / header ----------------------------------------------------------------------

function updateStatus(st) {
  if (st.id !== S.current) return;
  const prev = S.status;
  S.status = st;
  $('#chat-name').textContent = displayName(st);
  // the admin also sees whose session it is and which Claude account it runs under
  $('#chat-cwd').textContent = [st.cwd + (isAdmin() && st.owner ? `（用户 ${st.owner}）` : ''), isAdmin() && st.account ? `账号 ${st.account.label}` : ''].filter(Boolean).join(' · ');
  const badge = $('#chat-state');
  badge.textContent = st.quota_wait ? '等额度' : STATE_LABEL[st.state] || st.state;
  badge.className = `badge ${st.quota_wait ? 'waiting_input' : st.state}`;

  const busy = renderBusy(st);
  renderContext(st);
  const working = st.state === 'running' || st.state === 'waiting_input';
  $('#btn-interrupt').disabled = !(working || st.woken_since || st.quota_wait);
  $('#btn-interrupt').textContent = st.quota_wait && !working ? '取消等待' : '打断';
  $('#btn-cancel').disabled = !(st.process && st.process.alive) && st.state !== 'running';
  $('#send-opts').hidden = !busy;
  renderSendMode();

  if (typeof renderChatProject === 'function') renderChatProject(st);
  if (st.pending_question) ensureQuestion(st.pending_question);
  if (prev && prev.pending_question && (!st.pending_question || st.pending_question.id !== prev.pending_question.id)) markQuestionAnswered(prev.pending_question.id, 'auto');

  syncSelects();
}

const sinceS = (iso) => (iso ? Math.max(0, Math.round((Date.now() - Date.parse(iso)) / 1000)) : null);
const TASK_TYPE = { local_bash: '命令', local_agent: '子任务', remote_agent: '远程子任务', local_workflow: '工作流', mcp_task: 'MCP 任务' };
/** The project tools (mcp__project__*) in words. */
const PROJECT_TOOL = {
  team: '看团队', board: '看看板', send: '发消息', task_create: '建任务', task_update: '改任务', task_note: '在任务上记一笔', ask_owner: '请负责人定',
  record_owner_decision: '记下负责人的决定', propose_change: '提改动', deliver: '交付文件', handover_note: '写交接说明', assign: '派活', role_propose: '提议新角色',
  spawn_worker: '开临时工', request_review: '请验收员', mission_draft: '起草值班单', mission_log: '记值班进度', mission_report: '值班收尾', mission_retro: '值班复盘',
  report: '交回结果', review_verdict: '写验收结论',
};
const toolName = (t) => TOOL_LABEL[t] || (t && t.startsWith('mcp__project__') ? `项目 · ${PROJECT_TOOL[t.slice(14)] || t.slice(14)}` : t);

/** Background work the person can see and stop: running, not Claude Code's own housekeeping. */
function runningTasks(st) {
  return ((st.subagents && st.subagents.tasks) || []).filter((t) => t.status === 'running' && !t.ambient);
}

/** The bar above the composer: what Claude is doing right now. Returns whether anything is going on. */
function renderBusy(st) {
  const tasks = runningTasks(st);
  const fg = st.foreground_tools || [];
  const busy = !!(st.state === 'running' || st.state === 'waiting_input' || st.busy_reason || st.compacting_since || st.woken_since || tasks.length);
  $('#busy').hidden = !busy;
  if (!busy) { S.tasksOpen = false; return false; }
  const parts = [];
  if (st.compacting_since) parts.push(`正在压缩对话 ${fmtDuration(sinceS(st.compacting_since))}`);
  else if (st.woken_since) parts.push(`Claude 在自己干活（后台任务做完把它叫醒了）${fmtDuration(sinceS(st.woken_since))}`);
  else if (st.quota_wait) {
    parts.push(st.quota_wait.no_account ? BUSY_LABEL.no_account : BUSY_LABEL.quota);
    if (st.quota_wait.until && !st.quota_wait.no_account) parts.push(`约 ${fmtTime(st.quota_wait.until)} 恢复`);
    if (st.turn && st.turn.queued) parts.push(`${st.turn.queued} 条消息等着发`);
    $('#busy-text').textContent = parts.join(' · ');
    $('.busy .spinner').classList.add('paused');
    $('#btn-background').hidden = true;
    $('#btn-tasks').hidden = !tasks.length;
    renderTasks(tasks);
    return true;
  } else if (st.state === 'running' || st.state === 'waiting_input' || st.busy_reason) {
    parts.push(BUSY_LABEL[st.busy_reason] || STATE_LABEL[st.state]);
    if (st.turn && st.turn.elapsed_s !== null && st.turn.elapsed_s !== undefined) parts.push(fmtDuration(st.turn.elapsed_s));
  } else parts.push('后台任务还在跑');
  if (fg.length) parts.push(`正在${[...new Set(fg.map(toolName))].join('、')}`);
  if (st.turn && st.turn.queued) parts.push(`还有 ${st.turn.queued} 条排队`);
  if (!fg.length && !st.compacting_since && st.last_event && st.last_event.summary) parts.push(st.last_event.summary);
  $('#busy-text').textContent = parts.join(' · ');
  $('.busy .spinner').classList.toggle('paused', st.state === 'waiting_input' || !!st.quota_wait);

  // Ctrl+B: only while a turn is in flight and its tool calls block it
  $('#btn-background').hidden = !(fg.length && st.state === 'running' && !(st.subagents && st.subagents.result_withheld));
  const tb = $('#btn-tasks');
  tb.hidden = !tasks.length;
  if (!tasks.length) S.tasksOpen = false;
  tb.textContent = `后台任务 ${tasks.length} ${S.tasksOpen ? '▴' : '▾'}`;
  renderTasks(tasks);
  return true;
}

function renderTasks(tasks) {
  const ul = $('#busy-tasks');
  ul.hidden = !S.tasksOpen;
  if (!S.tasksOpen) return;
  // keep rows (and their buttons) across polls: only the text changes
  const rows = new Map([...ul.children].map((li) => [li.dataset.id, li]));
  const keep = new Set();
  for (const t of tasks) {
    keep.add(t.task_id);
    let li = rows.get(t.task_id);
    if (!li) {
      li = el('li', { dataset: { id: t.task_id } },
        el('span', { class: 'bt-name' }),
        el('span', { class: 'bt-sub muted' }),
        el('button', { type: 'button', class: 'small', text: '停止', title: '只停这一个后台任务，其他的和主回答照常', onclick: () => stopTask(t) }));
      ul.append(li);
    }
    const name = t.description || t.subagent_type || t.task_id;
    $('.bt-name', li).textContent = name;
    $('.bt-name', li).title = `${name}（${t.task_id}）`;
    const sub = [TASK_TYPE[t.task_type] || t.task_type || (t.backgrounded ? '后台任务' : '子任务'), fmtDuration(sinceS(t.started_at))];
    if (t.last_tool) sub.push(`在用 ${toolName(t.last_tool)}`);
    if (t.last_summary) sub.push(t.last_summary);
    $('.bt-sub', li).textContent = sub.join(' · ');
  }
  for (const [id, li] of rows) if (!keep.has(id)) li.remove();
}

async function stopTask(t) {
  if (!confirm(`停止后台任务“${t.description || t.task_id}”？\n主回答和其他后台任务照常进行。`)) return;
  try {
    updateStatus(await api('POST', `/sessions/${enc(S.current)}/tasks/${enc(t.task_id)}/stop`, {}));
    toast('已让它停下');
  } catch (e) { toast(errText(e), true); }
}

$('#btn-tasks').addEventListener('click', () => {
  S.tasksOpen = !S.tasksOpen;
  if (S.status) renderBusy(S.status);
});

async function moveToBackground() {
  if ($('#btn-background').hidden) return;
  try {
    const r = await api('POST', `/sessions/${enc(S.current)}/background`, {});
    if (r.status) updateStatus(r.status);
    toast(r.backgrounded ? '已挪到后台接着跑，Claude 马上往下做' : '这一步挪不到后台（比如抓网页），只能等它做完');
  } catch (e) { toast(errText(e), true); }
}
$('#btn-background').addEventListener('click', moveToBackground);

const fmtTokens = (n) => (n >= 1e6 ? `${(n / 1e6).toFixed(n >= 1e7 ? 0 : 1)}M` : n >= 1000 ? `${Math.round(n / 1000)}K` : String(n));

/** How full the context is: the last request Claude Code made, over its model's window. */
function renderContext(st) {
  const c = st.context || {};
  const box = $('#chat-ctx');
  const known = typeof c.percentage === 'number';
  if (!known && !(c.tokens > 0)) { box.hidden = true; return; }
  const pct = known ? Math.max(0, Math.min(100, Math.round(c.percentage))) : 0;
  box.hidden = false;
  box.className = `ctx${pct >= 95 ? ' full' : pct >= 80 ? ' warn' : ''}`;
  $('.ctx-bar', box).hidden = !known;
  $('#chat-ctx-fill').style.width = `${pct}%`;
  $('#chat-ctx-text').textContent = known ? `上下文 ${pct}%` : `上下文 ${fmtTokens(c.tokens)} tokens`;
  const n = (x) => (typeof x === 'number' ? x.toLocaleString('zh-CN') : '?');
  box.title = known
    ? `最近一次请求用了 ${n(c.tokens)} / ${n(c.window)} tokens 的上下文。快满时 Claude Code 会自己压缩；也可以发 /compact 让它现在就压。`
    : `最近一次请求用了 ${n(c.tokens)} tokens 的上下文（这一轮结束后才知道窗口多大）。`;
}

// ---- models / effort / mode -------------------------------------------------------------------

const DEFAULT_EFFORTS = ['low', 'medium', 'high', 'xhigh', 'max'];
const EFFORT_LABEL = { low: '低', medium: '中', high: '高', xhigh: '很高', max: '最高' };

async function loadModels(force) {
  if (S.catalog && !force) return S.catalog;
  try { S.catalog = await api('GET', '/models'); } catch (e) { S.catalog = null; }
  syncSelects();
  return S.catalog;
}

function modelOptions(sel, current) {
  const models = (S.catalog && S.catalog.models) || [];
  const opts = models.map((m) => ({ value: m.value, label: m.display_name || m.value }));
  if (current && !opts.some((o) => o.value === current)) opts.unshift({ value: current, label: current });
  sel.replaceChildren(...opts.map((o) => el('option', { value: o.value, text: o.label, title: o.value })));
  if (current) sel.value = current;
}

function effortOptions(sel, model, current) {
  const m = ((S.catalog && S.catalog.models) || []).find((x) => x.value === model);
  const levels = m && m.supports_effort && m.effort_levels && m.effort_levels.length ? m.effort_levels : DEFAULT_EFFORTS;
  const all = current && !levels.includes(current) ? [current, ...levels] : levels;
  sel.replaceChildren(...all.map((v) => el('option', { value: v, text: `思考：${EFFORT_LABEL[v] || v}` })));
  if (current) sel.value = current;
}

function syncSelects() {
  const st = S.status;
  if (!st) return;
  const ms = $('#sel-model');
  const es = $('#sel-effort');
  if (document.activeElement !== ms) modelOptions(ms, st.model);
  if (document.activeElement !== es) effortOptions(es, st.model, st.effort);
  if (document.activeElement !== $('#sel-mode')) $('#sel-mode').value = st.permission_mode;
}

async function patchCurrent(body, okMsg) {
  try {
    const st = await api('PATCH', `/sessions/${enc(S.current)}`, body);
    updateStatus(st);
    if (okMsg) toast(okMsg);
    refreshSessions();
  } catch (e) {
    toast(errText(e), true);
    syncSelects();
  }
}

$('#sel-model').addEventListener('change', (e) => patchCurrent({ model: e.target.value }, '模型已切换'));
$('#sel-effort').addEventListener('change', (e) => patchCurrent({ effort: e.target.value }, '思考强度已调整（下一轮生效）'));
$('#sel-mode').addEventListener('change', (e) => patchCurrent({ permission_mode: e.target.value }, e.target.value === 'plan' ? '已切到仅规划模式（不会改文件）' : '已切到自动执行模式'));
for (const s of ['#sel-model', '#sel-effort', '#sel-mode']) $(s).addEventListener('blur', syncSelects);

$('#chat-name').addEventListener('click', () => {
  const st = S.status;
  if (!st) return;
  const name = prompt('会话名称', st.name || '');
  if (name === null) return;
  patchCurrent({ name: name.trim() || null });
});

// ---- header actions ------------------------------------------------------------------------------

$('#btn-interrupt').addEventListener('click', async () => {
  const st = S.status || {};
  const waiting = st.quota_wait && st.state !== 'running' && st.state !== 'waiting_input';
  if (waiting && !confirm('不等了？排着的消息（包括换账号后自动接着做的那条）都会撤掉。')) return;
  try {
    await api('POST', `/sessions/${enc(S.current)}/interrupt`, waiting ? { drop_queued: true } : {});
    toast(waiting ? '已取消等待' : '已打断');
    refreshSessions();
  } catch (e) { toast(errText(e), true); }
});

$('#btn-cancel').addEventListener('click', async () => {
  if (!confirm('停止当前任务并关闭 Claude Code 进程？\n会话不会丢，之后发消息会自动续上。')) return;
  try {
    updateStatus(await api('POST', `/sessions/${enc(S.current)}/cancel`, {}));
    refreshSessions();
  } catch (e) { toast(errText(e), true); }
});

$('#btn-delete').addEventListener('click', async () => {
  const st = S.status;
  if (!st) return;
  const role = st.project && st.project.kind === 'role' && !st.project.past_shift ? `\n它是项目「${st.project.name}」里角色「${st.project.role_name}」的当班：删掉后这个角色就没在班了，下次给它发消息或开班会起一个新会话（看板、消息、交接说明都还在）。` : '';
  if (!confirm(`从控制台删除会话“${displayName(st)}”？\nClaude Code 自己的会话记录会保留，以后还能从“继续历史会话”里重新接管。${role}`)) return;
  try {
    await api('DELETE', `/sessions/${enc(st.id)}?force=1`);
    closeSession();
    refreshSessions();
  } catch (e) { toast(errText(e), true); }
});

$('#btn-diff').addEventListener('click', async () => {
  const body = $('#diff-body');
  body.replaceChildren(el('p', { class: 'muted', text: '加载中…' }));
  $('#dlg-diff').showModal();
  try {
    const d = await api('GET', `/sessions/${enc(S.current)}/diff?format=patch`);
    const parts = [];
    if (!d.repo) {
      parts.push(el('p', { class: 'muted small', text: '不是 git 仓库：只能列出 Claude 改过的文件，没有具体内容。' }));
      parts.push(el('ul', {}, ...(d.files || []).map((f) => el('li', { class: 'mono small', text: f.path }))));
    } else if (!d.files || !d.files.length) {
      parts.push(el('p', { class: 'muted', text: '没有改动。' }));
    } else {
      parts.push(el('div', { class: 'diff-stat', text: d.stat }));
      const pre = el('pre', { class: 'diff-patch' });
      for (const line of (d.patch || '').split('\n')) {
        const cls = line.startsWith('+') && !line.startsWith('+++') ? 'add' : line.startsWith('-') && !line.startsWith('---') ? 'del' : line.startsWith('@@') ? 'hunk' : '';
        pre.append(el('span', { class: cls, text: line + '\n' }));
      }
      parts.push(pre);
    }
    body.replaceChildren(...parts);
  } catch (e) {
    body.replaceChildren(el('p', { class: 'error', text: errText(e) }));
  }
});

// ---- dialog: session settings ------------------------------------------------------------------------

$('#btn-settings').addEventListener('click', () => {
  const st = S.status;
  if (!st) return;
  $('#set-shared').checked = !!st.allow_shared_cwd;
  $('#set-spare').checked = !!st.spare_background;
  $('#settings-error').hidden = true;
  if (typeof fillMembership === 'function') fillMembership(st);
  $('#dlg-settings').showModal();
});

$('#form-settings').addEventListener('submit', async (e) => {
  e.preventDefault();
  const st = S.status;
  if (!st) return;
  const body = {};
  if ($('#set-shared').checked !== !!st.allow_shared_cwd) body.allow_shared_cwd = $('#set-shared').checked;
  if ($('#set-spare').checked !== !!st.spare_background) body.spare_background = $('#set-spare').checked;
  const membership = typeof saveMembership === 'function' ? saveMembership(st) : null;
  if (!Object.keys(body).length && !membership) return $('#dlg-settings').close();
  try {
    if (membership) { await membership(); toast('项目身份改好了：下一轮起生效'); }
    if (Object.keys(body).length) updateStatus(await api('PATCH', `/sessions/${enc(st.id)}`, body));
    else updateStatus(await api('GET', `/sessions/${enc(st.id)}`));
    $('#dlg-settings').close();
    toast(body.spare_background !== undefined && st.process && st.process.alive ? '已保存（“打断时后台任务接着跑”下次启动进程时生效）' : '已保存');
    refreshSessions();
  } catch (ex) {
    $('#settings-error').textContent = errText(ex);
    $('#settings-error').hidden = false;
  }
});

// ---- composer ---------------------------------------------------------------------------------------

const input = $('#input');

function autosize() {
  input.style.height = 'auto';
  input.style.height = Math.min(input.scrollHeight + 2, window.innerHeight * 0.4) + 'px';
}
input.addEventListener('input', autosize);
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
    e.preventDefault();
    $('#composer').requestSubmit();
  } else if (e.key === 'b' && e.ctrlKey && !e.altKey && !e.metaKey && !$('#btn-background').hidden) {
    e.preventDefault(); // Ctrl+B, as in the terminal
    moveToBackground();
  }
});

$('#composer').addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text || !S.current) return;
  const id = S.current;
  const images = S.attachments.map((a) => ({ path: a.path }));
  const st = S.status || {};
  const btn = $('#btn-send');
  btn.disabled = true;
  try {
    let turn;
    let queued = false;
    let how;
    if (st.state === 'cancelled' || st.state === 'failed') {
      if (images.length) {
        await api('POST', `/sessions/${enc(id)}/resume`, {});
        const r = await api('POST', `/sessions/${enc(id)}/messages`, { text, images });
        turn = r.turn;
        queued = r.queued;
      } else {
        const r = await api('POST', `/sessions/${enc(id)}/resume`, { text });
        turn = r.turn && r.turn.n;
      }
    } else if (!$('#send-opts').hidden && SEND_MODES[sendMode].mail) {
      // after this step: the mailbox holds it (cancellable) until Claude's next tool call, or the end of the turn
      const r = await api('POST', `/sessions/${enc(id)}/mail`, { text, images: images.map((x) => x.path) });
      const m = addUser(text, { queued: true, images: images.length || undefined });
      m.dataset.mail = String(r.id);
      setMeta(m, '');
      m.querySelector('.meta').append('等它做完手上这一步… ', el('button', { type: 'button', class: 'link small', text: '撤回', onclick: async (ev2) => {
        try { await api('POST', `/mail/${r.id}/cancel`, {}); m.remove(); input.value = text; autosize(); toast('撤回了，原话放回输入框'); }
        catch (err2) { toast(errText(err2), true); ev2.target.remove(); }
      } }));
      scrollBottom();
    } else {
      // the options only show while Claude works; when it does not, every mode is a plain send
      const r = await api('POST', `/sessions/${enc(id)}/messages`, { text, images, ...($('#send-opts').hidden ? {} : SEND_MODES[sendMode].body) });
      turn = r.turn;
      queued = r.queued;
      how = r.how;
    }
    if (S.current === id && turn && !S.startedTurns.has(turn) && !$(`#messages .msg.user[data-turn="${turn}"]`)) {
      const m = addUser(text, { turn, queued: true, images: images.length || undefined });
      if (how) { m.classList.remove('queued'); setMeta(m, SENT_HOW[how] || '已送达'); }
      else if (!queued) setMeta(m, '');
      scrollBottom();
    }
    input.value = '';
    autosize();
    S.attachments = [];
    renderAttachments();
    if (sendMode === 'interrupt') { sendMode = savedSendMode(); renderSendMode(); }
    refreshSessions();
  } catch (err) {
    toast(errText(err), true);
  } finally {
    btn.disabled = false;
  }
});

function renderAttachments() {
  const box = $('#attachments');
  box.hidden = S.attachments.length === 0;
  box.replaceChildren(...S.attachments.map((a, i) => el('div', { class: 'att' },
    el('img', { src: a.url, alt: '' }),
    el('button', { type: 'button', title: '移除', text: '✕', onclick: () => { URL.revokeObjectURL(a.url); S.attachments.splice(i, 1); renderAttachments(); } }))));
}

async function addImage(file) {
  if (!/^image\/(png|jpeg|gif|webp)$/.test(file.type)) return toast('只支持 png / jpg / gif / webp 图片', true);
  const ext = { 'image/png': '.png', 'image/jpeg': '.jpg', 'image/gif': '.gif', 'image/webp': '.webp' }[file.type];
  const data = await new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = () => rej(r.error);
    r.readAsDataURL(file);
  });
  try {
    const up = await api('POST', '/uploads', { name: `image${ext}`, data });
    S.attachments.push({ path: up.path, url: URL.createObjectURL(file) });
    renderAttachments();
  } catch (e) { toast(errText(e), true); }
}

input.addEventListener('paste', (e) => {
  const files = [...(e.clipboardData ? e.clipboardData.files : [])].filter((f) => f.type.startsWith('image/'));
  if (!files.length) return;
  e.preventDefault();
  for (const f of files) addImage(f);
});
$('#file-input').addEventListener('change', (e) => {
  for (const f of e.target.files) addImage(f);
  e.target.value = '';
});

// ---- dialogs: shared ---------------------------------------------------------------------------------

for (const d of document.querySelectorAll('dialog')) {
  d.addEventListener('click', (e) => { if (e.target.matches('[data-close]')) d.close(); });
}

// ---- dialog: new session ------------------------------------------------------------------------------

$('#btn-new').addEventListener('click', async () => {
  const f = $('#form-new');
  f.reset();
  $('#new-error').hidden = true;
  $('#browser').hidden = true;
  // always from the root of what one may use (a user's directory, the admin's users root), not the last folder: a
  // user whose last session was in a remote directory gets back to their own directory this way ("在这里新建会话"
  // in the remote directories dialog fills it in right after)
  $('#new-cwd').value = '';
  $('#dlg-new').showModal();
  closeSidebarMobile();
  try {
    const d = await api('GET', '/fs/dirs');
    if (!$('#new-cwd').value) $('#new-cwd').value = d.home;
    $('#recent-cwds').replaceChildren(...d.recent.map((p) => el('button', { type: 'button', text: p, title: p, onclick: () => { $('#new-cwd').value = p; } })));
  } catch (e) { /* optional */ }
  const cat = await loadModels();
  const defModel = (cat && cat.defaults && cat.defaults.model) || 'opus[1m]';
  const defEffort = (cat && cat.defaults && cat.defaults.effort) || 'xhigh';
  modelOptions($('#new-model'), defModel);
  effortOptions($('#new-effort'), defModel, defEffort);
  if (typeof fillProjectSelect === 'function') fillProjectSelect($('#new-project'), $('#new-project-row'), $('#new-cwd').value);
});
$('#new-cwd').addEventListener('change', () => { if (typeof fillProjectSelect === 'function') fillProjectSelect($('#new-project'), $('#new-project-row'), $('#new-cwd').value, true); });

$('#new-model').addEventListener('change', (e) => effortOptions($('#new-effort'), e.target.value, $('#new-effort').value));

$('#btn-browse').addEventListener('click', () => {
  const b = $('#browser');
  b.hidden = !b.hidden;
  if (!b.hidden) browse($('#new-cwd').value);
});
$('#browser-hidden').addEventListener('change', () => browse($('#browser-path').textContent));
$('#browser-up').addEventListener('click', () => {
  const up = $('#browser-up').dataset.parent;
  if (up) browse(up);
});

async function browse(path) {
  try {
    const d = await api('GET', `/fs/dirs?path=${enc(path || '')}${$('#browser-hidden').checked ? '&hidden=1' : ''}`);
    $('#browser-path').textContent = d.path;
    $('#new-cwd').value = d.path;
    if (typeof fillProjectSelect === 'function') fillProjectSelect($('#new-project'), $('#new-project-row'), d.path, true);
    $('#browser-up').dataset.parent = d.parent || '';
    $('#browser-up').disabled = !d.parent;
    $('#browser-list').replaceChildren(...d.dirs.map((n) => el('li', { text: `📁 ${n}`, onclick: () => browse(`${d.path.replace(/\/$/, '')}/${n}`) })));
    if (!d.dirs.length) $('#browser-list').append(el('li', { class: 'muted', text: '（没有子目录）' }));
  } catch (e) {
    toast(errText(e), true);
  }
}

$('#form-new').addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = $('#new-error');
  err.hidden = true;
  const cwd = $('#new-cwd').value.trim();
  const prompt = $('#new-prompt').value.trim();
  const body = {
    cwd,
    name: $('#new-name').value.trim() || uniqueName(prompt ? prompt.split('\n')[0].slice(0, 24) : basename(cwd)),
    model: $('#new-model').value || undefined,
    effort: $('#new-effort').value || undefined,
    permission_mode: $('#new-mode').value,
    allow_shared_cwd: $('#new-shared').checked,
    spare_background: $('#new-spare').checked,
    unique_name: true, // other users' sessions are not in this list, but their names are taken too
  };
  const project = $('#new-project').value;
  // a session joining a project joins before its first turn, so that turn already has the project card and tools
  if (prompt && !project) body.prompt = prompt;
  $('#btn-create').disabled = true;
  try {
    const st = await api('POST', '/sessions', body);
    if (project) {
      await api('POST', `/projects/${enc(project)}/sessions`, { session: st.id });
      if (prompt) await api('POST', `/sessions/${enc(st.id)}/messages`, { text: prompt });
    }
    $('#dlg-new').close();
    await refreshSessions();
    openSession(st.id);
  } catch (ex) {
    err.textContent = errText(ex);
    err.hidden = false;
  } finally {
    $('#btn-create').disabled = false;
  }
});

// ---- dialog: continue a previous session ------------------------------------------------------------------

let historyRows = [];

$('#btn-history').addEventListener('click', async () => {
  $('#history-filter').value = '';
  $('#history-list').replaceChildren(el('li', { class: 'muted', text: '加载中…' }));
  $('#dlg-history').showModal();
  closeSidebarMobile();
  try {
    historyRows = await api('GET', '/claude-sessions?limit=300');
    renderHistoryRows();
  } catch (e) {
    $('#history-list').replaceChildren(el('li', { class: 'error', text: errText(e) }));
  }
});
$('#history-filter').addEventListener('input', renderHistoryRows);

function renderHistoryRows() {
  const q = $('#history-filter').value.trim().toLowerCase();
  const rows = historyRows.filter((c) => !q || [c.title, c.first_prompt, c.last_prompt, c.cwd].some((v) => v && v.toLowerCase().includes(q)));
  const ul = $('#history-list');
  ul.replaceChildren(...rows.map((c) => {
    let action;
    if (c.bridge) action = el('button', { text: '打开', onclick: () => { $('#dlg-history').close(); openSession(c.id); } });
    else if (c.held_by_terminal) action = el('button', { disabled: true, text: '终端占用中', title: '先在终端里退出这个 claude 会话' });
    else action = el('button', { class: 'primary', text: '接管并继续', onclick: (e) => adopt(c, e.target) });
    const title = c.title || c.first_prompt || c.id;
    const sub = [c.cwd || '(目录未知)', fmtAgo(c.updated_at), c.active_recently ? '⚠ 可能正在终端中使用' : null, c.bridge ? `控制台里：${c.bridge.name || ''} ${STATE_LABEL[c.bridge.state] || ''}` : null].filter(Boolean).join(' · ');
    return el('li', {},
      el('div', { class: 'h-main' },
        el('div', { class: 'h-title', text: title, title }),
        c.last_prompt && c.last_prompt !== title ? el('div', { class: 'h-sub', text: `最后：${c.last_prompt}`, title: c.last_prompt }) : null,
        el('div', { class: 'h-sub mono', text: sub, title: c.cwd || '' })),
      action);
  }));
  if (!rows.length) ul.append(el('li', { class: 'muted', text: historyRows.length ? '没有匹配的会话' : '这台机器上还没有 Claude Code 会话记录' }));
}

async function adopt(c, btn) {
  if (c.active_recently && !confirm('这个会话在最近两分钟内还有写入，可能还开在某个终端里。\n两边同时用同一个会话会把记录写乱。确定已经在终端退出了吗？')) return;
  let cwd = c.cwd;
  if (!cwd) {
    cwd = prompt('这个会话记录里没有工作目录，请输入：');
    if (!cwd) return;
  }
  btn.disabled = true;
  try {
    const st = await api('POST', '/sessions', { cwd, adopt_claude_session_id: c.id, name: uniqueName(c.title || c.first_prompt || basename(cwd)), unique_name: true, spare_background: true });
    $('#dlg-history').close();
    await refreshSessions();
    openSession(st.id);
    toast('已接管，发消息就会带着之前的上下文继续');
  } catch (e) {
    btn.disabled = false;
    toast(errText(e), true);
  }
}

// ---- dialog: files (browse, upload, download) -----------------------------------------------------------

const F = { path: null, want: '', parent: null, upload: null };
const UPLOAD_PARALLEL = 3;

function fmtSize(n) {
  if (n === null || n === undefined) return '';
  if (n < 1024) return `${n} B`;
  const units = ['KB', 'MB', 'GB', 'TB'];
  let v = n / 1024;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return `${v < 10 ? v.toFixed(1) : Math.round(v)} ${units[i]}`;
}

function fmtDate(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.getFullYear() === new Date().getFullYear() ? fmtTime(iso) : `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

/** Upload / new folder need a listed directory to put things in. */
function needDir() {
  if (F.path) return true;
  toast('目录还没列出来，没法上传或新建：先解决列表里显示的错误，再点 ⟳ 重试', true);
  return false;
}

const joinPath = (dir, name) => `${dir.replace(/\/+$/, '')}/${name}`;
const downloadUrl = (path) => `/fs/download?path=${enc(path)}`;
const relTo = (base, p) => {
  const b = base.replace(/\/+$/, '');
  return p.startsWith(`${b}/`) ? p.slice(b.length + 1) : p;
};

function openFiles(path, { root = false } = {}) {
  $('#files-cwd').hidden = !S.status;
  $('#dlg-files').showModal();
  closeSidebarMobile();
  renderUploadProgress();
  // '' = where the server starts one (their directory)
  listFiles(root ? '' : path || F.path || '');
}

$('#btn-files').addEventListener('click', () => openFiles(S.status && S.status.cwd));
// the sidebar's "文件": the root of what one may use first (the session's own button opens its working directory)
$('#btn-files-side').addEventListener('click', () => openFiles('', { root: true }));
$('#files-cwd').addEventListener('click', () => { if (S.status) listFiles(S.status.cwd); });
$('#files-up').addEventListener('click', () => { if (F.parent) listFiles(F.parent); });
$('#files-refresh').addEventListener('click', () => listFiles(F.path || F.want));
$('#files-hidden').addEventListener('change', () => listFiles(F.path));
$('#files-path').addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  e.preventDefault();
  listFiles($('#files-path').value.trim());
});

let listSeq = 0;
async function listFiles(path) {
  const seq = ++listSeq;
  F.want = path || '';
  let d;
  try {
    d = await api('GET', `/fs/list?path=${enc(path || '')}${$('#files-hidden').checked ? '&hidden=1' : ''}`);
  } catch (e) {
    if (seq !== listSeq) return;
    if (F.path) { toast(errText(e), true); $('#files-path').value = F.path; }
    else $('#files-list').replaceChildren(el('li', { class: 'note error', text: errText(e) }));
    return;
  }
  if (seq !== listSeq) return;
  F.path = d.path;
  F.parent = d.parent;
  F.remote = !!d.remote;
  $('#files-path').value = d.path;
  $('#files-up').disabled = !d.parent;
  $('#files-zip').href = downloadUrl(d.path);
  renderFiles(d);
}

function renderFiles(d) {
  const rows = d.entries.map((e) => {
    const p = joinPath(d.path, e.name);
    const dir = e.type === 'dir';
    const icon = dir ? '📁' : e.type === 'file' ? '📄' : '·';
    const file = e.type === 'file';
    return el('li', { class: dir ? 'dir' : file ? 'file' : '', title: p, onclick: dir ? () => listFiles(p) : file ? () => openPreview(p, e.size) : undefined },
      el('span', { class: 'f-name', text: `${icon} ${e.name}${e.symlink ? ' ↗' : ''}` }),
      el('span', { class: 'f-size', text: dir ? '' : fmtSize(e.size) }),
      el('span', { class: 'f-time', text: fmtDate(e.mtime) }),
      el('span', { class: 'f-actions', onclick: (ev) => ev.stopPropagation() },
        file ? el('button', { type: 'button', class: 'small', text: '预览', title: '在页面里打开看看', onclick: () => openPreview(p, e.size) }) : null,
        e.type === 'file' && S.status ? el('button', { type: 'button', class: 'small', text: '引用', title: '把这个路径插入到消息输入框', onclick: () => insertPath(p) }) : null,
        dir || e.type === 'file' ? el('a', { class: 'btn small', href: downloadUrl(p), download: true, text: dir ? '下载 .zip' : '下载' }) : null,
        // not in a remote directory: those are the originals on someone's computer (the server refuses it too)
        d.remote ? null : el('button', { type: 'button', class: 'small danger', text: '删除', title: dir && !e.symlink ? '删除这个文件夹和里面的所有内容' : '删除', onclick: () => deleteEntry(p, e) })));
  });
  if (d.total > d.entries.length) rows.push(el('li', { class: 'note', text: `只显示了前 ${d.entries.length} 项（共 ${d.total} 项）` }));
  if (!d.entries.length) rows.push(el('li', { class: 'note', text: '空目录。点“上传文件 / 上传文件夹”，或者把文件、文件夹拖到这里' }));
  $('#files-list').replaceChildren(...rows);
}

/** Delete one entry of the list (a folder with everything in it), after saying what that means. */
async function deleteEntry(path, e) {
  const link = !!e.symlink;
  const what = link ? '链接' : e.type === 'dir' ? '文件夹' : '文件';
  const notes = [];
  if (link) notes.push('只删除这个链接，不动它指向的东西。');
  else if (e.type === 'dir') notes.push('文件夹里的所有内容会一起删除。');
  const inside = (cwd) => cwd === path || (cwd || '').startsWith(`${path}/`);
  const affected = (S.sessions || []).filter((s) => inside(s.cwd)).map((s) => s.name || s.id.slice(0, 8));
  if (affected.length) notes.push(`这是会话「${affected.slice(0, 3).join('」「')}」${affected.length > 3 ? ` 等 ${affected.length} 个会话` : ''}的工作目录：之后再用这些会话时，会自动重建一个空文件夹。`);
  if (!confirm(`删除${what}「${e.name}」？\n${notes.join('\n')}${notes.length ? '\n' : ''}删除后不能恢复。`)) return;
  try {
    await api('POST', '/fs/delete', { path });
    toast(`已删除 ${e.name}`);
  } catch (err) {
    toast(err && err.code === 'cwd_busy' ? `${err.message}：等它这一轮结束（或打断它）再删` : errText(err), true);
  }
  listFiles(F.path);
}

// ---- dialog: file preview ------------------------------------------------------------------------------

const PREVIEW_TEXT_MAX = 1024 * 1024;
const PREVIEW_MODEL_MAX = 100 * 1024 * 1024; // parsing and uploading more than this to the GPU gets slow
const previewUrl = (path) => `/fs/preview?path=${enc(path)}`;
let previewAbort = null;
let previewView = null; // an STL viewer holding a GL context

function closePreviewView() {
  if (previewView) previewView.destroy();
  previewView = null;
}

/**
 * The server says what a file is (by its type): images, audio, video and PDF the browser shows from the
 * URL itself; an STL model is fetched whole and drawn by web/stl.js; anything else is text, of which only the first MB is fetched and decoded here (UTF-8,
 * else GB18030), and a file with NUL bytes in it counts as binary.
 */
async function openPreview(path, size) {
  if (previewAbort) previewAbort.abort();
  closePreviewView();
  const ctrl = (previewAbort = new AbortController());
  const body = $('#preview-body');
  const note = (text, error) => body.replaceChildren(el('p', { class: error ? 'note error' : 'note', text }));
  $('#preview-name').textContent = path.split('/').pop();
  $('#preview-name').title = path;
  $('#preview-info').textContent = fmtSize(size);
  $('#preview-download').href = downloadUrl(path);
  note('加载中…');
  if (!$('#dlg-preview').open) $('#dlg-preview').showModal();
  let res;
  try {
    res = await fetch(previewUrl(path), { credentials: 'same-origin', headers: { range: `bytes=0-${PREVIEW_TEXT_MAX - 1}` }, signal: ctrl.signal });
  } catch (e) {
    if (!ctrl.signal.aborted) note('连不上服务（服务停了，或者端口转发断了）', true);
    return;
  }
  if (!res.ok) {
    const err = ((await res.json().catch(() => null)) || {}).error || {};
    if (res.status === 401) showLogin();
    if (!ctrl.signal.aborted) note(errText(new ApiError(res.status, err.code, err.message || `HTTP ${res.status}`, err.hint)), true);
    return;
  }
  const type = (res.headers.get('content-type') || '').split(';')[0];
  const kind = type === 'application/pdf' ? 'pdf' : type.split('/')[0];
  const total = Number((res.headers.get('content-range') || '').split('/')[1]) || Number(res.headers.get('content-length')) || 0;
  if (kind === 'model') {
    res.body.cancel().catch(() => {});
    if (total > PREVIEW_MODEL_MAX) return note(`模型太大（${fmtSize(total)}，超过 ${fmtSize(PREVIEW_MODEL_MAX)}），在页面里打开会很慢，请下载下来看`);
    let buf;
    try {
      const whole = await fetch(previewUrl(path), { credentials: 'same-origin', signal: ctrl.signal });
      if (!whole.ok) throw new Error(`HTTP ${whole.status}`);
      buf = await readWithProgress(whole, (got, all) => note(`加载模型… ${fmtSize(got)} / ${fmtSize(all)}`));
    } catch (e) {
      if (!ctrl.signal.aborted) note(String(e.message || e), true);
      return;
    }
    if (ctrl.signal.aborted) return;
    try { previewView = StlViewer.show(body, buf); } catch (e) { note(String(e.message || e), true); }
    return;
  }
  if (kind !== 'text') {
    ctrl.abort(); // the element below fetches it again, whole (and by range, for seeking)
    const url = previewUrl(path);
    const media = kind === 'image' ? el('img', { src: url, alt: path })
      : kind === 'video' ? el('video', { src: url, controls: true, autoplay: true })
      : kind === 'audio' ? el('audio', { src: url, controls: true, autoplay: true })
      : el('iframe', { src: url, title: path });
    media.addEventListener('error', () => note('浏览器打不开这个文件（格式或编码不支持），可以下载下来看', true));
    body.replaceChildren(media);
    return;
  }
  let buf;
  try { buf = new Uint8Array(await res.arrayBuffer()); } catch (e) { if (!ctrl.signal.aborted) note(String(e.message || e), true); return; }
  if (ctrl.signal.aborted) return;
  const cut = total > buf.length;
  if (buf.subarray(0, 8192).includes(0)) return note('这是二进制文件，没法在页面里预览，可以下载下来看');
  const pre = el('pre', { text: decodeText(buf, cut) });
  body.replaceChildren(pre);
  if (cut) body.append(el('p', { class: 'note', text: `只显示了开头 ${fmtSize(buf.length)}（共 ${fmtSize(total)}），完整内容请下载` }));
}

/** A response body as an ArrayBuffer, reporting bytes as they arrive. */
async function readWithProgress(res, onProgress) {
  const all = Number(res.headers.get('content-length')) || 0;
  const reader = res.body.getReader();
  const parts = [];
  let got = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    parts.push(value);
    got += value.length;
    onProgress(got, all || got);
  }
  const out = new Uint8Array(got);
  let at = 0;
  for (const p of parts) { out.set(p, at); at += p.length; }
  return out.buffer;
}

/** UTF-8 if it is (a cut-off tail of up to 3 bytes forgiven), else GB18030, which never fails. */
function decodeText(buf, cut) {
  for (let k = 0; k <= (cut ? 3 : 0); k++) {
    try { return new TextDecoder('utf-8', { fatal: true }).decode(buf.subarray(0, buf.length - k)); } catch {}
  }
  return new TextDecoder('gb18030').decode(buf);
}

// Closing stops a playing video and an unfinished fetch.
$('#dlg-preview').addEventListener('close', () => {
  if (previewAbort) previewAbort.abort();
  previewAbort = null;
  closePreviewView();
  $('#preview-body').replaceChildren();
});

/** Put a path (relative to the session's cwd when inside it) at the caret in the message box. */
function insertPath(p) {
  let ref = S.status ? relTo(S.status.cwd, p) : p;
  if (/\s/.test(ref)) ref = `"${ref}"`;
  const start = input.selectionStart ?? input.value.length;
  const end = input.selectionEnd ?? start;
  const before = input.value.slice(0, start);
  input.setRangeText(`${before && !/\s$/.test(before) ? ' ' : ''}${ref} `, start, end, 'end');
  autosize();
  toast(`已插入 ${ref}`);
}

$('#files-mkdir').addEventListener('click', async () => {
  if (!needDir()) return;
  const name = (prompt('新文件夹名称') || '').trim();
  if (!name) return;
  if (name.includes('/') || name === '.' || name === '..') return toast('名称里不能有 /', true);
  try {
    const r = await api('POST', '/fs/mkdir', { path: joinPath(F.path, name) });
    toast(r.created ? `已创建 ${name}` : `${name} 已经存在`);
    listFiles(F.path);
  } catch (e) { toast(errText(e), true); }
});

$('#files-upload').addEventListener('click', () => { if (needDir()) $('#files-pick').click(); });
$('#files-upload-dir').addEventListener('click', () => { if (needDir()) $('#files-pick-dir').click(); });
$('#files-pick').addEventListener('change', (e) => {
  const items = [...e.target.files].map((f) => ({ file: f, rel: f.name }));
  e.target.value = '';
  uploadFiles(items, []);
});
$('#files-pick-dir').addEventListener('change', (e) => {
  const items = [...e.target.files].map((f) => ({ file: f, rel: f.webkitRelativePath || f.name }));
  e.target.value = '';
  uploadFiles(items, []);
});

const dropZone = $('#files-drop');
const draggingFiles = (e) => !!e.dataTransfer && [...e.dataTransfer.types].includes('Files');
dropZone.addEventListener('dragover', (e) => {
  if (!draggingFiles(e)) return;
  e.preventDefault();
  e.dataTransfer.dropEffect = 'copy';
  dropZone.classList.add('over');
});
dropZone.addEventListener('dragleave', (e) => { if (!dropZone.contains(e.relatedTarget)) dropZone.classList.remove('over'); });
dropZone.addEventListener('drop', async (e) => {
  if (!draggingFiles(e)) return;
  e.preventDefault();
  dropZone.classList.remove('over');
  // Entries are only reachable while the event is dispatched; walk them afterwards.
  const entries = [...e.dataTransfer.items].filter((i) => i.kind === 'file').map((i) => (i.webkitGetAsEntry ? i.webkitGetAsEntry() : null));
  const plain = [...e.dataTransfer.files];
  if (!entries.length || entries.some((x) => !x)) return uploadFiles(plain.map((f) => ({ file: f, rel: f.name })), []);
  const items = [];
  const dirs = [];
  try {
    for (const en of entries) await walkEntry(en, '', items, dirs);
  } catch (err) {
    return toast(`读取拖进来的文件失败：${err && err.message ? err.message : err}`, true);
  }
  uploadFiles(items, dirs);
});
// A file dropped anywhere else would make the browser navigate away to it.
window.addEventListener('dragover', (e) => {
  if (!draggingFiles(e) || e.defaultPrevented) return;
  e.preventDefault();
  e.dataTransfer.dropEffect = 'none';
});
window.addEventListener('drop', (e) => { if (draggingFiles(e) && !e.defaultPrevented) e.preventDefault(); });

/** A dropped FileSystemEntry → files (with their relative paths) and empty folders. */
async function walkEntry(entry, prefix, items, dirs) {
  const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
  if (entry.isFile) {
    items.push({ file: await new Promise((res, rej) => entry.file(res, rej)), rel });
    return;
  }
  if (!entry.isDirectory) return;
  const reader = entry.createReader();
  let empty = true;
  for (;;) {
    const batch = await new Promise((res, rej) => reader.readEntries(res, rej));
    if (!batch.length) break;
    empty = false;
    for (const child of batch) await walkEntry(child, rel, items, dirs);
  }
  if (empty) dirs.push(rel);
}

/** items: [{ file, rel }] relative to the listed directory; dirs: empty folders to create there. */
async function uploadFiles(items, dirs) {
  if (F.upload) return toast('上一批还在上传，等它传完再来', true);
  if (!needDir()) return;
  const base = F.path;
  const clean = (rel) => rel.split('/').filter((s) => s && s !== '.' && s !== '..').join('/');
  let jobs = items.filter((it) => clean(it.rel)).map((it) => ({ file: it.file, path: joinPath(base, clean(it.rel)) }));
  const mkdirs = dirs.map(clean).filter(Boolean).map((r) => joinPath(base, r));
  if (!jobs.length && !mkdirs.length) return;
  let overwrite = false;
  if (jobs.length) {
    let existing;
    try {
      existing = (await api('POST', '/fs/exists', { paths: jobs.map((j) => j.path) })).existing;
    } catch (e) { return toast(errText(e), true); }
    if (existing.length) {
      const choice = await askConflict(existing, base);
      if (choice === 'cancel') return;
      if (choice === 'overwrite') overwrite = true;
      else {
        const skip = new Set(existing.map((x) => x.path));
        jobs = jobs.filter((j) => !skip.has(j.path));
      }
    }
  }
  const up = { total: jobs.reduce((n, j) => n + j.file.size, 0), count: jobs.length, done: 0, ok: 0, bytes: 0, live: new Map(), failed: [], aborted: false };
  F.upload = up;
  renderUploadProgress();
  for (const d of mkdirs) {
    try { await api('POST', '/fs/mkdir', { path: d }); } catch (e) { up.failed.push(`${relTo(base, d)}：${errText(e)}`); }
  }
  let next = 0;
  const worker = async () => {
    while (!up.aborted && next < jobs.length) {
      const j = jobs[next++];
      try {
        await putFile(j, overwrite, up);
        up.ok++;
      } catch (e) {
        if (!up.aborted) up.failed.push(`${relTo(base, j.path)}：${e.message}`);
      }
      up.done++;
      renderUploadProgress();
    }
  };
  await Promise.all(Array.from({ length: Math.min(UPLOAD_PARALLEL, jobs.length) }, worker));
  F.upload = null;
  renderUploadProgress();
  if (up.aborted) toast(`已取消，传完了 ${up.ok} 个文件`, true);
  else if (up.failed.length) toast(`${up.failed.length} 项没传上去：\n${up.failed.slice(0, 3).join('\n')}${up.failed.length > 3 ? '\n…' : ''}`, true);
  else toast(`已上传 ${up.ok} 个文件${mkdirs.length ? `和 ${mkdirs.length} 个空文件夹` : ''}到 ${base}`);
  if ($('#dlg-files').open && F.path === base) listFiles(base);
}

/** XHR rather than fetch: it reports upload progress. The body is the raw file, any size. */
function putFile(job, overwrite, up) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const mtime = job.file.lastModified ? `&mtime_ms=${job.file.lastModified}` : '';
    xhr.open('PUT', `/fs/file?path=${enc(job.path)}${overwrite ? '&overwrite=1' : ''}${mtime}`);
    xhr.setRequestHeader('content-type', 'application/octet-stream');
    up.live.set(xhr, 0);
    const settle = (fn, arg) => { up.live.delete(xhr); fn(arg); };
    xhr.upload.onprogress = (e) => { up.live.set(xhr, e.loaded); renderUploadProgress(); };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        up.bytes += job.file.size;
        return settle(resolve);
      }
      if (xhr.status === 401) showLogin();
      let msg = `HTTP ${xhr.status}`;
      try { msg = JSON.parse(xhr.responseText).error.message || msg; } catch (e) { /* not JSON */ }
      settle(reject, new Error(msg));
    };
    xhr.onerror = () => settle(reject, new Error('网络错误（连接断了？）'));
    xhr.onabort = () => settle(reject, new Error('已取消'));
    xhr.send(job.file);
  });
}

function renderUploadProgress() {
  const up = F.upload;
  $('#files-progress').hidden = !up;
  if (!up) return;
  let sent = up.bytes;
  for (const v of up.live.values()) sent += v;
  $('#files-bar').value = up.total ? Math.min(1, sent / up.total) : up.count ? up.done / up.count : 0;
  $('#files-progress-text').textContent = `上传中 ${up.done}/${up.count} 个文件 · ${fmtSize(sent)} / ${fmtSize(up.total)}`;
}

$('#files-abort').addEventListener('click', () => {
  const up = F.upload;
  if (!up) return;
  up.aborted = true;
  for (const x of up.live.keys()) x.abort();
});

window.addEventListener('beforeunload', (e) => {
  if (!F.upload) return;
  e.preventDefault();
  e.returnValue = '';
});

/** Same-named files already there → 'overwrite' | 'skip' | 'cancel'. */
function askConflict(existing, base) {
  const d = $('#dlg-conflict');
  $('#conflict-text').textContent = `${existing.length} 个文件在 ${base} 里已经有了：`;
  const rows = existing.slice(0, 10).map((x) => el('li', { class: 'mono small', text: `${relTo(base, x.path)}${x.type === 'dir' ? '（这是个文件夹，覆盖不了）' : ''}` }));
  if (existing.length > 10) rows.push(el('li', { class: 'muted small', text: `……还有 ${existing.length - 10} 个` }));
  $('#conflict-list').replaceChildren(...rows);
  d.returnValue = '';
  d.showModal();
  return new Promise((resolve) => d.addEventListener('close', () => resolve(d.returnValue || 'cancel'), { once: true }));
}

// ---- dialog: remote directories ----------------------------------------------------------------------------

let mountsTimer = null;

$('#btn-mounts').addEventListener('click', () => {
  $('#mounts-list').replaceChildren(el('li', { class: 'muted small', text: '加载中…' }));
  $('#dlg-mounts').showModal();
  closeSidebarMobile();
  loadMounts();
  renderShares();
  clearInterval(mountsTimer);
  mountsTimer = setInterval(loadMounts, 3000);
});
$('#dlg-mounts').addEventListener('close', () => { clearInterval(mountsTimer); mountsTimer = null; });

async function loadMounts() {
  let d;
  try { d = await api('GET', '/mounts'); } catch (e) {
    $('#mounts-list').replaceChildren(el('li', { class: 'error', text: errText(e) }));
    return;
  }
  lastMounts = d.mounts;
  diskCacheCfg = d.disk_cache || null;
  $('#bshare-disk-opt').hidden = !diskCacheCfg;
  if (diskCacheCfg) $('#bshare-disk-opt').title = `勾上（默认）：读过的文件在服务器磁盘上留一份副本（每个文件夹最多 ${fmtSize(diskCacheCfg.mb * 1024 * 1024)}），断开重连后不用再从你电脑取，只有你电脑上改过的才重新传。副本在下面“移除”这个文件夹时删掉${diskCacheCfg.days > 0 ? `，${diskCacheCfg.days} 天没再共享也会自动删掉` : ''}。不勾：只放在服务器内存里，断开就清掉，每次重连都要重新从你电脑取，会慢。`;
  $('#bshare').hidden = !d.available;
  $('#mounts-unavailable').hidden = d.available;
  $('#mounts-unavailable').textContent = d.available ? '' : `这台服务器现在用不了远程目录：${d.reason}`;
  const admin = S.me && S.me.admin;
  const ul = $('#mounts-list');
  ul.replaceChildren(...d.mounts.map((x) => {
    const online = x.state === 'online';
    const from = [x.client.host, x.client.dir].filter(Boolean).join(' · ');
    return el('li', {},
      el('div', { class: 'u-main' },
        el('span', { class: 'u-name' }, `${x.name} `, el('span', { class: `badge ${x.state}`, text: online ? '已连接' : '连接中' }), x.read_only ? el('span', { class: 'badge', text: '只读' }) : null, ...shareBadges(x.git_context, x.prefetch, x.disk_cache)),
        el('span', { class: 'u-sub mono', text: x.path, title: x.path }),
        el('span', { class: 'u-sub', text: [admin ? (x.owner ? `用户 ${x.owner}` : '管理员') : null, from ? `来自 ${from}` : null, `连接于 ${fmtTime(x.connected_at)}`].filter(Boolean).join(' · '), title: from }),
        online ? el('span', { class: 'u-sub', text: mountPerf(x), title: '延迟：服务器和共享它的页面之间来回一次要多久。缓存：服务器记着的文件和文件夹、已经取过来的文件。' }) : null),
      el('span', { class: 'u-actions' },
        el('button', { type: 'button', class: 'small', text: '浏览文件', disabled: !online, onclick: () => { $('#dlg-mounts').close(); openFiles(x.path); } }),
        el('button', { type: 'button', class: 'small', text: '在这里新建会话', disabled: !online, onclick: () => { $('#dlg-mounts').close(); $('#btn-new').click(); $('#new-cwd').value = x.path; } }),
        el('button', { type: 'button', class: 'small', text: '在这里新建项目', title: '几个角色分工、一起在这个文件夹里干活（角色共用这个文件夹，不建 git worktree）', disabled: !online || x.read_only, onclick: () => { $('#dlg-mounts').close(); if (typeof newProjectDialog === 'function') newProjectDialog({ root: x.path }); } }),
        el('button', { type: 'button', class: 'small danger', text: '断开', onclick: () => unmount(x) })));
  }));
  if (!d.mounts.length) ul.append(el('li', { class: 'muted small', text: d.available ? '还没有连接的远程目录。在下面选一个你电脑上的文件夹共享。' : '（无）' }));
  loadCaches();
}

/** Copies of shared folders on the server's disk (also ones this browser no longer remembers). */
async function loadCaches() {
  let d;
  try { d = await api('GET', '/mounts/caches'); } catch (e) { return; }
  const admin = S.me && S.me.admin;
  $('#mcache').hidden = !d.caches.length;
  $('#mcache-list').replaceChildren(...d.caches.map((x) => {
    const from = [x.client.host, x.client.dir].filter(Boolean).join(' · ');
    return el('li', {},
      el('div', { class: 'u-main' },
        el('span', { class: 'u-name' }, `${x.name || '（没有名字）'} `, x.online ? el('span', { class: 'badge online', text: '正在用' }) : null),
        el('span', { class: 'u-sub', text: [admin ? (x.owner ? `用户 ${x.owner}` : '管理员') : null, fmtSize(x.bytes) || '0 B', from ? `来自 ${from}` : null, x.shared_at ? `最后共享 ${fmtTime(x.shared_at)}` : null].filter(Boolean).join(' · ') })),
      el('span', { class: 'u-actions' },
        el('button', { type: 'button', class: 'small danger', text: '删除副本', onclick: () => dropCache(x) })));
  }));
}

async function dropCache(x) {
  if (!confirm(`删掉服务器上“${x.name || x.id}”的副本？${x.online ? '\n正在用它的远程目录会先断开。' : ''}\n你电脑上的文件不受影响；以后再共享这个文件夹，文件要重新从电脑取。`)) return;
  const admin = S.me && S.me.admin;
  try {
    await api('DELETE', `/mounts/caches/${enc(x.id)}${admin && x.owner ? `?owner=${enc(x.owner)}` : ''}`);
    toast('已删除服务器上的副本');
  } catch (e) { toast(errText(e), true); }
  loadMounts();
}

/** Badges for the choices made when sharing. */
function shareBadges(gitContext, prefetch, diskCache) {
  return [
    diskCache ? el('span', { class: 'badge', text: '服务器留副本', title: '读过的文件在服务器磁盘上留一份副本，断开重连后不用重新取；移除这个文件夹时删掉' }) : null,
    gitContext ? el('span', { class: 'badge', text: '读取 git 状态', title: 'Claude 启动时读取这个文件夹的 git 状态（大的仓库启动会慢）' }) : el('span', { class: 'badge', text: '速度优先', title: 'Claude 启动时不读这个文件夹的 git 状态，需要时自己跑 git' }),
    prefetch ? el('span', { class: 'badge', text: '预先缓存', title: '连上后先把小文件缓存到服务器' }) : null,
  ];
}

/** "延迟 120 ms · 缓存：记着 1,234 项，已取 56 个文件（1.2 MB）" */
function mountPerf(x) {
  const parts = [];
  if (typeof x.rtt_ms === 'number') parts.push(`延迟 ${x.rtt_ms} ms`);
  const c = x.cache;
  if (c && c.on) parts.push(`缓存：${c.crawl_done ? '' : '正在了解文件夹，'}记着 ${c.entries.toLocaleString()} 项，内存里 ${c.cached_files.toLocaleString()} 个文件（${fmtSize(c.cached_bytes) || '0 B'}）${c.disk ? `，服务器副本 ${c.disk_files.toLocaleString()} 个文件（${fmtSize(c.disk_bytes) || '0 B'}）` : ''}`);
  else if (c) parts.push('没有缓存（每次读写都要走网络）');
  return parts.join(' · ');
}

async function unmount(x) {
  if (!confirm(`断开远程目录 ${x.name}？\n共享它的页面会停止共享；正在用它的会话和项目角色会报错（发给它们的项目消息先排着），重新共享后可以继续。`)) return;
  try {
    await api('DELETE', `/mounts/${enc(x.id)}`);
    toast(`已断开 ${x.name}`);
  } catch (e) { toast(errText(e), true); }
  loadMounts();
}

// ---- remote directories shared from this page (web/remote.js) ---------------------------------------------

let lastMounts = [];
/** `{ mb, days }` when the server keeps copies on its disk (GET /mounts), else null */
let diskCacheCfg = null;
/** name → { name, handle, readOnly, exclude, gitContext, prefetch, diskCache, cacheId, share } */
const shares = new Map();
const SHARE_STATE = { connecting: '连接中', online: '已共享', retrying: '重连中', stopped: '已停止', failed: '出错了' };

function shareSupport() {
  if (!window.isSecureContext) return '这个网址不是 https，浏览器不允许网页访问电脑上的文件夹：请通过 https 或 localhost（例如 SSH 转发）打开控制台。';
  if (!('showDirectoryPicker' in window) || !window.CabRemote) return '这个浏览器不支持网页访问电脑上的文件夹：请用电脑上的 Chrome 或 Edge 打开控制台。';
  return null;
}

function browserClientId() {
  let id = localStorage.getItem('cab-browser-client');
  if (!id) {
    id = `web-${Array.from(crypto.getRandomValues(new Uint8Array(10)), (b) => b.toString(16).padStart(2, '0')).join('')}`;
    localStorage.setItem('cab-browser-client', id);
  }
  return id;
}

const browserName = () => {
  const ua = navigator.userAgent;
  return /Edg\//.test(ua) ? 'Edge' : /OPR\//.test(ua) ? 'Opera' : /Chrome\//.test(ua) ? 'Chrome' : '浏览器';
};

/** The folder's name, made safe for a directory name on the server, not yet in use. */
function shareName(folder) {
  const base = folder.replace(/[^\p{L}\p{N}._-]+/gu, '-').replace(/^[^\p{L}\p{N}]+/u, '').slice(0, 60).replace(/[.-]+$/, '') || 'remote';
  const taken = new Set([...shares.keys(), ...lastMounts.map((m) => m.name)]);
  let n = base;
  for (let i = 2; taken.has(n); i++) n = `${base}-${i}`;
  return n;
}

// The folder handles survive a reload in IndexedDB (per login), so sharing can carry on.
const whoAmI = () => (S.me && S.me.name) || '(admin)';
function idb() {
  return new Promise((resolve, reject) => {
    const r = indexedDB.open('cab-remote', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('shares', { keyPath: 'key' });
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}
async function idbDo(mode, fn) {
  const db = await idb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('shares', mode);
    const req = fn(tx.objectStore('shares'));
    tx.oncomplete = () => resolve(req && req.result);
    tx.onerror = () => reject(tx.error);
  });
}
const saveShare = (c, active) => idbDo('readwrite', (st) => st.put({ key: `${whoAmI()}/${c.name}`, owner: whoAmI(), name: c.name, handle: c.handle, readOnly: c.readOnly, exclude: c.exclude, gitContext: !!c.gitContext, prefetch: !!c.prefetch, diskCache: !!c.diskCache, cacheId: c.cacheId || null, active })).catch(() => {});
/** Names the folder's copy on the server (random: the server keeps one per id and user). */
const newCacheId = () => Array.from(crypto.getRandomValues(new Uint8Array(16)), (b) => b.toString(16).padStart(2, '0')).join('');
const dropShare = (name) => idbDo('readwrite', (st) => st.delete(`${whoAmI()}/${name}`)).catch(() => {});

function startShare(c) {
  const old = shares.get(c.name);
  if (old && old.share) old.share.stop();
  const share = new CabRemote.Share({
    root: c.handle,
    name: c.name,
    readOnly: c.readOnly,
    exclude: c.exclude,
    gitContext: !!c.gitContext,
    prefetch: !!c.prefetch,
    cacheId: c.diskCache ? c.cacheId : null,
    clientId: browserClientId(),
    origin: location.origin,
    client: { host: `浏览器（${browserName()}）`, platform: navigator.platform || '', dir: c.handle.name, version: 'web' },
    fetch: (path, init) => fetch(path, init),
    onchange: (state) => {
      renderShares();
      if (state === 'online' && !$('#dlg-mounts').open) toast(`已共享 ${c.name}`);
      if (state === 'stopped' || state === 'failed') saveShare(c, false);
    },
  });
  shares.set(c.name, { ...c, share });
  saveShare(c, true);
  share.start();
  renderShares();
}

/** The folder dialog needs a click; so does asking for permission again. */
async function grant(handle, readOnly) {
  const mode = readOnly ? 'read' : 'readwrite';
  if ((await handle.queryPermission({ mode })) === 'granted') return true;
  return (await handle.requestPermission({ mode })) === 'granted';
}

$('#bshare-disk').addEventListener('change', () => { $('#bshare-disk-warn').hidden = $('#bshare-disk').checked; });

$('#bshare-pick').addEventListener('click', async () => {
  const readOnly = $('#bshare-ro').checked;
  let handle;
  try {
    handle = await window.showDirectoryPicker({ id: 'cab-remote', mode: readOnly ? 'read' : 'readwrite' });
  } catch (e) {
    if (e && e.name !== 'AbortError') toast(`没能打开这个文件夹：${e.message || e}`, true);
    return;
  }
  if (!(await grant(handle, readOnly).catch(() => false))) return toast('没有得到访问这个文件夹的许可', true);
  const exclude = $('#bshare-exclude').value.split(/[,，\s]+/).filter(Boolean);
  const diskCache = !!diskCacheCfg && $('#bshare-disk').checked;
  startShare({ name: shareName(handle.name), handle, readOnly, exclude, gitContext: $('#bshare-git').checked, prefetch: $('#bshare-prefetch').checked, diskCache, cacheId: diskCache ? newCacheId() : null });
});

function renderShares() {
  const why = shareSupport();
  $('#bshare-unsupported').hidden = !why;
  $('#bshare-unsupported').textContent = why || '';
  $('#bshare-form').hidden = !!why;
  const ul = $('#bshare-list');
  ul.replaceChildren(...[...shares.values()].map((c) => {
    const st = c.share ? c.share.state : 'stopped';
    const live = c.share && !['stopped', 'failed'].includes(st);
    return el('li', {},
      el('div', { class: 'u-main' },
        el('span', { class: 'u-name' }, `${c.name} `, el('span', { class: `badge ${st}`, text: SHARE_STATE[st] || st }), c.readOnly ? el('span', { class: 'badge', text: '只读' }) : null, ...shareBadges(c.gitContext, c.prefetch, c.diskCache)),
        el('span', { class: 'u-sub', text: [c.handle.name ? `你电脑上的“${c.handle.name}”` : null, c.share && c.share.path ? `服务器上 ${c.share.path}` : null, c.share && c.share.detail && st !== 'online' ? c.share.detail : null, c.exclude && c.exclude.length ? `不共享 ${c.exclude.join(',')}` : null].filter(Boolean).join(' · ') })),
      el('span', { class: 'u-actions' },
        live
          ? el('button', { type: 'button', class: 'small', text: '停止共享', onclick: () => { c.share.stop(); saveShare(c, false); renderShares(); } })
          : el('button', { type: 'button', class: 'small primary', text: '继续共享', onclick: async () => {
            if (!(await grant(c.handle, c.readOnly).catch(() => false))) return toast('没有得到访问这个文件夹的许可', true);
            startShare(c);
          } }),
        live ? null : el('button', { type: 'button', class: 'small', text: '移除', title: c.cacheId ? '不再记住这个文件夹，并删掉服务器上它的副本' : '不再记住这个文件夹', onclick: () => removeShare(c) })));
  }));
  updateShareBadge();
}

/** "Remove": forgotten here, and its copy on the server deleted (the only way a user clears it, besides it expiring). */
async function removeShare(c) {
  if (c.cacheId) {
    if (!confirm(`不再记住“${c.name}”？\n服务器上它的副本也会删掉（你电脑上的文件不受影响）。`)) return;
    try {
      await api('DELETE', `/mounts/caches/${enc(c.cacheId)}`);
    } catch (e) {
      if (e.status !== 404) return toast(`服务器上的副本没删掉，先没移除：${errText(e)}`, true);
    }
  }
  shares.delete(c.name);
  dropShare(c.name);
  renderShares();
  loadCaches();
}

function liveShares() {
  return [...shares.values()].filter((c) => c.share && !['stopped', 'failed'].includes(c.share.state));
}

function updateShareBadge() {
  const n = liveShares().length;
  $('#share-badge').hidden = !n;
  $('#share-badge').textContent = n ? `● 正在共享 ${n} 个文件夹` : '';
  $('#share-badge').title = n ? `这个页面正在把你电脑上的 ${n} 个文件夹共享给服务器：关掉页面就会断开` : '';
}
$('#share-badge').addEventListener('click', () => $('#btn-mounts').click());

function stopAllShares() {
  for (const c of shares.values()) if (c.share) c.share.stop('logged out');
  shares.clear();
  updateShareBadge();
}

/** After a reload: carry on with what was being shared when permission is still there; list the rest. */
async function resumeShares() {
  if (shareSupport()) return;
  let saved = [];
  try { saved = (await idbDo('readonly', (st) => st.getAll())) || []; } catch (e) { return; }
  for (const r of saved.filter((x) => x.owner === whoAmI())) {
    if (shares.has(r.name)) continue;
    // remembered before copies on the server existed: stays memory only (that is what was agreed to then)
    const c = { name: r.name, handle: r.handle, readOnly: r.readOnly, exclude: r.exclude || [], gitContext: !!r.gitContext, prefetch: !!r.prefetch, diskCache: !!r.diskCache && !!r.cacheId, cacheId: r.cacheId || null };
    let ok = false;
    try { ok = (await r.handle.queryPermission({ mode: r.readOnly ? 'read' : 'readwrite' })) === 'granted'; } catch (e) { /* gone */ }
    if (r.active && ok) startShare(c);
    else shares.set(r.name, { ...c, share: null });
  }
  renderShares();
}

window.addEventListener('beforeunload', (e) => {
  if (!liveShares().length) return;
  e.preventDefault();
  e.returnValue = '';
});

// ---- the local agent (web/agent.js) -------------------------------------------------------------------------

/** Per login in this browser: { code (the pairing code), port, enabled }. The agent keeps only the code's hash. */
const agentKey = () => `cab-agent/${whoAmI()}`;
function agentPrefs() { try { return JSON.parse(localStorage.getItem(agentKey()) || '{}') || {}; } catch (e) { return {}; } }
function saveAgentPrefs(p) { localStorage.setItem(agentKey(), JSON.stringify(p)); }
function agentCode() {
  const p = agentPrefs();
  if (!p.code) { p.code = CabAgent.newCode(); p.port = p.port || 7790; saveAgentPrefs(p); }
  return p;
}
let agentLink = null;
let agentServer = null; // GET /agent
const AGENT_STATE = { off: '没启用', connecting: '连接中', no_agent: '没找到本机助手', refused: '配对没通过', online: '已连接', replaced: '另一个页面在用', failed: '出错了' };

function startAgent() {
  const p = agentPrefs();
  stopAgent();
  if (!p.enabled || !p.code || !window.CabAgent) return renderAgent();
  agentLink = new CabAgent.Link({
    port: p.port || 7790,
    token: p.code,
    origin: location.origin,
    fetch: (path, init) => fetch(path, init),
    onchange: () => renderAgent(),
    onconfirm: (resource) => toast(`本机助手在等你确认 ${resource} 上的操作：切到运行它的终端窗口`),
  });
  agentLink.start();
  renderAgent();
}

function stopAgent() {
  if (agentLink) { agentLink.stop(); agentLink = null; }
  renderAgent();
}

$('#btn-agent').addEventListener('click', async () => {
  agentCode();
  $('#dlg-agent').showModal();
  closeSidebarMobile();
  renderAgent();
  try { agentServer = await api('GET', '/agent'); } catch (e) { agentServer = null; $('#agent-unavailable').hidden = false; $('#agent-unavailable').textContent = errText(e); }
  renderAgent();
});
$('#agent-badge').addEventListener('click', () => $('#btn-agent').click());

$('#agent-copy').addEventListener('click', async () => {
  const p = agentCode();
  try { await navigator.clipboard.writeText($('#agent-pair-cmd').value); toast('已复制：在你电脑的终端里运行它'); } catch (e) { $('#agent-pair-cmd').select(); }
  if (!p.enabled) { p.enabled = true; saveAgentPrefs(p); startAgent(); }
});
$('#agent-toggle').addEventListener('click', () => {
  const p = agentCode();
  p.enabled = !p.enabled;
  saveAgentPrefs(p);
  if (p.enabled) startAgent(); else stopAgent();
});
$('#agent-newcode').addEventListener('click', () => {
  if (!confirm('重新生成配对码？\n旧的配对命令作废：要在你电脑上把新命令再运行一次，本机助手才认这个页面。')) return;
  const p = agentPrefs();
  p.code = CabAgent.newCode();
  saveAgentPrefs(p);
  if (p.enabled) startAgent(); else renderAgent();
});
$('#agent-port').addEventListener('change', () => {
  const p = agentCode();
  const n = Number($('#agent-port').value);
  p.port = Number.isInteger(n) && n > 0 && n < 65536 ? n : 7790;
  saveAgentPrefs(p);
  if (p.enabled) startAgent(); else renderAgent();
});

$('#agent-example-copy').addEventListener('click', async () => {
  const text = $('#agent-example').textContent;
  try { await navigator.clipboard.writeText(text); toast('已复制配置示例'); }
  catch (e) { const r = document.createRange(); r.selectNodeContents($('#agent-example')); getSelection().removeAllRanges(); getSelection().addRange(r); toast('按 Ctrl+C 复制选中的示例'); }
});

function renderAgent() {
  const p = agentPrefs();
  const st = agentLink ? agentLink.state : 'off';
  const online = st === 'online' && agentLink && agentLink.agent;
  const resources = online ? agentLink.agent.resources : [];
  // the sidebar
  $('#agent-badge').hidden = !online;
  $('#agent-badge').textContent = online ? `● 本机助手已连接（${resources.length} 个资源）` : '';
  if (!$('#dlg-agent').open) return;
  const server = agentServer;
  $('#agent-unavailable').hidden = !server || server.enabled;
  if (server && !server.enabled) $('#agent-unavailable').textContent = '这台服务器没有开放本机助手（管理员在 config.json 里设了 local_agent: false）。';
  const detail = agentLink && agentLink.detail && st !== 'online' ? `：${agentLink.detail}` : '';
  $('#agent-status').replaceChildren(
    el('span', { class: `badge ${online ? 'online' : st === 'connecting' ? 'connecting' : ''}`, text: AGENT_STATE[st] || st }),
    ` ${online ? `本机助手 ${agentLink.agent.version}，配置文件 ${agentLink.agent.config_path}` : detail}`);
  const ul = $('#agent-resources');
  ul.replaceChildren(...resources.map((r) => el('li', {},
    el('div', { class: 'u-main' },
      el('span', { class: 'u-name' }, `${r.name} `, el('span', { class: 'badge', text: r.type }),
        el('span', { class: 'badge', text: r.type === 'ssh' ? (r.confirm ? '每条命令要确认' : '命令不用确认') : r.access === 'read' ? '只读' : r.confirm ? '可写，改动要确认' : '可写' })),
      el('span', { class: 'u-sub', text: [r.description, (r.hosts || []).join(', ')].filter(Boolean).join(' · ') })))));
  if (online && !resources.length) ul.append(el('li', { class: 'muted small', text: `还没有资源：编辑 ${agentLink.agent.config_path}（下面“配置示例和每一项的说明”，或同目录的 config.example.json），保存后会出现在这里。` }));
  const ex = server && server.example;
  $('#agent-example-box').hidden = !ex;
  if (ex && !$('#agent-example').textContent) {
    $('#agent-example').textContent = JSON.stringify(ex.config, null, 2);
    $('#agent-example-help').replaceChildren(...ex.help.map((t) => el('li', { text: t })));
  }
  // setup
  const d = server && server.download;
  $('#agent-download').hidden = !d;
  $('#agent-version').textContent = d ? `（版本 ${d.version}，${fmtSize(d.size)}）` : '这台服务器上没有构建本机助手';
  $('#agent-sha').textContent = d ? d.sha256 : '';
  const port = p.port || 7790;
  $('#agent-port').value = String(port);
  $('#agent-pair-cmd').value = p.code ? `node cab-agent.mjs pair ${location.origin} ${p.code}${port !== 7790 ? ` --port ${port}` : ''}` : '';
  $('#agent-config-path').textContent = online ? agentLink.agent.config_path : '~/.cab-agent/config.json';
  $('#agent-toggle').textContent = p.enabled ? '停用（这个页面不再连本机助手）' : '启用（这个页面连本机助手）';
}

// ---- dialog: usage (admin) ---------------------------------------------------------------------------------

const USAGE_WINDOW = { five_hour: '5 小时', seven_day: '本周（全部模型）', seven_day_opus: '本周 Opus', seven_day_sonnet: '本周 Sonnet', seven_day_oauth_apps: '本周（第三方应用）' };
const BEHAVIOR = {
  cache_miss: '缓存没命中（隔太久再接着聊，整段上下文重新计费）',
  long_context: '上下文很长',
  subagent_heavy: '子任务用得多',
  high_parallel: '同时跑很多',
  cron: '定时任务',
  max_effort: '最高思考强度',
  workflow: '工作流',
  always_on_context: '每次都带的上下文（CLAUDE.md、MCP 工具说明等）',
  large_tool_results: '工具输出很大',
};
let usageBehaviors = null;

/** A bar filled to pct (0-100). The page's CSP forbids style attributes; CSSOM is fine. */
function meter(pct, cls = '') {
  const fill = el('span');
  fill.style.width = `${Math.max(0, Math.min(100, pct || 0))}%`;
  return el('div', { class: `meter${cls}` }, fill);
}

function meterRow(label, pct, when, title) {
  const p = typeof pct === 'number' ? Math.max(0, Math.min(100, pct)) : null;
  return el('div', { class: 'usage-row', title: title || '' },
    el('span', { text: label }),
    meter(p, p === null ? '' : p >= 95 ? ' full' : p >= 80 ? ' warn' : ''),
    el('span', { class: 'u-when', text: p === null ? '不知道' : `已用 ${p}%${when ? ` · ${when}` : ''}` }));
}

const resetsIn = (iso) => (iso ? `${fmtTime(iso)} 重置` : '');

async function loadUsage(refresh) {
  const box = $('#usage-body');
  box.replaceChildren(el('p', { class: 'muted', text: '加载中…' }));
  let u;
  try { u = await api('GET', `/usage${refresh ? '?refresh=1' : ''}`); } catch (e) { box.replaceChildren(el('p', { class: 'error', text: errText(e) })); return; }
  const rows = [];
  for (const [k, label] of Object.entries(USAGE_WINDOW)) {
    const w = u.windows && u.windows[k];
    if (w && w.available) rows.push(meterRow(label, w.utilization_pct, resetsIn(w.resets_at)));
  }
  for (const m of u.model_scoped || []) rows.push(meterRow(`本周 ${m.display_name}`, m.utilization_pct, resetsIn(m.resets_at)));
  const x = u.extra_usage;
  if (x && x.is_enabled) rows.push(meterRow('额外用量（本月）', x.utilization_pct, x.used_credits !== null && x.monthly_limit !== null ? `${x.used_credits} / ${x.monthly_limit}${x.currency ? ` ${x.currency}` : ''}` : ''));
  const parts = [];
  if (rows.length) parts.push(el('div', { class: 'usage-rows' }, ...rows));
  else {
    parts.push(el('p', { class: 'muted', text: '现在拿不到额度数据。' }));
    const why = (u.unavailable || []).map((x2) => x2.reason).filter(Boolean);
    if (why.length) parts.push(el('ul', { class: 'small muted' }, ...[...new Set(why)].slice(0, 4).map((r) => el('li', { text: r }))));
  }
  const src = { get_usage: 'Claude Code 的 /usage', rate_limit_event: '最近一次限流提示' }[u.source] || u.source;
  parts.push(el('p', { class: 'muted small', text: [u.subscription_type ? `订阅：${u.subscription_type}` : '', src ? `来源：${src}` : '', u.at ? `更新于 ${fmtTime(u.at)}` : ''].filter(Boolean).join(' · ') }));
  box.replaceChildren(...parts);
}

function renderBehaviors() {
  const box = $('#usage-behaviors');
  const u = usageBehaviors;
  if (!u) return;
  const b = u.behaviors;
  $('#usage-span-label').hidden = !b;
  if (!b) {
    const why = (u.unavailable || []).filter((x) => /behaviors/.test(x.field)).map((x) => x.reason);
    box.replaceChildren(el('p', { class: 'muted small', text: `没拿到：${why[0] || 'Claude Code 没有给出这部分（扫描可能超时了），稍后再试'}` }));
    return;
  }
  const w = b[$('#usage-span').value] || b.week;
  const parts = [el('p', { class: 'small', text: `${w.request_count} 次请求，${w.session_count} 个会话${u.behaviors_at ? `（${fmtTime(u.behaviors_at)} 扫的）` : ''}。下面各项会重叠，加起来不是 100%。` })];
  const beh = [...(w.behaviors || [])].sort((p, q) => q.pct - p.pct).filter((x) => x.pct > 0);
  if (beh.length) parts.push(el('div', { class: 'usage-rows' }, ...beh.map((x) => el('div', { class: 'usage-row' },
    el('span', { text: BEHAVIOR[x.key] || x.key, title: x.key }),
    meter(x.pct),
    el('span', { class: 'u-when', text: `${Math.round(x.pct)}% · ${x.count} 次` })))));
  if (w.recommendations && w.recommendations.length) {
    parts.push(el('h4', { text: '建议' }));
    parts.push(el('ol', { class: 'usage-recs' }, ...w.recommendations.map((r) => el('li', {},
      el('span', { text: `${r.title}（${Math.round(r.pct)}%）` }),
      r.detail ? el('div', { class: 'muted small', text: r.detail }) : null))));
  }
  const tops = [['子任务类型', w.agents], ['技能', w.skills], ['插件', w.plugins], ['MCP 服务器', w.mcp_servers]].filter(([, l]) => l && l.length);
  if (tops.length) parts.push(el('div', { class: 'usage-tops' }, ...tops.map(([t, l]) => el('div', {},
    el('strong', { text: t }),
    el('ul', {}, ...[...l].sort((p, q) => q.pct - p.pct).slice(0, 5).map((x) => el('li', { text: `${x.name} ${Math.round(x.pct)}%` })))))));
  box.replaceChildren(...parts);
}

$('#btn-usage').addEventListener('click', () => {
  $('#dlg-usage').showModal();
  closeSidebarMobile();
  loadUsage(false);
  renderBehaviors();
});
$('#usage-refresh').addEventListener('click', () => loadUsage(true));
$('#usage-span').addEventListener('change', renderBehaviors);
$('#usage-scan').addEventListener('click', async () => {
  const btn = $('#usage-scan');
  btn.disabled = true;
  $('#usage-behaviors').replaceChildren(el('p', { class: 'muted small', text: '正在扫描最近 7 天的会话记录…（可能要几十秒）' }));
  try {
    usageBehaviors = await api('GET', '/usage?behaviors=1');
    renderBehaviors();
  } catch (e) {
    $('#usage-behaviors').replaceChildren(el('p', { class: 'error small', text: errText(e) }));
  } finally { btn.disabled = false; }
});

// ---- dialog: Claude accounts (admin) ------------------------------------------------------------------------

const LOGIN_LABEL = { ok: '已登录', logged_out: '未登录', error: '出错', unknown: '未检查' };
let acctLogin = null;   // { login_id, account_id }

function acctName(a) { return a.label || a.email || a.id; }

// who may use an account: null = every user (the default); one name = theirs alone; several = shared; 'admin' = the admin's own sessions
const userLabel = (n) => (n === 'admin' ? '管理员自己' : n);
function acctWho(a) {
  if (a.users === null || a.users === undefined) return { text: '所有用户', cls: 'stopped', title: '默认：每个用户都能用（排在 TA 们专用、共享的账号后面）' };
  if (!a.users.length) return { text: '没人能用', cls: 'limit', title: '分给的用户都删掉了：点“谁能用”重新分配' };
  if (a.users.length === 1) return { text: `${userLabel(a.users[0])} 专用`, cls: 'bound', title: '只给这一个用户用，TA 的会话优先用它' };
  return { text: `共享：${a.users.map(userLabel).join('、')}`, cls: 'bound', title: '这几个用户共用：用完各自的专用账号后用它，再往后才用所有人都能用的账号' };
}

let acctData = null;   // the last GET /accounts, for the "谁能用" editor
let acctEditing = null;   // id of the account whose users are being edited
let acctUserNames = null;   // the users as GET /users lists them when the editor opened (null: not loaded yet)

// Open (or close) the "谁能用" editor of an account: the user list is read again each time, so users made since the
// dialog opened are there too.
async function toggleAcctEditor(a) {
  if (acctEditing === a.id) { acctEditing = null; renderAccounts(acctData); return; }
  acctEditing = a.id;
  acctUserNames = null;
  renderAccounts(acctData);
  try {
    acctUserNames = (await api('GET', '/users')).map((u) => u.name);
  } catch (e) {
    acctUserNames = [];
    toast(`读不到用户列表：${errText(e)}`, true);
  }
  if (acctEditing === a.id) renderAccounts(acctData);
}

function acctUsersEditor(a) {
  // A service started before this feature (the page is read from disk on every load, the server code only on
  // restart) neither keeps nor reports who may use an account: saving would do nothing (and drop the account's name).
  if (!acctData || !Array.isArray(acctData.user_names) || !('users' in a)) {
    return el('div', { class: 'acct-who-edit small' },
      el('p', { class: 'error', text: '服务端还是旧版本，还不能把账号分给用户：重启服务（claude-agent-bridge）后刷新页面再设置。' }),
      el('div', { class: 'dialog-actions' }, el('button', { type: 'button', class: 'small', text: '关闭', onclick: () => { acctEditing = null; renderAccounts(acctData); } })));
  }
  if (acctUserNames === null) return el('div', { class: 'acct-who-edit small muted', text: '正在读取用户列表…' });
  const chosen = new Set(a.users || []);
  // the admin, every user there is now, and whoever the account already names (so nothing checked is hidden)
  const names = [...new Set(['admin', ...acctUserNames, ...acctData.user_names, ...chosen])];
  const all = el('input', { type: 'radio', name: `who-${a.id}`, value: 'all' });
  const some = el('input', { type: 'radio', name: `who-${a.id}`, value: 'some' });
  all.checked = a.users === null || a.users === undefined;
  some.checked = !all.checked;
  const boxes = names.map((n) => {
    const c = el('input', { type: 'checkbox', value: n });
    c.checked = chosen.has(n);
    c.addEventListener('change', () => { if (c.checked) some.checked = true; });
    return el('label', { class: 'small acct-user' }, c, ` ${userLabel(n)}`);
  });
  const save = el('button', { type: 'button', class: 'small primary', text: '保存', onclick: () => {
    const users = all.checked ? null : boxes.map((b) => b.querySelector('input')).filter((c) => c.checked).map((c) => c.value);
    if (users && !users.length && !confirm(`一个用户都没选：账号「${acctName(a)}」谁都不能用了。确定？`)) return;
    acctEditing = null;
    acctAction(() => api('PATCH', `/accounts/${enc(a.id)}`, { users }), users === null ? '所有用户都能用' : users.length === 1 ? `已设为 ${userLabel(users[0])} 专用` : users.length ? '已设为这几个用户共享' : '已设为没人能用');
  } });
  const cancel = el('button', { type: 'button', class: 'small', text: '取消', onclick: () => { acctEditing = null; renderAccounts(acctData); } });
  return el('div', { class: 'acct-who-edit small' },
    el('div', {}, el('label', {}, all, ' 所有用户（默认）')),
    el('div', {}, el('label', {}, some, ' 只给这些用户：'), ...boxes),
    el('p', { class: 'muted small', text: '只选一个用户 = TA 专用；选几个 = 他们共享。每个用户先用自己专用的账号，不够再用共享的，最后用所有人都能用的；没分给 TA 的账号，额度再紧也不会用。从各会话的下一轮起生效。' }),
    el('div', { class: 'dialog-actions' }, cancel, save));
}

function acctBadges(a) {
  const out = [];
  if (a.current) out.push(el('span', { class: 'badge online', text: '正在用' }));
  if (a.login !== 'ok') out.push(el('span', { class: `badge ${a.login === 'logged_out' ? 'logged_out' : 'stopped'}`, text: LOGIN_LABEL[a.login] || a.login, title: a.login_error || '' }));
  if (a.exhausted && !a.available) out.push(el('span', { class: 'badge limit', text: `额度用完${a.exhausted.until ? ` · ${fmtTime(a.exhausted.until)} 恢复` : ''}`, title: `${a.exhausted.reason}，${fmtTime(a.exhausted.at)} 用完` }));
  else if (a.login === 'ok') out.push(el('span', { class: 'badge ok', text: '可用' }));
  return out;
}

function acctUsage(a) {
  const u = a.usage;
  if (!u) return el('div', { class: 'muted small', text: a.usage_error ? `用量：${a.usage_error}` : '用量：还没查' });
  const rows = [];
  for (const [k, label] of Object.entries(USAGE_WINDOW)) {
    const w = u.windows && u.windows[k];
    if (w && w.available) rows.push(meterRow(label, w.utilization_pct, resetsIn(w.resets_at)));
  }
  for (const m of u.model_scoped || []) rows.push(meterRow(`本周 ${m.display_name}`, m.utilization_pct, resetsIn(m.resets_at)));
  if (!rows.length) return el('div', { class: 'muted small', text: '拿不到这个账号的额度数据' });
  return el('div', { class: 'acct-usage' }, ...rows);
}

async function acctAction(fn, okMsg) {
  try {
    const r = await fn();
    if (okMsg) toast(okMsg);
    await loadAccounts(false, r && r.accounts ? r : null);
  } catch (e) { toast(errText(e), true); }
}

function renderAccounts(d) {
  acctData = d;
  const warn = [];
  if (d.env_token_override) warn.push('服务的环境里设了 CLAUDE_CODE_OAUTH_TOKEN，它比这里的账号优先，切换账号不会生效：运行 claude-agent auth set-token 清掉它（留空），再 claude-agent auth reload。');
  if (d.waiting_sessions) warn.push(`${d.waiting_sessions} 个会话在等账号（能用的账号额度都用完了${d.next_reset ? `，约 ${fmtTime(d.next_reset)} 有账号恢复` : ''}），到时自动接着做。`);
  if (!Array.isArray(d.user_names)) warn.push('服务端还是旧版本：要把账号分给用户（“谁能用”），先重启服务（claude-agent-bridge），再刷新这个页面。');
  if (d.left_without && d.left_without.length) warn.push(`没有任何账号能给 ${d.left_without.map(userLabel).join('、')} 用：TA 们发的消息会被拒绝。把某个账号设为“所有用户”，或者在“谁能用”里勾上 TA 们。`);
  $('#accounts-warn').hidden = !warn.length;
  $('#accounts-warn').textContent = warn.join('\n');
  $('#accounts-list').replaceChildren(...d.accounts.map((a) => el('li', { class: a.current ? 'current' : '' },
    el('div', { class: 'u-main' },
      el('div', { class: 'u-name' }, acctName(a), ...acctBadges(a), (() => { const w = acctWho(a); return el('span', { class: `badge ${w.cls}`, text: w.text, title: w.title || '' }); })()),
      el('div', { class: 'u-sub', text: [a.email && a.email !== acctName(a) ? a.email : '', a.plan ? `套餐 ${a.plan}` : '', a.config_dir + (a.default ? '（默认）' : ''), a.live_sessions ? `${a.live_sessions} 个会话在用` : ''].filter(Boolean).join(' · '), title: a.config_dir }),
      acctUsage(a),
      acctEditing === a.id ? acctUsersEditor(a) : null),
    el('div', { class: 'u-actions' },
      a.current || !a.available ? null : el('button', { type: 'button', class: 'small', text: '设为当前', title: '之后的消息优先用这个账号（正在跑的这一轮做完再换）；分了专用、共享账号的用户仍然先用 TA 们自己的', onclick: () => acctAction(() => api('POST', `/accounts/${enc(a.id)}/use`, {}), `已切换到「${acctName(a)}」`) }),
      el('button', { type: 'button', class: 'small', text: '谁能用', title: '所有用户（默认），还是只给某个用户专用 / 几个用户共享', onclick: () => toggleAcctEditor(a) }),
      a.exhausted ? el('button', { type: 'button', class: 'small', text: '标记为可用', title: '比如买了额外用量：不等恢复时间，马上可以再用', onclick: () => acctAction(() => api('POST', `/accounts/${enc(a.id)}/clear-limit`, {}), '已标记为可用') }) : null,
      el('button', { type: 'button', class: 'small', text: a.login === 'ok' ? '重新登录' : '登录', onclick: () => startAcctLogin(a) }),
      el('button', { type: 'button', class: 'small', text: '改名', onclick: () => {
        const label = prompt('账号名称（留空就显示邮箱）', a.label || '');
        if (label !== null) acctAction(() => api('PATCH', `/accounts/${enc(a.id)}`, { label: label.trim() || null }));
      } }),
      a.default ? null : el('button', { type: 'button', class: 'small danger', text: '移除', title: '不再使用（目录和里面的登录都留着）', onclick: () => {
        if (confirm(`不再使用账号「${acctName(a)}」？\n目录 ${a.config_dir} 和里面的登录都留着，以后可以重新添加。`)) acctAction(() => api('DELETE', `/accounts/${enc(a.id)}`), '已移除');
      } })))));
}

async function loadAccounts(refresh, data) {
  try {
    renderAccounts(data || await api('GET', `/accounts${refresh ? '?refresh=1' : ''}`));
  } catch (e) {
    $('#accounts-list').replaceChildren(el('li', { class: 'error', text: errText(e) }));
  }
}

async function startAcctLogin(a) {
  const box = $('#acct-login');
  $('#acct-login-error').hidden = true;
  $('#acct-login-code').value = '';
  $('#acct-login-label').value = a ? a.label || '' : '';
  $('#acct-login-title').textContent = a ? `登录账号「${acctName(a)}」（${a.config_dir}）` : '添加账号';
  $('#acct-login-url').textContent = '正在准备登录链接…';
  $('#acct-login-url').removeAttribute('href');
  box.hidden = false;
  try {
    const r = await api('POST', '/accounts/login', a ? { account_id: a.id } : {});
    acctLogin = { login_id: r.login_id, account_id: a ? a.id : null };
    $('#acct-login-url').textContent = r.url;
    $('#acct-login-url').href = r.url;
    if (!a) $('#acct-login-title').textContent = `添加账号（存在 ${r.config_dir}）`;
    $('#acct-login-code').focus();
  } catch (e) {
    $('#acct-login-url').textContent = '';
    $('#acct-login-error').textContent = errText(e);
    $('#acct-login-error').hidden = false;
  }
}

function closeAcctLogin() {
  if (acctLogin) api('DELETE', `/accounts/login/${enc(acctLogin.login_id)}`).catch(() => {});
  acctLogin = null;
  $('#acct-login').hidden = true;
}

$('#btn-accounts').addEventListener('click', () => {
  $('#acct-login').hidden = true;
  acctEditing = null;
  $('#accounts-list').replaceChildren(el('li', { class: 'muted small', text: '加载中…（第一次要查每个账号的用量，要几秒）' }));
  $('#dlg-accounts').showModal();
  closeSidebarMobile();
  loadAccounts(false);
});
$('#dlg-accounts').addEventListener('close', closeAcctLogin);
$('#accounts-refresh').addEventListener('click', () => loadAccounts(true));
$('#accounts-add').addEventListener('click', () => startAcctLogin(null));
$('#acct-login-cancel').addEventListener('click', closeAcctLogin);
$('#acct-login-done').addEventListener('click', async () => {
  if (!acctLogin) return;
  const code = $('#acct-login-code').value.trim();
  if (!code) return $('#acct-login-code').focus();
  const btn = $('#acct-login-done');
  btn.disabled = true;
  $('#acct-login-error').hidden = true;
  try {
    const a = await api('POST', `/accounts/login/${enc(acctLogin.login_id)}`, { code, label: $('#acct-login-label').value.trim() || undefined });
    acctLogin = null;
    $('#acct-login').hidden = true;
    toast(`已登录：${acctName(a)}`);
    loadAccounts(false);
  } catch (e) {
    $('#acct-login-error').textContent = `${errText(e)}\n授权码只能用一次：点“取消”再重新登录，用新链接拿新的授权码。`;
    $('#acct-login-error').hidden = false;
  } finally { btn.disabled = false; }
});

// ---- dialog: users (admin) ---------------------------------------------------------------------------------

/** What config.json lets the admin see (the server enforces it; the page only leaves out what would be refused). */
const adminView = () => (S.me && S.me.admin_view) || { admin_root: null, elsewhere: true, user_dirs: true, user_sessions: true, sandbox: false };

$('#btn-users').addEventListener('click', () => {
  $('#users-root').textContent = `${((S.me && S.me.users_root) || '/workspaces').replace(/\/+$/, '')}/<用户名>`;
  const v = adminView();
  const own = v.admin_root ? `管理员自己的目录是 ${v.admin_root}（和用户的目录平级）。` : '';
  const cannot = [v.elsewhere ? null : '自己目录之外的地方', v.user_dirs ? null : '用户的目录（包括 TA 们的远程目录）', v.user_sessions ? null : '用户的会话、项目和历史会话'].filter(Boolean);
  const sandboxText = v.sandbox
    ? '管理员自己的会话也在沙箱里，按同样的限制（config.json 的 admin_sandbox 打开了；会话连不上本机端口、Docker，不能 sudo）。'
    : '这只管控制台：管理员自己的会话不在沙箱里，会话里的 Claude 仍能读到这些（要一起管住，在 config.json 里打开 admin_sandbox）。';
  $('#users-admin-view').textContent = cannot.length
    ? `${own}管理员看不到${cannot.join('、')}；要放开，在服务器的 config.json 里改 admin_view_elsewhere / admin_view_user_dirs / admin_view_user_sessions（网页上改不了），重启服务生效。${sandboxText}`
    : `${own}管理员能看到所有目录和所有用户的会话（服务器的 config.json 里 admin_view_* 都打开了）。${v.sandbox ? '管理员的会话在沙箱里（admin_sandbox），但不挡任何目录，只是连不上本机端口、Docker，不能 sudo。' : ''}`;
  hideToken();
  $('#dlg-users').showModal();
  closeSidebarMobile();
  loadUsers();
});
// The token is shown once: do not leave it in the page after the dialog closes.
$('#dlg-users').addEventListener('close', hideToken);

function hideToken() {
  $('#user-token').hidden = true;
  $('#user-token-value').value = '';
  $('#user-token-link').value = '';
}

function showToken(title, r) {
  $('#user-token-title').textContent = title;
  $('#user-token-value').value = r.token;
  $('#user-token-link').value = `${location.origin}${r.login_path}`;
  $('#user-token').hidden = false;
}

async function loadUsers() {
  const ul = $('#users-list');
  let list;
  try { list = await api('GET', '/users'); } catch (e) { ul.replaceChildren(el('li', { class: 'error', text: errText(e) })); return; }
  ul.replaceChildren(...list.map((u) => el('li', {},
    el('div', { class: 'u-main' },
      el('span', { class: 'u-name', text: u.name }),
      el('span', { class: 'u-sub mono', text: `${u.root}${u.root_exists ? '' : '（目录不存在，登录后会重建）'}`, title: u.root }),
      u.accounts && u.accounts.length ? el('span', { class: 'u-sub', text: `Claude 账号：${u.accounts.map((a) => `${a.label}（${a.scope === 'exclusive' ? '专用' : '共享'}）`).join('、')}，用完再用所有人都能用的`, title: '在“Claude 账号”里点“谁能用”修改' }) : null,
      el('span', { class: 'u-sub', text: [`${u.sessions} 个会话`, typeof PJ !== 'undefined' && PJ.list.some((p) => p.owner === u.name) ? `${PJ.list.filter((p) => p.owner === u.name).length} 个项目` : null, u.running ? `${u.running} 个在运行` : null, `创建于 ${fmtDate(u.created_at)}`, u.token_reset_at ? `令牌重置于 ${fmtDate(u.token_reset_at)}` : null].filter(Boolean).join(' · ') }),
      u.remote_cache ? el('span', { class: 'u-sub', text: remoteCacheText(u.remote_cache) }) : null),
    el('span', { class: 'u-actions' },
      adminView().user_dirs ? el('button', { type: 'button', class: 'small', text: '浏览目录', onclick: () => { $('#dlg-users').close(); openFiles(u.root); } }) : null,
      u.remote_cache ? el('button', { type: 'button', class: 'small', text: '远程目录缓存', title: '这个用户的远程目录在服务器磁盘上留多大的副本、多久没共享就删掉', onclick: (e) => toggleCacheEditor(e.target.closest('li'), u) }) : null,
      el('button', { type: 'button', class: 'small', text: '重置令牌', onclick: () => resetUserToken(u.name) }),
      el('button', { type: 'button', class: 'small danger', text: '删除', onclick: () => removeUser(u) })))));
  if (!list.length) ul.append(el('li', { class: 'muted small', text: '还没有用户。在上面输入用户名创建一个。' }));
}

$('#form-user').addEventListener('submit', async (e) => {
  e.preventDefault();
  const name = $('#user-name').value.trim();
  if (!/^[a-z][a-z0-9_-]{0,31}$/.test(name)) return toast('用户名：小写字母开头，只能有小写字母、数字、- 和 _，最长 32 个字符', true);
  try {
    const r = await api('POST', '/users', { name });
    $('#user-name').value = '';
    showToken(`已创建用户 ${r.name}，目录 ${r.root}${r.root_existed ? '（目录原来就有，里面已有的内容对方都能看到）' : ''}`, r);
    loadUsers();
  } catch (err) { toast(errText(err), true); }
});

/** "远程目录副本：每个文件夹最多 2 GB（默认）· 7 天没共享就删（默认）· 现在占 1.2 MB（2 个文件夹）" */
function remoteCacheText(c) {
  if (!c.available) return '远程目录副本：这台服务器没开（remote_mounts 或 mount_cache_mb）';
  const dflt = (v) => (v === null ? '（默认）' : '');
  return [
    `远程目录副本：${c.effective_disk_mb > 0 ? `每个文件夹最多 ${fmtSize(c.effective_disk_mb * 1024 * 1024)}` : '不留'}${dflt(c.disk_mb)}`,
    c.effective_disk_mb > 0 || c.used.copies ? `${c.effective_days > 0 ? `${c.effective_days} 天没共享就删` : '不自动删'}${dflt(c.days)}` : null,
    `现在占 ${fmtSize(c.used.bytes) || '0 B'}${c.used.copies ? `（${c.used.copies} 个文件夹）` : ''}`,
  ].filter(Boolean).join(' · ');
}

/** The per-user editor under a user's row: empty = the server's default (config.json). */
function toggleCacheEditor(li, u) {
  const open = li.querySelector('.u-cache');
  if (open) { open.remove(); return; }
  const c = u.remote_cache;
  const mb = el('input', { type: 'number', min: '0', max: '1048576', step: '1', placeholder: `默认 ${c.default_disk_mb}`, value: c.disk_mb === null ? '' : String(c.disk_mb), 'aria-label': '每个文件夹最多多少 MB' });
  const days = el('input', { type: 'number', min: '0', max: '3650', step: '1', placeholder: `默认 ${c.default_days}`, value: c.days === null ? '' : String(c.days), 'aria-label': '多少天没共享就删掉' });
  const num = (input) => (input.value.trim() === '' ? null : Number(input.value));
  const save = async (body) => {
    for (const v of Object.values(body)) if (v !== null && !(Number.isInteger(v) && v >= 0)) return toast('填 0 或正整数；空着表示用服务器默认值', true);
    try {
      const r = await api('PATCH', `/users/${enc(u.name)}`, body);
      toast(`已保存 ${u.name} 的远程目录缓存设置：${remoteCacheText(r.remote_cache)}`);
      loadUsers();
    } catch (e) { toast(errText(e), true); }
  };
  li.append(el('div', { class: 'u-cache' },
    el('label', {}, '每个文件夹最多 ', mb, ' MB'),
    el('label', {}, days, ' 天没共享就删掉'),
    el('button', { type: 'button', class: 'small primary', text: '保存', onclick: () => save({ mount_disk_cache_mb: num(mb), mount_disk_cache_days: num(days) }) }),
    el('button', { type: 'button', class: 'small', text: '恢复默认', onclick: () => save({ mount_disk_cache_mb: null, mount_disk_cache_days: null }) }),
    el('p', { class: 'muted small hint', text: `空着就用服务器的默认值（config.json：每个文件夹 ${c.default_disk_mb} MB、${c.default_days} 天）。MB 填 0：以后不再留副本，只用内存；天数填 0：不自动删。改小以后，正在共享的文件夹要下次共享时才按新大小收缩；天数改了马上按新天数清理。` })));
  mb.focus();
}

// ---- the admin's sessions and projects in folders it no longer sees ----------------------------------------------

let oovData = null;
const OOV_SEEN = 'cab.oov.seen';

/** Shown to the admin once per set of items (or when asked: `force`); nothing for a user. */
async function checkOutOfView(force) {
  if (!isAdmin()) return;
  try { oovData = await api('GET', '/admin/out-of-view'); } catch (e) { return; }
  const ids = [...oovData.sessions.map((s) => s.id), ...oovData.projects.map((p) => p.id)].sort().join(',');
  if (!ids) { if ($('#dlg-oov').open) $('#dlg-oov').close(); return; }
  if (!force && localStorage.getItem(OOV_SEEN) === ids) return;
  renderOutOfView();
  if (!$('#dlg-oov').open) $('#dlg-oov').showModal();
}

function renderOutOfView() {
  $('#oov-root').textContent = adminView().admin_root || '管理员目录';
  const groups = new Map();
  for (const s of oovData.sessions) { const k = s.user || ''; if (!groups.has(k)) groups.set(k, { sessions: [], projects: [] }); groups.get(k).sessions.push(s); }
  for (const p of oovData.projects) { const k = p.user || ''; if (!groups.has(k)) groups.set(k, { sessions: [], projects: [] }); groups.get(k).projects.push(p); }
  $('#oov-list').replaceChildren(...[...groups].map(([user, g]) => el('li', {},
    el('div', { class: 'u-main' },
      el('span', { class: 'u-name', text: user ? `在用户 ${user} 的目录里` : '在管理员目录之外' }),
      ...g.projects.map((p) => el('span', { class: 'u-sub mono', text: `项目「${p.name}」（${p.sessions} 个会话）· ${p.root}`, title: p.root })),
      ...g.sessions.map((s) => el('span', { class: 'u-sub mono', text: `会话「${s.name || s.id.slice(0, 8)}」· ${s.cwd}`, title: s.cwd })),
      user ? null : el('span', { class: 'u-sub', text: `这些不在管理员目录里，也不是哪个用户的：要接着用，把目录搬进 ${adminView().admin_root || '管理员目录'}（在服务器上运行 claude-agent relocate <旧目录> <新目录>，会话和对话记录跟着改），或者在 config.json 里打开 admin_view_elsewhere。` })),
    el('span', { class: 'u-actions' },
      user ? el('button', { type: 'button', class: 'small primary', text: `全部转给 ${user}`, onclick: () => handOver(user, g) }) : null))));
}

async function handOver(user, g) {
  const n = g.sessions.length + g.projects.reduce((k, p) => k + p.sessions, 0);
  if (!confirm(`把这些转给 ${user}？\n${g.projects.length ? `${g.projects.length} 个项目、` : ''}共 ${n} 个会话改归 ${user}：TA 登录后在自己的会话列表里接着用，管理员以后看不到它们（除非 config.json 打开 admin_view_user_sessions）。\n目录和对话记录都不变。`)) return;
  const failed = [];
  for (const p of g.projects) { try { await api('POST', `/projects/${enc(p.id)}/transfer`, { to: user }); } catch (e) { failed.push(`项目「${p.name}」：${errText(e)}`); } }
  for (const s of g.sessions) { try { await api('POST', `/sessions/${enc(s.id)}/transfer`, { to: user }); } catch (e) { failed.push(`会话「${s.name || s.id.slice(0, 8)}」：${errText(e)}`); } }
  toast(failed.length ? `有的没转成：\n${failed.join('\n')}` : `已转给 ${user}`, failed.length > 0);
  if (S.current && g.sessions.some((s) => s.id === S.current)) closeSession();
  refreshSessions();
  if (typeof PJ !== 'undefined' && typeof refreshProjects === 'function') refreshProjects();
  checkOutOfView(true);
}

$('#oov-later').addEventListener('click', () => {
  if (oovData) localStorage.setItem(OOV_SEEN, [...oovData.sessions.map((s) => s.id), ...oovData.projects.map((p) => p.id)].sort().join(','));
  $('#dlg-oov').close();
});

async function resetUserToken(name) {
  if (!confirm(`给 ${name} 生成新令牌？\n旧令牌和用它登录的浏览器会立刻失效。`)) return;
  try {
    showToken(`${name} 的新令牌`, await api('POST', `/users/${enc(name)}/token`));
    loadUsers();
  } catch (e) { toast(errText(e), true); }
}

async function removeUser(u) {
  const v = adminView();
  if (!confirm(`删除用户 ${u.name}？\n令牌立刻失效，正在运行的会话会停下来，TA 在服务器上的远程目录副本会删掉。\n目录 ${u.root} 保留${v.user_dirs ? '' : '（删除后它就是普通文件夹，管理员能在文件面板里看到、清理）'}；会话记录和 TA 的项目也保留（${v.user_sessions ? '管理员仍能看到' : '管理员看不到，除非在 config.json 里打开 admin_view_user_sessions'}）；TA 共享出去的角色模板也还在，不想要可以在角色库里下架。`)) return;
  try {
    const r = await api('DELETE', `/users/${enc(u.name)}`);
    hideToken();
    toast(`已删除用户 ${u.name}${r.stopped_sessions ? `，停止了 ${r.stopped_sessions} 个会话` : ''}${r.accounts_left_to_nobody && r.accounts_left_to_nobody.length ? `；账号 ${r.accounts_left_to_nobody.join('、')} 原来是 TA 专用的，现在没人能用，去“Claude 账号”里重新分配` : ''}`, !!(r.accounts_left_to_nobody && r.accounts_left_to_nobody.length));
    loadUsers();
    refreshSessions();
  } catch (e) { toast(errText(e), true); }
}

for (const b of document.querySelectorAll('[data-copy]')) {
  b.addEventListener('click', async () => {
    const input = $(b.dataset.copy);
    try { await navigator.clipboard.writeText(input.value); }
    catch (e) { input.select(); document.execCommand('copy'); }
    toast('已复制');
  });
}

// ---- go ------------------------------------------------------------------------------------------------

document.addEventListener('visibilitychange', () => { if (!document.hidden && !$('#app').hidden) refreshSessions(); });
// A login link pasted into an already-open tab only changes the hash.
window.addEventListener('hashchange', () => { if (/[#&]token=/.test(location.hash)) boot(); });
boot();

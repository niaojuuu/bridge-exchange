'use strict';
/*
 * Projects in the web console (DESIGN §16). Loaded after app.js and uses its helpers ($, el, api, toast, S, …).
 *   GET  /projects, /projects/:id               sidebar groups + the overview (polled with the sessions)
 *   GET  /projects/:id/inbox                    "在你这": questions, messages, decisions, changes, missions …
 *   GET  /projects/:id/items, /mail, /missions, /history    board, messages, missions, activity
 *   POST /projects, /projects/:id/roles/:role/shift|handover, /projects/:id/mail, …/decide, …
 * Every button that answers a role is a message to that role (it sees "负责人" and the answer), never a hidden state.
 */

const PJ = {
  list: [],
  current: null,          // project id on screen (overview), null when a session or nothing is open
  view: null,             // the current project's view
  tab: 'overview',
  data: { inbox: [], items: [], mail: [], missions: [], history: [] },
  collapsed: new Set(JSON.parse(localStorage.getItem('cab.pjCollapsed') || '[]')),
  showOthers: new Set(),
  templates: null,
  openMission: null,
  loading: false,
  lastBody: '',
};

const ROLE_STATE = {
  running: '在干活', waiting_input: '等你回答', idle: '空闲', created: '刚开班', dormant: '歇着（来消息会醒）', cancelled: '歇着（来消息会醒）', failed: '出错停了',
};
const TASK_COLS = [['todo', '待办'], ['doing', '在做'], ['blocked', '卡住'], ['review', '待验收'], ['done', '完成']];
const STATUS_TEXT = { todo: '待办', doing: '在做', blocked: '卡住', review: '待验收', done: '完成', dropped: '不做了' };
const MAIL_STATUS = { queued: '排队中', waiting: '等待重试', delivered: '已交给它', received: '它已读到', replied: '已回复', cancelled: '已撤回', failed: '没送到', unread: '未读', read: '已读' };
const WS_LABEL = { worktree: '自己的分支（worktree）', root: '主目录', subdir: '子目录', readonly: '只读（规划模式）' };
const MISSION_STATUS = { pending: '等你确认', scheduled: '已确认，到点开始', running: '进行中', paused: '暂停（等额度）', wrapup: '停下了，在写收尾', ended: '已结束' };
const OUTCOME = { complete: '完全完成', partial: '部分完成', stuck: '中间卡住', cancelled: '撤销', lapsed: '作废' };
const circled = (i) => '①②③④⑤⑥⑦⑧⑨⑩'[i] || String(i + 1);
const pj = () => PJ.list.find((p) => p.id === PJ.current) || PJ.view;
const roleName = (p, id) => ((p && p.roles.find((r) => r.id === id)) || {}).name || id;
const saveCollapsed = () => { try { localStorage.setItem('cab.pjCollapsed', JSON.stringify([...PJ.collapsed])); } catch (e) { /* private mode */ } };

// ---- refreshing -----------------------------------------------------------------------------------------

async function refreshProjects() {
  if (PJ.loading) return;
  if (LIB.tick++ % 12 === 0) refreshLibraryBadge();
  PJ.loading = true;
  try {
    PJ.list = await api('GET', '/projects');
    if (PJ.current) {
      const v = PJ.list.find((p) => p.id === PJ.current);
      if (!v) { toast('这个项目已经不在了'); leaveProject(); closeSessionIfProject(); }
      else { PJ.view = v; await loadTab(); renderProject(); }
    }
    renderSidebar();
  } catch (e) { /* the session poll shows connection trouble */ }
  finally { PJ.loading = false; }
}

function closeSessionIfProject() {
  if (!S.current) { $('#empty').hidden = false; history.replaceState(null, '', location.pathname); }
}

async function loadTab() {
  const id = PJ.current;
  if (!id) return;
  const t = PJ.tab;
  const jobs = [api('GET', `/projects/${enc(id)}/inbox`).then((x) => { PJ.data.inbox = x; })];
  if (t === 'overview' || t === 'board') jobs.push(api('GET', `/projects/${enc(id)}/items?kind=task`).then((x) => { PJ.data.items = x; }));
  if (t === 'overview' || t === 'missions') jobs.push(api('GET', `/projects/${enc(id)}/missions`).then((x) => { PJ.data.missions = x; }));
  if (t === 'mail') jobs.push(api('GET', `/projects/${enc(id)}/mail?limit=300`).then((x) => { PJ.data.mail = x; }));
  if (t === 'files') jobs.push(api('GET', `/projects/${enc(id)}/items?kind=deliverable`).then((x) => { PJ.data.files = x; }));
  if (t === 'history') jobs.push(api('GET', `/projects/${enc(id)}/history?limit=300`).then((x) => { PJ.data.history = x; }));
  if (t === 'decisions') jobs.push(api('GET', `/projects/${enc(id)}/items`).then((x) => { PJ.data.all = x; }));
  await Promise.all(jobs.map((j) => j.catch(() => undefined)));
}

// ---- sidebar --------------------------------------------------------------------------------------------

function renderGroupedSidebar(ul, sessionItem) {
  const out = [];
  const inProject = new Set();
  const byId = new Map(S.sessions.map((s) => [s.id, s]));
  for (const p of PJ.list) {
    for (const m of p.members) inProject.add(m.session_id);
    out.push(...projectGroup(p, byId, sessionItem));
  }
  const plain = S.sessions.filter((s) => !s.project && !inProject.has(s.id));
  if (PJ.list.length && plain.length) out.push(el('li', { class: 'group-head', text: '独立会话' }));
  out.push(...plain.map((st) => sessionItem(st)));
  if (!PJ.list.length && !plain.length) out.push(el('li', { class: 'muted small', text: '还没有会话。新会话：一个 Claude 做一件事；新项目：几个角色分工做一件大事。' }));
  ul.replaceChildren(...out);
}

function projectGroup(p, byId, sessionItem) {
  const open = !PJ.collapsed.has(p.id);
  const s = p.summary || {};
  const head = el('li', { class: `project-head${PJ.current === p.id && !S.current ? ' active' : ''}`, title: p.root },
    el('button', { class: 'caret', title: open ? '收起' : '展开', text: open ? '▾' : '▸', onclick: (e) => { e.stopPropagation(); if (open) PJ.collapsed.add(p.id); else PJ.collapsed.delete(p.id); saveCollapsed(); renderSidebar(); } }),
    el('span', { class: 'p-name', text: p.name }),
    s.running ? el('span', { class: 'p-badge run', title: `${s.running} 个在干活`, text: `● ${s.running}` }) : null,
    s.waiting ? el('span', { class: 'p-badge wait', title: `${s.waiting} 件事在你这`, text: `⚑ ${s.waiting}` }) : null);
  head.addEventListener('click', () => { openProject(p.id); closeSidebarMobile(); });
  const items = [head];
  if (!open) return items;
  for (const r of p.roles.filter((x) => !x.archived)) items.push(roleItem(p, r, byId));
  const roleSessions = new Set(p.roles.map((r) => r.session_id).filter(Boolean));
  const others = p.members.filter((m) => !roleSessions.has(m.session_id) && m.session);
  if (others.length) {
    const showing = PJ.showOthers.has(p.id);
    items.push(el('li', { class: 'sub others', onclick: () => { if (showing) PJ.showOthers.delete(p.id); else PJ.showOthers.add(p.id); renderSidebar(); } },
      el('span', { class: 'muted small', text: `${showing ? '▾' : '▸'} 其他会话 ${others.length}（临时工、验收、以前的班次、接入的会话）` })));
    if (showing) {
      for (const m of others) {
        const st = byId.get(m.session_id);
        if (!st) continue;
        const kind = { worker: '临时工', review: '验收', solo: '接入', role: `${roleName(p, m.role_id)} 第${m.shift_n}班` }[m.kind] || m.kind;
        const li = sessionItem(st, `${kind} · ${st.name || st.id.slice(0, 8)}`);
        li.classList.add('sub');
        items.push(li);
      }
    }
  }
  return items;
}

function roleItem(p, r, byId) {
  const st = r.session ? byId.get(r.session.id) : null;
  const state = st ? st.state : null;
  const busy = st && st.pending_question ? '等你回答' : st && st.busy_reason === 'queued' ? '排队等名额' : state ? ROLE_STATE[state] || state : '没在班';
  const doing = st && (state === 'running' || state === 'waiting_input') && st.last_event ? st.last_event.summary : r.session && r.session.last_text;
  const li = el('li', { class: `sub role${st && st.id === S.current ? ' active' : ''}`, title: r.duty || r.title || '' },
    el('div', { class: 's-top' },
      el('span', { class: `dot ${state || 'none'}`, style: `box-shadow: 0 0 0 2px ${r.color || 'var(--border)'}` }),
      el('span', { class: 's-name', text: r.name + (r.coordinator ? ' · 协调' : '') }),
      st && st.pending_question ? el('span', { class: 'badge waiting_input', text: '待回答' }) : null,
      r.workspace_error ? el('span', { class: 'badge failed', title: r.workspace_error, text: '目录没准备好' }) : null),
    el('div', { class: 's-sub', text: [busy, doing && state !== 'idle' ? doing : (r.session ? fmtAgo(r.session.last_activity) : r.title)].filter(Boolean).join(' · ') }));
  li.addEventListener('click', () => { closeSidebarMobile(); if (st) openSession(st.id); else startRoleDialog(p, r); });
  return li;
}

// ---- the overview page ---------------------------------------------------------------------------------

function leaveProject() {
  PJ.current = null;
  PJ.view = null;
  const sec = $('#project');
  if (sec) sec.hidden = true;
}

async function openProject(id) {
  if (S.current) { closeStream(); S.current = null; S.status = null; $('#chat').hidden = true; }
  const p = PJ.list.find((x) => x.id === id || x.name === id);
  if (!p) { try { PJ.list = await api('GET', '/projects'); } catch (e) { return toast(errText(e), true); } }
  const v = PJ.list.find((x) => x.id === id || x.name === id);
  if (!v) return toast('找不到这个项目', true);
  if (PJ.current !== v.id) { PJ.tab = 'overview'; PJ.openMission = null; PJ.lastBody = ''; }
  PJ.current = v.id;
  PJ.view = v;
  $('#empty').hidden = true;
  $('#chat').hidden = true;
  const sec = $('#project');
  sec.hidden = false;
  history.replaceState(null, '', `${location.pathname}#p=${v.id}`);
  sec.replaceChildren(projectSkeleton());
  await loadTab();
  renderProject(true);
  renderSidebar();
}

function projectSkeleton() {
  const p = pj();
  const frag = document.createDocumentFragment();
  const head = el('header', { class: 'pj-head' },
    el('button', { class: 'icon only-mobile', title: '会话列表', text: '☰', onclick: () => $('#sidebar').classList.add('open') }),
    el('div', { class: 'pj-title' },
      el('div', { class: 'title-row' }, el('span', { class: 'pj-name', text: p.name }), el('span', { id: 'pj-sum', class: 'muted small' })),
      el('div', { class: 'muted small pj-goal', id: 'pj-goal', title: '点击修改目标', onclick: editGoal })),
    el('div', { class: 'chat-controls' },
      el('button', { class: 'primary', text: '给协调者说话', title: '经项目信箱发给协调者：它在忙就做完手上这一步再看', onclick: () => composeTo(p.roles.find((r) => r.coordinator && !r.archived)) }),
      el('button', { text: '新值班单', title: '定一段无人值守的长任务：时间、要做的事、额度上限', onclick: () => missionDialog() }),
      el('button', { text: '文件', title: '浏览项目目录，上传、下载文件和文件夹', onclick: () => openFiles(pj().root) }),
      el('button', { text: '设置', onclick: () => settingsDialog() })));
  const tabs = el('nav', { class: 'pj-tabs', id: 'pj-tabs' });
  const body = el('div', { class: 'pj-body', id: 'pj-body' });
  frag.append(head, tabs, body);
  return frag;
}

const TABS = [['overview', '总览'], ['board', '看板'], ['mail', '消息'], ['missions', '值班单'], ['decisions', '决定'], ['files', '交付'], ['history', '动态']];

function renderProject(force) {
  const p = pj();
  if (!p || $('#project').hidden) return;
  const inbox = PJ.data.inbox || [];
  $('#pj-sum').textContent = [`${p.summary.roles} 个角色`, p.summary.running ? `${p.summary.running} 个在干活` : '都空着', inbox.length ? `${inbox.length} 件在你这` : ''].filter(Boolean).join(' · ');
  $('#pj-goal').textContent = p.goal ? `目标：${p.goal.replace(/\s+/g, ' ')}` : '还没写目标（点这里写）';
  $('#pj-tabs').replaceChildren(...TABS.map(([k, label]) => el('button', { class: PJ.tab === k ? 'active' : '', text: k === 'overview' && inbox.length ? `${label} ⚑${inbox.length}` : label, onclick: async () => { PJ.tab = k; PJ.lastBody = ''; await loadTab(); renderProject(true); } })));
  // don't redraw under the user's hands (typing, an open menu)
  const body = $('#pj-body');
  const act = document.activeElement;
  if (!force && act && body.contains(act) && /^(INPUT|TEXTAREA|SELECT)$/.test(act.tagName)) return;
  const draw = { overview: overviewBody, board: boardBody, mail: mailBody, missions: missionsBody, decisions: decisionsBody, files: filesBody, history: historyBody }[PJ.tab] || overviewBody;
  const node = draw(p);
  const sig = node.textContent + '|' + node.querySelectorAll('button').length;
  if (!force && sig === PJ.lastBody) return;
  PJ.lastBody = sig;
  const top = body.scrollTop;
  body.replaceChildren(node);
  body.scrollTop = top;
}

function section(title, ...children) {
  return el('section', { class: 'pj-sec' }, el('h3', { text: title }), ...children);
}

function overviewBody(p) {
  const wrap = el('div', { class: 'pj-overview' });
  const inbox = PJ.data.inbox || [];
  if (p.remote && p.remote_offline) wrap.append(el('p', { class: 'box small warn-text', text: `项目目录是远程目录，现在没有连接：${p.remote_offline}。角色会停在那里，发给它们的消息先排着；在那台电脑的浏览器里重新共享这个文件夹（左侧“远程目录”）就能接着做。` }));
  else if (p.remote) wrap.append(el('p', { class: 'muted small', text: '项目目录是远程目录（你电脑上的文件夹）：角色们共用这个文件夹，不建 git worktree；共享它的标签页要一直开着。' }));
  wrap.append(section(inbox.length ? `在你这 · ${inbox.length}` : '在你这',
    inbox.length ? el('div', { class: 'inbox' }, ...inbox.map((x) => inboxCard(p, x))) : el('p', { class: 'muted small', text: '没有要你定、要你回的事。角色提问、请你拍板、要你批的改动、值班单要你确认，都会出现在这里。' })));
  wrap.append(section('角色', el('div', { class: 'roles' }, ...p.roles.filter((r) => !r.archived).map((r) => roleCard(p, r)),
    el('button', { class: 'role-add', text: '＋ 加角色', onclick: () => roleDialog(p, null) }))));
  const live = (PJ.data.missions || []).filter((m) => ['running', 'paused', 'wrapup', 'scheduled'].includes(m.data.status));
  if (live.length) wrap.append(section('值班单', ...live.map((m) => missionLine(m))));
  const tasks = PJ.data.items || [];
  if (tasks.length) {
    const counts = TASK_COLS.map(([k, label]) => `${label} ${tasks.filter((t) => t.data.status === k).length}`).join(' · ');
    wrap.append(section('看板', el('p', { class: 'small link-row', onclick: async () => { PJ.tab = 'board'; await loadTab(); renderProject(true); } }, counts, el('span', { class: 'muted', text: '  → 看板' }))));
  } else {
    wrap.append(section('看板', el('p', { class: 'muted small', text: '还没有任务。协调者会把目标拆成任务、派给角色；你也可以在“看板”里自己建。' })));
  }
  return wrap;
}

function roleCard(p, r) {
  const s = r.session;
  const st = s ? S.sessions.find((x) => x.id === s.id) : null;
  const state = st ? st.state : s ? s.state : null;
  const label = st && st.pending_question ? '等你回答' : state ? ROLE_STATE[state] || state : '没在班';
  const tasks = (PJ.data.items || []).filter((t) => t.data.assignee === r.id && !['done', 'dropped'].includes(t.data.status));
  const ctx = s && s.context_pct;
  const card = el('div', { class: `role-card ${state || 'none'}`, style: `border-top-color: ${r.color || 'var(--border)'}` },
    el('div', { class: 'rc-top' },
      el('span', { class: `dot ${state || 'none'}` }),
      el('b', { text: r.name }),
      r.coordinator ? el('span', { class: 'badge', text: '协调' }) : null,
      el('span', { class: 'muted small', text: label })),
    el('div', { class: 'small rc-duty', text: r.duty || r.title || '' }),
    el('div', { class: 'muted small rc-doing', text: s ? `${state === 'running' || state === 'waiting_input' ? '正在：' : '最后：'}${s.last_text || '—'}` : `${WS_LABEL[r.workspace] || r.workspace}${r.branch ? ` · ${r.branch}` : ''}` }),
    el('div', { class: 'muted small', text: [tasks.length ? `名下 ${tasks.length} 件` : '', s ? `第 ${r.shift_n} 班` : '', ctx != null ? `上下文 ${ctx}%` : ''].filter(Boolean).join(' · ') }),
    r.workspace_error ? el('div', { class: 'error small', text: r.workspace_error }) : null,
    el('div', { class: 'rc-actions' },
      s ? el('button', { class: 'small', text: '打开对话', onclick: () => openSession(s.id) }) : el('button', { class: 'small primary', text: '开班', onclick: () => startRoleDialog(p, r) }),
      el('button', { class: 'small', text: '发消息', onclick: () => composeTo(r) }),
      s && ctx != null && ctx >= 75 ? el('button', { class: 'small warn', text: '换班', title: '上下文快满了：让它写交接说明，换个新会话接着做', onclick: () => handoverDialog(p, r) }) : null,
      el('button', { class: 'small link', text: '设置', onclick: () => roleDialog(p, r) })));
  return card;
}

// ---- inbox ---------------------------------------------------------------------------------------------

function inboxCard(p, x) {
  const head = (kind, extra) => el('div', { class: 'ib-head' }, el('span', { class: `ib-kind ${x.kind}`, text: kind }), el('b', { text: x.from || '' }), el('span', { class: 'muted small', text: `${fmtAgo(x.at)}${extra ? ` · ${extra}` : ''}` }));
  const card = el('div', { class: `ib-card ${x.kind}` });
  const done = (msg) => { toast(msg); refreshProjects(); };
  const fail = (e) => toast(errText(e), true);
  if (x.kind === 'question') {
    const q = (x.questions || [])[0] || {};
    card.append(head('在问你', x.deadline_at ? `${fmtTime(x.deadline_at)} 前没人答它自己定` : ''), el('div', { class: 'ib-text', text: (x.questions || []).map((y) => y.question).join('\n') }));
    const simple = (x.questions || []).length === 1 && !q.multiSelect && (q.options || []).length;
    card.append(el('div', { class: 'ib-actions' },
      ...(simple ? q.options.map((o, i) => el('button', { class: 'small', title: o.description || '', text: `${circled(i)} ${o.label}`, onclick: () => api('POST', `/sessions/${enc(x.session)}/input`, { question_id: x.id, answers: { [q.question]: o.label } }).then(() => done('答了')).catch(fail) })) : []),
      el('button', { class: 'small', text: '去对话里回答', onclick: () => openSession(x.session) })));
  } else if (x.kind === 'message') {
    card.append(head('给你的消息'), el('div', { class: 'ib-text', text: x.text || x.title }),
      el('div', { class: 'ib-actions' },
        el('button', { class: 'small primary', text: '回复', onclick: async () => {
          const role = (x.sender || '').startsWith('role:') ? x.sender.slice(5) : null;
          if (!role) return toast('发消息的会话不是角色：去它的对话里回', true);
          const t = await askText(`回复 ${x.from}`, '它会作为“负责人”的消息收到', '');
          if (t) api('POST', `/projects/${enc(p.id)}/mail`, { to: role, text: t, reply_to: Number(x.id) }).then(() => done('回了')).catch(fail);
        } }),
        el('button', { class: 'small', text: '知道了', onclick: () => api('POST', `/mail/${x.id}/read`, {}).then(() => done('收起了')).catch(fail) })));
  } else if (x.kind === 'decision') {
    card.append(head(`请你定 ${x.id}`), el('div', { class: 'ib-text', text: x.title }), x.why ? el('div', { class: 'muted small', text: `推荐理由：${x.why}` }) : null);
    const opts = x.options || [];
    card.append(el('div', { class: 'ib-actions' },
      ...opts.map((o, i) => el('button', { class: `small${x.recommended === i ? ' primary' : ''}`, title: o.description || '', text: `${circled(i)} ${o.label}${x.recommended === i ? '（推荐）' : ''}`, onclick: () => decide(p, x.id, i, '') })),
      el('button', { class: 'small', text: opts.length ? '写别的' : '回答', onclick: async () => { const t = await askText(`${x.id}：${x.title}`, '你的答复（会发给提问的角色）', ''); if (t) decide(p, x.id, null, t); } }),
      el('button', { class: 'small link', text: '撤掉这题', onclick: () => api('POST', `/projects/${enc(p.id)}/items/decision/${x.id}/withdraw`, {}).then(() => done('撤掉了')).catch(fail) })));
  } else if (x.kind === 'change') {
    const role = x.role;
    card.append(head(role ? `要加角色 ${x.id}` : `要你批 ${x.id}`), el('div', { class: 'ib-text', text: x.title }),
      role ? el('div', { class: 'small', text: `「${role.name}」：${role.duty || ''}（${WS_LABEL[role.workspace || 'worktree']}）` }) : el('div', { class: 'small', text: [x.before ? `现在：${x.before}` : '', x.after ? `改成：${x.after}` : ''].filter(Boolean).join('\n') }),
      x.why ? el('div', { class: 'muted small', text: `理由：${x.why}` }) : null,
      el('div', { class: 'ib-actions' },
        el('button', { class: 'small primary', text: '批准', onclick: () => api('POST', `/projects/${enc(p.id)}/items/change/${x.id}/decide`, { approve: true }).then(() => done('批了')).catch(fail) }),
        el('button', { class: 'small', text: '不批', onclick: async () => { const t = await askText(`不批 ${x.id}`, '为什么（可以不写）', '', true); if (t !== null) api('POST', `/projects/${enc(p.id)}/items/change/${x.id}/decide`, { approve: false, note: t }).then(() => done('没批')).catch(fail); } })));
  } else if (x.kind === 'review') {
    const r = x.result || {};
    card.append(head(`等验收 ${x.id}`), el('div', { class: 'ib-text', text: x.title }), el('div', { class: 'small', text: [`交付：${r.what || ''}`, `怎么验：${r.how || ''}`, r.evidence ? `证据：${r.evidence}` : '', r.gaps ? `不足：${r.gaps}` : ''].filter(Boolean).join('\n') }),
      el('div', { class: 'ib-actions' },
        el('button', { class: 'small primary', text: '通过', onclick: () => review(p, x.id, true, '') }),
        el('button', { class: 'small', text: '打回', onclick: async () => { const t = await askText(`打回 ${x.id}`, '为什么打回（会发给做的角色）', ''); if (t) review(p, x.id, false, t); } }),
        el('button', { class: 'small', text: '让验收员验', onclick: () => api('POST', `/projects/${enc(p.id)}/items/task/${x.id}/request-review`, {}).then((r2) => done(r2.message)).catch(fail) })));
  } else if (x.kind === 'mail_failed') {
    card.append(head('没送到', `给 ${x.to || ''}`), el('div', { class: 'ib-text', text: x.title }), el('div', { class: 'error small', text: x.error || '' }),
      el('div', { class: 'ib-actions' }, el('button', { class: 'small', text: '重发', onclick: () => api('POST', `/mail/${x.id}/retry`, {}).then(() => done('重发了')).catch(fail) })));
  } else if (x.kind === 'mission') {
    const m = x.mission;
    if (x.action === 'confirm') {
      card.append(head(`值班单 ${x.id} 等你确认`, m.start_at ? `定在 ${fmtTime(m.start_at)} 开始` : '确认就开始'), el('div', { class: 'ib-text', text: `${m.title}：${m.goal}` }),
        el('div', { class: 'small', text: `${m.items.length} 件事 · ${m.hours} 小时${m.quota_pct ? ` · 周额度最多 ${m.quota_pct}%` : ''} · 参与：${m.roles.map((r) => roleName(p, r)).join('、')}` }),
        el('div', { class: 'ib-actions' },
          el('button', { class: 'small', text: '看一下', onclick: async () => { PJ.tab = 'missions'; PJ.openMission = x.id; await loadTab(); renderProject(true); } }),
          el('button', { class: 'small primary', text: m.start_at ? '确认' : '开始', onclick: () => api('POST', `/projects/${enc(p.id)}/missions/${x.id}/confirm`, {}).then(() => done('值班单开始了')).catch(fail) }),
          el('button', { class: 'small', text: '不要', onclick: () => api('POST', `/projects/${enc(p.id)}/missions/${x.id}/abort`, { why: '负责人不要' }).then(() => done('撤了')).catch(fail) })));
    } else {
      card.append(head(`值班单 ${x.id} 结束了`, OUTCOME[m.outcome] || ''), el('div', { class: 'ib-text', text: `${m.title}：${(m.report || '').slice(0, 300)}` }),
        el('div', { class: 'ib-actions' },
          el('button', { class: 'small', text: '看收尾', onclick: async () => { PJ.tab = 'missions'; PJ.openMission = x.id; await loadTab(); renderProject(true); } }),
          ...[['good', '很好'], ['ok', '一般'], ['bad', '有问题']].map(([k, label]) => el('button', { class: 'small', text: label, onclick: async () => { const t = await askText(`${x.id} 的结论：${label}`, '一句话（会发给协调者复盘）', '', true); if (t !== null) api('POST', `/projects/${enc(p.id)}/missions/${x.id}/verdict`, { rating: k, note: t }).then(() => done('写好了')).catch(fail); } }))));
    }
  }
  return card;
}

function decide(p, id, choice, text) {
  api('POST', `/projects/${enc(p.id)}/items/decision/${id}/decide`, { choice, text }).then(() => { toast('定了，答复已经发给它'); refreshProjects(); }).catch((e) => toast(errText(e), true));
}

function review(p, id, pass, note) {
  api('POST', `/projects/${enc(p.id)}/items/task/${id}/review`, { pass, note }).then(() => { toast(pass ? '通过了' : '打回了'); refreshProjects(); }).catch((e) => toast(errText(e), true));
}

// ---- board --------------------------------------------------------------------------------------------

function boardBody(p) {
  const tasks = PJ.data.items || [];
  const wrap = el('div', { class: 'pj-board-wrap' },
    el('div', { class: 'pj-toolbar' }, el('button', { class: 'primary small', text: '＋ 新任务', onclick: () => taskDialog(p, null) }),
      el('span', { class: 'muted small', text: '角色用工具改任务；你也可以点开一张改状态、换人、验收。' })));
  const board = el('div', { class: 'board' });
  for (const [k, label] of TASK_COLS) {
    const col = tasks.filter((t) => t.data.status === k);
    board.append(el('div', { class: 'col' }, el('div', { class: 'col-head', text: `${label} ${col.length}` }),
      ...col.map((t) => el('div', { class: `task ${t.data.priority}`, onclick: () => taskDialog(p, t.id) },
        el('div', { class: 'small muted', text: `${t.id}${t.data.depends_on.length ? ` ← ${t.data.depends_on.join(',')}` : ''}` }),
        el('div', { text: t.data.title }),
        el('div', { class: 'small muted', text: t.data.assignee ? roleName(p, t.data.assignee) : '未派' })))));
  }
  const dropped = tasks.filter((t) => t.data.status === 'dropped');
  wrap.append(board);
  if (dropped.length) wrap.append(el('p', { class: 'muted small', text: `不做了：${dropped.map((t) => `${t.id} ${t.data.title}`).join('；')}` }));
  return wrap;
}

async function taskDialog(p, id) {
  let t = null, history = [];
  if (id) {
    try { const r = await api('GET', `/projects/${enc(p.id)}/items/task/${id}`); t = r.data; history = r.history; } catch (e) { return toast(errText(e), true); }
  }
  const roles = p.roles.filter((r) => !r.archived);
  const f = {
    title: el('input', { value: t ? t.title : '', placeholder: '一句话说清做什么' }),
    description: el('textarea', { rows: 3, placeholder: '说明（可选）' }),
    acceptance: el('textarea', { rows: 2, placeholder: '完成标准：怎样算做完（可选）' }),
    assignee: el('select', {}, el('option', { value: '', text: '先不派' }), ...roles.map((r) => el('option', { value: r.id, text: r.name }))),
    status: el('select', {}, ...Object.entries(STATUS_TEXT).map(([k, v]) => el('option', { value: k, text: v }))),
    depends: el('input', { placeholder: '依赖的任务编号，逗号分开，如 T1,T2' }),
    note: el('input', { placeholder: '附一句说明（可选）' }),
  };
  if (t) { f.description.value = t.description; f.acceptance.value = t.acceptance; f.assignee.value = t.assignee || ''; f.status.value = t.status; f.depends.value = t.depends_on.join(','); }
  const body = el('div', { class: 'form' },
    el('label', {}, '标题', f.title), el('label', {}, '说明', f.description), el('label', {}, '完成标准', f.acceptance),
    el('div', { class: 'row' }, el('label', { class: 'grow' }, '负责', f.assignee), t ? el('label', { class: 'grow' }, '状态', f.status) : null),
    el('label', {}, '依赖', f.depends), t ? el('label', {}, '说明一句', f.note) : null);
  if (t) {
    const r = t.result;
    if (r) body.append(el('div', { class: 'small box' }, el('b', { text: '交付说明' }), el('div', { text: [`交付：${r.what}`, `怎么验：${r.how}`, r.evidence ? `证据：${r.evidence}` : '', r.gaps ? `不足：${r.gaps}` : ''].filter(Boolean).join('\n') })));
    if (t.review) body.append(el('div', { class: 'small box' }, `验收：${t.review.verdict === 'pass' ? '通过' : '打回'}（${t.review.by === 'owner' || t.review.by === 'admin' ? '负责人' : roleName(p, t.review.by.replace(/^role:/, ''))}）${t.review.note ? `：${t.review.note}` : ''}`));
    if (t.notes.length) body.append(el('div', { class: 'small box notes' }, el('b', { text: '记录' }), ...t.notes.slice(-30).map((n) => el('div', { text: `${fmtTime(n.at)} ${who(p, n.by)}：${n.text}` }))));
    body.append(el('details', { class: 'small' }, el('summary', { text: `改动记录 ${history.length}` }), ...history.map((h) => el('div', { class: 'muted', text: `${fmtTime(h.at)} ${h.by_label} ${h.action}` }))));
  }
  const buttons = [];
  if (t && t.status === 'review') {
    buttons.push(el('button', { type: 'button', text: '通过', class: 'primary', onclick: () => { review(p, id, true, f.note.value); dlg.close(); } }));
    buttons.push(el('button', { type: 'button', text: '打回', onclick: async () => { const why = f.note.value || await askText(`打回 ${id}`, '为什么', ''); if (why) { review(p, id, false, why); dlg.close(); } } }));
    buttons.push(el('button', { type: 'button', text: '让验收员验', onclick: () => api('POST', `/projects/${enc(p.id)}/items/task/${id}/request-review`, {}).then((r) => { toast(r.message); dlg.close(); }).catch((e) => toast(errText(e), true)) }));
  }
  const dlg = modal(t ? `${id} · ${STATUS_TEXT[t.status]}` : '新任务', body, [...buttons, el('button', { type: 'submit', class: t && t.status === 'review' ? '' : 'primary', text: t ? '保存' : '建好并派出' })], async () => {
    const deps = f.depends.value.split(/[,，\s]+/).map((x) => x.trim()).filter(Boolean);
    const payload = { title: f.title.value.trim(), description: f.description.value, acceptance: f.acceptance.value, assignee: f.assignee.value || null, depends_on: deps };
    if (t) Object.assign(payload, { status: f.status.value !== t.status ? f.status.value : undefined, note: f.note.value || undefined });
    if (t) await api('PATCH', `/projects/${enc(p.id)}/items/task/${id}`, payload);
    else await api('POST', `/projects/${enc(p.id)}/items/task`, payload);
    toast(t ? '改好了' : '建好了；派了人的话已经发给它');
    refreshProjects();
  });
}

function who(p, by) {
  if (by === 'owner' || by === 'admin') return '负责人';
  if (by === 'system') return '平台';
  if (by.startsWith('role:')) return roleName(p, by.slice(5));
  return by.startsWith('session:') ? '会话' : by;
}

// ---- messages -------------------------------------------------------------------------------------------

function mailBody(p) {
  const list = PJ.data.mail || [];
  const wrap = el('div', { class: 'pj-mail' },
    el('div', { class: 'pj-toolbar' }, el('button', { class: 'primary small', text: '＋ 发消息', onclick: () => composeTo(null) }),
      el('span', { class: 'muted small', text: '项目里的所有消息：你、角色、平台之间。对方在忙时，消息在它做完手上这一步后送到，不打断它。' })));
  if (!list.length) wrap.append(el('p', { class: 'muted small', text: '还没有消息。' }));
  for (const m of list.slice().reverse()) {
    const to = m.to_label || (m.to_session ? '会话' : '');
    const acts = [];
    if (m.status === 'queued' || m.status === 'waiting') {
      acts.push(el('button', { class: 'small link', text: '撤回', onclick: () => api('POST', `/mail/${m.id}/cancel`, {}).then(() => refreshProjects()).catch((e) => toast(errText(e), true)) }));
      acts.push(el('button', { class: 'small link', text: '插队', title: '打断它这一轮，马上看排着的消息', onclick: () => api('POST', `/mail/${m.id}/cutin`, {}).then(() => refreshProjects()).catch((e) => toast(errText(e), true)) }));
    }
    if (m.status === 'failed' || m.status === 'waiting') acts.push(el('button', { class: 'small link', text: '重发', onclick: () => api('POST', `/mail/${m.id}/retry`, {}).then(() => refreshProjects()).catch((e) => toast(errText(e), true)) }));
    if (m.status === 'unread') acts.push(el('button', { class: 'small link', text: '知道了', onclick: () => api('POST', `/mail/${m.id}/read`, {}).then(() => refreshProjects()).catch((e) => toast(errText(e), true)) }));
    wrap.append(el('div', { class: `mail-row ${m.status}` },
      el('div', { class: 'small' }, el('b', { text: m.sender_label }), ` → ${to} · ${fmtTime(m.created_at)} · `, el('span', { class: `mail-st ${m.status}`, text: MAIL_STATUS[m.status] || m.status }), m.error ? el('span', { class: 'error', text: `（${m.error}）` }) : null, ...acts),
      el('div', { class: 'mail-text', text: m.text }),
      m.reply ? el('details', { class: 'small muted' }, el('summary', { text: '它那一轮的回答' }), el('div', { class: 'mail-text', text: m.reply })) : null));
  }
  return wrap;
}

async function composeTo(role) {
  const p = pj();
  if (!p) return;
  const roles = p.roles.filter((r) => !r.archived);
  if (!roles.length) return toast('这个项目还没有角色', true);
  const sel = el('select', {}, ...roles.map((r) => el('option', { value: r.id, text: `${r.name}${r.coordinator ? '（协调者）' : ''}` })));
  if (role) sel.value = role.id;
  const text = el('textarea', { rows: 5, placeholder: '写清要它做什么。它在忙就做完手上这一步再看；没在班会开班。' });
  const fyi = el('input', { type: 'checkbox' });
  modal('给角色发消息', el('div', { class: 'form' }, el('label', {}, '发给', sel), el('label', {}, '内容', text), el('label', { class: 'small' }, fyi, ' 只是告知，不用叫醒它（它下次干活时看到）')),
    [el('button', { type: 'submit', class: 'primary', text: '发送' })], async () => {
      if (!text.value.trim()) throw new Error('写点内容');
      const r = await api('POST', `/projects/${enc(p.id)}/mail`, { to: sel.value, text: text.value, notify_only: fyi.checked });
      toast(r.status === 'queued' ? '发了：它在忙，做完手上这一步就看' : r.status === 'waiting' ? `暂时送不到：${r.error || ''}（会自动重试）` : '发了');
      refreshProjects();
    });
  setTimeout(() => text.focus(), 50);
}

// ---- missions ------------------------------------------------------------------------------------------

function missionLine(m) {
  const d = m.data;
  const left = d.ends_at ? Math.max(0, Math.round((Date.parse(d.ends_at) - Date.now()) / 60000)) : null;
  const done = d.items.filter((it) => it.status === 'done' || it.status === 'partial').length;
  return el('div', { class: 'mission-line', onclick: async () => { PJ.tab = 'missions'; PJ.openMission = m.id; await loadTab(); renderProject(true); } },
    el('b', { text: `${m.id} ${d.title}` }), ' ', el('span', { class: 'badge', text: MISSION_STATUS[d.status] }),
    el('span', { class: 'muted small', text: ` ${done}/${d.items.length} 件${left !== null && d.status !== 'scheduled' ? ` · 还剩 ${Math.floor(left / 60)} 小时 ${left % 60} 分` : d.start_at ? ` · ${fmtTime(d.start_at)} 开始` : ''}${d.quota_pct ? ` · 周额度 ${d.quota.used_pct ?? 0}% / ${d.quota_pct}%` : ''}` }));
}

function missionsBody(p) {
  const list = (PJ.data.missions || []).slice().reverse();
  const wrap = el('div', { class: 'pj-missions' },
    el('div', { class: 'pj-toolbar' }, el('button', { class: 'primary small', text: '＋ 新值班单', onclick: () => missionDialog() }),
      el('span', { class: 'muted small', text: '一段没人看着的长任务：你定目标和限制，角色们按单子干，平台管时间、额度和先后。也可以让协调者起草（它会交给你确认）。' })));
  if (!list.length) wrap.append(el('p', { class: 'muted small', text: '还没有值班单。' }));
  for (const m of list) {
    const d = m.data;
    const open = PJ.openMission === m.id;
    const box = el('div', { class: `mission ${d.status}` },
      el('div', { class: 'mission-head', onclick: () => { PJ.openMission = open ? null : m.id; PJ.lastBody = ''; renderProject(true); } },
        el('b', { text: `${m.id} ${d.title}` }), el('span', { class: 'badge', text: d.status === 'ended' ? `已结束 · ${OUTCOME[d.outcome] || ''}` : MISSION_STATUS[d.status] }),
        el('span', { class: 'muted small', text: ` ${d.goal.slice(0, 80)}` })));
    if (open) box.append(missionDetail(p, m));
    wrap.append(box);
  }
  return wrap;
}

function missionDetail(p, m) {
  const d = m.data;
  const fail = (e) => toast(errText(e), true);
  const done = (t) => { toast(t); refreshProjects(); };
  const it = el('ol', { class: 'mission-items', start: '0' }, ...d.items.map((x) => el('li', {}, `${x.title}`, el('span', { class: 'muted small', text: ` — ${x.role ? roleName(p, x.role) : '负责人'}${x.depends_on.length ? ` · 依赖 ${x.depends_on.join('、')}` : ''} · ${{ todo: x.called ? '轮到了' : '没轮到', doing: '在做', done: '做完', partial: '部分完成', failed: '没做成' }[x.status]}${x.note ? ` · ${x.note}` : ''}` }))));
  const wrap = el('div', { class: 'mission-detail' },
    el('div', { class: 'small', text: [`目标：${d.goal}`, `时间：${d.started_at ? `${fmtTime(d.started_at)} 起` : d.start_at ? `定在 ${fmtTime(d.start_at)} 开始` : '确认后开始'}，${d.hours} 小时${d.ends_at ? `（到 ${fmtTime(d.ends_at)}）` : ''}`, d.quota_pct ? `周额度上限 ${d.quota_pct}%${d.quota.used_pct !== null ? `，已用 ${d.quota.used_pct}%` : ''}` : '不限周额度', `参与：${d.roles.map((r) => roleName(p, r)).join('、')}${d.lead ? `；负责：${roleName(p, d.lead)}` : ''}`, d.stop_when ? `停下来等你：${d.stop_when}` : '', d.rules ? `规矩：${d.rules}` : ''].filter(Boolean).join('\n') }),
    it);
  const acts = el('div', { class: 'ib-actions' });
  if (d.status === 'pending') {
    acts.append(el('button', { class: 'small primary', text: d.start_at ? '确认（到点开始）' : '开始', onclick: () => api('POST', `/projects/${enc(p.id)}/missions/${m.id}/confirm`, {}).then(() => done('确认了')).catch(fail) }));
    acts.append(el('button', { class: 'small', text: '不要', onclick: () => api('POST', `/projects/${enc(p.id)}/missions/${m.id}/abort`, { why: '负责人不要' }).then(() => done('撤了')).catch(fail) }));
  } else if (d.status !== 'ended') {
    acts.append(el('button', { class: 'small danger', text: '中止', onclick: async () => { const why = await askText(`中止 ${m.id}`, '为什么（可以不写）', '', true); if (why !== null) api('POST', `/projects/${enc(p.id)}/missions/${m.id}/abort`, { why }).then(() => done('中止了')).catch(fail); } }));
  } else {
    acts.append(el('button', { class: 'small', text: '照这张再开一次', onclick: () => api('POST', `/projects/${enc(p.id)}/missions/${m.id}/rerun`, {}).then((r) => done(`建好了 ${r.id}，等你确认`)).catch(fail) }));
    if (!d.verdict && d.outcome !== 'lapsed' && d.outcome !== 'cancelled') {
      for (const [k, label] of [['good', '很好'], ['ok', '一般'], ['bad', '有问题']]) acts.append(el('button', { class: 'small', text: `结论：${label}`, onclick: async () => { const t = await askText(`${m.id} 的结论：${label}`, '一句话（会发给协调者复盘）', '', true); if (t !== null) api('POST', `/projects/${enc(p.id)}/missions/${m.id}/verdict`, { rating: k, note: t }).then(() => done('写好了')).catch(fail); } }));
    }
  }
  wrap.append(acts);
  if (d.report) wrap.append(el('div', { class: 'box small' }, el('b', { text: '收尾' }), el('div', { class: 'bubble', html: md(d.report) })));
  if (d.facts) {
    const f = d.facts;
    wrap.append(el('div', { class: 'box small' }, el('b', { text: '事实清单（平台记的）' }), el('div', { text: [
      `用时 ${f.duration_min} 分钟${f.over_time ? '（超时）' : ''}`,
      `周额度：${f.weekly_quota_used_pct ?? '读不到'}${f.weekly_quota_used_pct != null ? '%' : ''}（${f.quota_basis}）；花费约 $${f.cost_usd}（${Object.entries(f.cost_by_role_usd || {}).map(([k, v]) => `${k} $${v}`).join('，')}）`,
      `件数：做完 ${f.items.done} · 部分 ${f.items.partial} · 没做成 ${f.items.failed} · 没动 ${f.items.open}`,
      (f.pauses || []).length ? `暂停 ${f.pauses.length} 次` : '',
      ...(f.commits || []).map((c) => `${c.role}${c.branch ? `（${c.branch}）` : ''} 提交 ${c.lines.length} 次：${c.lines.slice(0, 5).join('；')}`),
    ].filter(Boolean).join('\n') })));
  }
  if (d.verdict) wrap.append(el('div', { class: 'box small', text: `你的结论：${{ good: '很好', ok: '一般', bad: '有问题' }[d.verdict.rating]}${d.verdict.note ? `：${d.verdict.note}` : ''}` }));
  if (d.retro) wrap.append(el('div', { class: 'box small' }, el('b', { text: '复盘' }), el('div', { class: 'bubble', html: md(d.retro) })));
  if (d.log.length) wrap.append(el('details', { class: 'small', open: d.status !== 'ended' }, el('summary', { text: `角色记的进度 ${d.log.length}` }), ...d.log.slice(-80).map((l) => el('div', { text: `${fmtTime(l.at)} ${who(p, l.by)}：${l.text}` }))));
  if (d.events.length) wrap.append(el('details', { class: 'small' }, el('summary', { text: `平台记的 ${d.events.length}` }), ...d.events.slice(-80).map((l) => el('div', { class: 'muted', text: `${fmtTime(l.at)} ${l.text}` }))));
  return wrap;
}

function missionDialog() {
  const p = pj();
  if (!p) return;
  const roles = p.roles.filter((r) => !r.archived);
  const f = {
    title: el('input', { placeholder: '例如：今晚把测试补齐' }),
    goal: el('textarea', { rows: 2, placeholder: '要达到什么' }),
    items: el('textarea', { rows: 5, placeholder: '一行一件，可以写 @角色 和 <依赖第几件（从 0 数）：\n补后端测试 @backend\n补前端测试 @frontend <0\n跑一遍全部测试，写报告 @qa <0,1' }),
    hours: el('input', { type: 'number', min: '0.5', max: '72', step: '0.5', value: '8' }),
    quota: el('input', { type: 'number', min: '1', max: '100', step: '1', placeholder: '不限' }),
    start: el('input', { type: 'datetime-local' }),
    stop: el('input', { placeholder: '碰到这些情况停下来等你，例如：要删数据、要花钱' }),
    rules: el('input', { placeholder: '例如：不合并主线，只在各自分支提交' }),
  };
  const roleIds = (line) => { const m = /@(\S+)/.exec(line); if (!m) return null; const r = roles.find((x) => x.id === m[1] || x.name === m[1]); return r ? r.id : m[1]; };
  modal('新值班单', el('div', { class: 'form' },
    el('label', {}, '标题', f.title), el('label', {}, '目标', f.goal), el('label', {}, '要做的事', f.items),
    el('div', { class: 'row' }, el('label', { class: 'grow' }, '跑多少小时', f.hours), el('label', { class: 'grow' }, '周额度最多用 %', f.quota)),
    el('label', {}, '定时开始（不填就是你确认时开始；定了时间到点没确认就作废）', f.start),
    el('label', {}, '停下来等你的情况', f.stop), el('label', {}, '规矩', f.rules),
    el('p', { class: 'muted small', text: `可用的角色：${roles.map((r) => `${r.name}（@${r.id}）`).join('、')}` })),
  [el('button', { type: 'submit', class: 'primary', text: '建好（下一步确认）' })], async () => {
    const items = f.items.value.split('\n').map((x) => x.trim()).filter(Boolean).map((line) => {
      const deps = /<([\d,，\s]+)/.exec(line);
      return { title: line.replace(/@\S+/g, '').replace(/<[\d,，\s]+/g, '').trim(), role: roleIds(line), depends_on: deps ? deps[1].split(/[,，\s]+/).filter(Boolean).map(Number) : [] };
    });
    const r = await api('POST', `/projects/${enc(p.id)}/missions`, { title: f.title.value, goal: f.goal.value, items, hours: Number(f.hours.value) || 8, quota_pct: f.quota.value ? Number(f.quota.value) : null, start_at: f.start.value ? new Date(f.start.value).toISOString() : null, stop_when: f.stop.value, rules: f.rules.value });
    PJ.tab = 'missions';
    PJ.openMission = r.id;
    toast(`建好了 ${r.id}：看一下，点“开始”`);
    await loadTab();
    renderProject(true);
  });
}

// ---- decisions, files, history -------------------------------------------------------------------------

function decisionsBody(p) {
  const all = PJ.data.all || [];
  const decisions = all.filter((x) => x.kind === 'decision').reverse();
  const changes = all.filter((x) => x.kind === 'change').reverse();
  const wrap = el('div', { class: 'pj-decisions' });
  wrap.append(section('请你定的事', ...(decisions.length ? decisions.map((x) => {
    const d = x.data;
    const ans = d.answer ? `${d.answer.choice !== null && d.answer.choice !== undefined ? `${circled(d.answer.choice)} ${(d.options[d.answer.choice] || {}).label || ''}` : ''}${d.answer.text ? ` ${d.answer.text}` : ''}${d.answer.via === 'chat' ? `（在对话里定的${d.answer.quote ? `：“${d.answer.quote}”` : ''}）` : ''}` : '';
    return el('div', { class: 'small dec-row' }, el('b', { text: `${x.id} ` }), d.question, el('span', { class: 'muted', text: ` — ${who(p, d.asked_by)} · ${d.status === 'open' ? '等你定' : d.status === 'decided' ? `已定：${ans}` : '撤掉了'}` }));
  }) : [el('p', { class: 'muted small', text: '还没有。' })])));
  wrap.append(section('改动和新角色', ...(changes.length ? changes.map((x) => el('div', { class: 'small dec-row' }, el('b', { text: `${x.id} ` }), x.data.title, el('span', { class: 'muted', text: ` — ${who(p, x.data.proposed_by)} · ${{ proposed: '等你批', approved: '批了', rejected: '没批', done: '已生效' }[x.data.status]}` }))) : [el('p', { class: 'muted small', text: '还没有。' })])));
  return wrap;
}

function filesBody(p) {
  const files = (PJ.data.files || []).slice().reverse();
  const wrap = el('div', { class: 'pj-files' }, el('p', { class: 'muted small', text: '角色用 deliver 交给你的文件。' }));
  if (!files.length) wrap.append(el('p', { class: 'muted small', text: '还没有。' }));
  for (const f of files) {
    wrap.append(el('div', { class: 'file-row small' },
      el('b', { text: `${f.id} ` }), el('span', { class: 'mono', text: f.data.path }),
      el('span', { class: 'muted', text: ` — ${who(p, f.data.by)} · ${fmtTime(f.created_at)}${f.data.size != null ? ` · ${fmtSize(f.data.size)}` : ''}${f.data.note ? ` · ${f.data.note}` : ''}` }),
      f.data.size != null ? el('button', { class: 'small link', text: '预览', onclick: () => openPreview(f.data.path, f.data.size) }) : null,
      el('a', { class: 'small', href: downloadUrl(f.data.path), text: '下载' })));
  }
  return wrap;
}

function historyBody(p) {
  const rows = (PJ.data.history || []).slice().reverse();
  const wrap = el('div', { class: 'pj-history' });
  if (!rows.length) wrap.append(el('p', { class: 'muted small', text: '还没有动静。' }));
  for (const h of rows) wrap.append(el('div', { class: 'small hist-row' }, el('span', { class: 'muted', text: fmtTime(h.at) }), ` ${h.by_label} · ${h.kind} ${h.item_id} · ${h.action}${h.note ? ` · ${h.note}` : ''}`));
  return wrap;
}

// ---- roles: start, handover, edit ----------------------------------------------------------------------

function startRoleDialog(p, r) {
  const text = el('textarea', { rows: 4, placeholder: '第一条消息（可以不写：先开班，等你或别的角色给它派活）' });
  modal(`给「${r.name}」开班`, el('div', { class: 'form' },
    el('p', { class: 'small', text: `${r.duty || r.title || ''}` }),
    el('p', { class: 'muted small', text: `工作目录：${r.cwd}${r.branch ? `（分支 ${r.branch}）` : ''}。它会带着角色卡（项目目标、职责、团队、规矩）和项目工具开工。` }),
    r.workspace_error ? el('p', { class: 'error small', text: r.workspace_error }) : null,
    el('label', {}, '第一条消息', text)),
  [el('button', { type: 'submit', class: 'primary', text: '开班' })], async () => {
    const res = await api('POST', `/projects/${enc(p.id)}/roles/${enc(r.id)}/shift`, { text: text.value.trim() || undefined });
    await refreshSessions();
    openSession(res.session.id);
  });
  setTimeout(() => text.focus(), 50);
}

function handoverDialog(p, r) {
  const skip = el('input', { type: 'checkbox' });
  modal(`给「${r.name}」换班`, el('div', { class: 'form' },
    el('p', { class: 'small', text: '先让现在这一班用 handover_note 写交接说明（做到哪、在等什么、要注意什么），写完自动开新的一班：新会话带着角色卡、交接说明和看板接着做。旧会话留着，随时能翻。' }),
    r.handover ? el('div', { class: 'box small' }, el('b', { text: '现在的交接说明' }), el('div', { text: r.handover })) : null,
    el('label', { class: 'small' }, skip, ' 不用再写了，直接换（用现在的交接说明）')),
  [el('button', { type: 'submit', class: 'primary', text: '换班' })], async () => {
    const res = await api('POST', `/projects/${enc(p.id)}/roles/${enc(r.id)}/handover`, { skip_note: skip.checked });
    toast(res.state === 'started' ? '新的一班开始了' : '在写交接说明，写完自动换班');
    refreshProjects();
    if (res.session) { await refreshSessions(); openSession(res.session.id); }
  });
}

function roleDialog(p, r) {
  const f = {
    name: el('input', { value: r ? r.name : '', placeholder: '例如：后端' }),
    id: el('input', { value: r ? r.id : '', placeholder: '英文编号（可不填），如 backend', disabled: !!r }),
    title: el('input', { value: r ? r.title : '' }),
    duty: el('textarea', { rows: 3, placeholder: '它负责什么' }),
    instructions: el('textarea', { rows: 3, placeholder: '给它的额外要求（可选）：风格、边界、要遵守的规矩' }),
    workspace: el('select', {}, ...Object.entries(WS_LABEL).map(([k, v]) => el('option', { value: k, text: v }))),
    model: el('select', {}, el('option', { value: '', text: '用项目默认' })),
    effort: el('select', {}, el('option', { value: '', text: '用项目默认' }), ...['low', 'medium', 'high', 'xhigh', 'max'].map((v) => el('option', { value: v, text: v }))),
    coordinator: el('input', { type: 'checkbox' }),
  };
  f.duty.value = r ? r.duty : '';
  f.instructions.value = r ? r.instructions : '';
  f.workspace.value = r ? r.workspace : 'worktree';
  f.coordinator.checked = !!(r && r.coordinator);
  loadModels().then(() => { for (const m of (S.catalog && S.catalog.models) || []) f.model.append(el('option', { value: m.value, text: m.display_name || m.value })); f.model.value = r && r.model ? r.model : ''; });
  f.effort.value = r && r.effort ? r.effort : '';
  let templateId = r ? r.template_id : null;
  const from = el('p', { class: 'muted small' });
  const showFrom = () => { from.textContent = templateId ? `来自角色库：${templateId}（字段已经拷进这个项目；改这里不影响角色库）` : ''; from.hidden = !templateId; };
  showFrom();
  const fill = (t) => {
    templateId = t.id;
    f.name.value = t.name; f.title.value = t.title || ''; f.duty.value = t.duty || ''; f.instructions.value = t.instructions || '';
    f.workspace.value = t.workspace || 'worktree'; f.model.value = t.model || ''; f.effort.value = t.effort || '';
    if (!r && !f.id.value) f.id.value = t.id.startsWith('sys:') ? t.id.slice(4) : '';
    showFrom();
  };
  const current = () => ({ name: f.name.value, title: f.title.value, duty: f.duty.value, instructions: f.instructions.value, workspace: f.workspace.value, model: f.model.value || null, effort: f.effort.value || null, coordinator: f.coordinator.checked, color: r ? r.color : undefined });
  const extra = [
    !r ? el('button', { type: 'button', text: '从角色库选', onclick: async () => { const t = await libraryDialog({ pick: 'one' }); if (t && t[0]) fill(t[0]); } }) : null,
    el('button', { type: 'button', text: '存为我的角色模板', title: '把这个角色存进你的角色库，以后的项目可以直接选；还可以分享给其他用户（管理员审核）', onclick: () => {
      const c = current();
      if (!c.name.trim()) return toast('先写名字', true);
      templateDialog(null, { prefill: { ...c, coordinator: c.coordinator }, from: templateId });
    } }),
    r ? el('button', { type: 'button', class: 'danger', text: r.archived ? '恢复' : '撤下这个角色', onclick: () => api('PATCH', `/projects/${enc(p.id)}/roles/${enc(r.id)}`, { archived: !r.archived }).then(() => { toast('好了'); dlg.close(); refreshProjects(); }).catch((e) => toast(errText(e), true)) }) : null,
  ].filter(Boolean);
  const dlg = modal(r ? `角色「${r.name}」` : '加角色', el('div', { class: 'form' },
    el('div', { class: 'row' }, el('label', { class: 'grow' }, '名字', f.name), el('label', { class: 'grow' }, '编号', f.id)),
    el('label', {}, '头衔', f.title), el('label', {}, '职责', f.duty), el('label', {}, '额外要求', f.instructions),
    el('div', { class: 'row' }, el('label', { class: 'grow' }, '工作方式', f.workspace), el('label', { class: 'grow' }, '模型', f.model), el('label', { class: 'grow' }, '思考', f.effort)),
    el('label', { class: 'small' }, f.coordinator, ' 协调者（负责人的主要对接人：拆任务、派活、验收、合并；一个项目最多一个）'),
    from,
    r ? el('p', { class: 'muted small', text: `目录：${r.cwd}${r.branch ? `（${r.branch}）` : ''}。改了职责等，正在跑的会话下一轮生效。` }) : null),
  [...extra, el('button', { type: 'submit', class: 'primary', text: r ? '保存' : '加上' })], async () => {
    const body = { name: f.name.value, title: f.title.value, duty: f.duty.value, instructions: f.instructions.value, workspace: f.workspace.value, model: f.model.value || null, effort: f.effort.value || null, coordinator: f.coordinator.checked };
    if (r) await api('PATCH', `/projects/${enc(p.id)}/roles/${enc(r.id)}`, body);
    else await api('POST', `/projects/${enc(p.id)}/roles`, { ...body, id: f.id.value.trim() || undefined, template: templateId || undefined });
    toast(r ? '改好了' : '加上了');
    refreshProjects();
  });
}

// ---- project settings ----------------------------------------------------------------------------------

function settingsDialog() {
  const p = pj();
  if (!p) return;
  const st = p.settings || {};
  const f = {
    name: el('input', { value: p.name }),
    goal: el('textarea', { rows: 3 }),
    rules: el('textarea', { rows: 4, placeholder: '所有角色都要遵守的规矩（写进每个角色的角色卡）' }),
    model: el('select', {}, el('option', { value: '', text: '服务默认' })),
    worker: el('select', {}, el('option', { value: '', text: '和派活的角色一样' })),
    links: el('input', { value: (st.link_dirs || []).join(','), placeholder: '如 node_modules,.venv' }),
    memory: el('input', { type: 'checkbox' }),
    hub: el('input', { type: 'checkbox' }),
    stop: el('input', { type: 'checkbox' }),
    perHour: el('input', { type: 'number', min: '0', value: String(st.mail_per_hour ?? 30) }),
  };
  f.goal.value = p.goal;
  f.rules.value = p.rules;
  f.memory.checked = st.share_memory !== false;
  f.hub.checked = st.mail_policy === 'hub';
  f.stop.checked = st.stop_check !== false;
  loadModels().then(() => {
    for (const m of (S.catalog && S.catalog.models) || []) { f.model.append(el('option', { value: m.value, text: m.display_name || m.value })); f.worker.append(el('option', { value: m.value, text: m.display_name || m.value })); }
    f.model.value = st.default_model || '';
    f.worker.value = st.worker_model || '';
  });
  const dlg = modal(`项目设置 · ${p.name}`, el('div', { class: 'form' },
    el('label', {}, '名字', f.name), el('label', {}, '目标', f.goal), el('label', {}, '规矩', f.rules),
    el('div', { class: 'row' }, el('label', { class: 'grow' }, '角色默认模型', f.model), el('label', { class: 'grow' }, '临时工 / 验收员模型', f.worker)),
    el('label', {}, '链接进每个 worktree 的目录', f.links),
    el('label', { class: 'small' }, f.memory, ' 所有角色共用一份 Claude Code 记忆（主目录的）'),
    el('label', { class: 'small' }, f.stop, ' 角色改了文件却没更新看板时，提醒它一次再结束'),
    el('label', { class: 'small' }, f.hub, ' 角色之间不直接发消息，都经协调者（最省额度）'),
    el('label', {}, '每个角色每小时最多发几条消息（0 = 不限）', f.perHour),
    el('p', { class: 'muted small', text: `主目录：${p.root}${p.is_git ? '（git 仓库：角色各在自己的 worktree 分支上）' : '（不是 git 仓库：角色共用目录或用子目录）'}` })),
  [el('button', { type: 'button', class: 'danger', text: '删除项目', onclick: async () => {
    if (!confirm(`删除项目「${p.name}」？\n会话、worktree 和文件都留着（会话变成普通会话），看板、消息、值班单记录会删掉。`)) return;
    try { await api('DELETE', `/projects/${enc(p.id)}`); dlg.close(); leaveProject(); $('#empty').hidden = false; history.replaceState(null, '', location.pathname); refreshProjects(); toast('删了'); } catch (e) { toast(errText(e), true); }
  } }), el('button', { type: 'submit', class: 'primary', text: '保存' })], async () => {
    await api('PATCH', `/projects/${enc(p.id)}`, { name: f.name.value, goal: f.goal.value, rules: f.rules.value, settings: {
      default_model: f.model.value || null, worker_model: f.worker.value || null, link_dirs: f.links.value.split(/[,，\s]+/).filter(Boolean),
      share_memory: f.memory.checked, mail_policy: f.hub.checked ? 'hub' : 'mesh', stop_check: f.stop.checked, mail_per_hour: Number(f.perHour.value) || 0,
    } });
    toast('保存了；正在跑的角色下一轮用新的设置');
    refreshProjects();
  });
}

async function editGoal() {
  const p = pj();
  const t = await askText('项目目标', '要做成什么（每个角色的角色卡里都有）', p.goal, false, true);
  if (t === null) return;
  try { await api('PATCH', `/projects/${enc(p.id)}`, { goal: t }); refreshProjects(); } catch (e) { toast(errText(e), true); }
}

// ---- new project ---------------------------------------------------------------------------------------

$('#btn-new-project').addEventListener('click', () => newProjectDialog());

async function newProjectDialog(opts = {}) {
  if (!PJ.templates) { try { PJ.templates = await api('GET', '/projects/templates'); } catch (e) { return toast(errText(e), true); } }
  const me = S.me || {};
  const f = {
    name: el('input', { placeholder: '例如：商城网站', value: opts.root ? basename(opts.root) : '' }),
    root: el('input', { class: 'mono', placeholder: '/path/to/project', value: opts.root || me.root || '' }),
    goal: el('textarea', { rows: 3, placeholder: '要做成什么。越具体越好：给谁用、做到什么程度、有什么限制' }),
    start: el('input', { type: 'checkbox', checked: true }),
  };
  let tpl = PJ.templates[0];
  let roles = clone(tpl.roles);
  const tplBox = el('div', { class: 'tpls' });
  const rolesBox = el('div', { class: 'roles-edit' });
  const browser = el('ul', { class: 'mini-browser', hidden: true });
  const drawTpls = () => tplBox.replaceChildren(...PJ.templates.map((t) => el('label', { class: `tpl${t.id === tpl.id ? ' on' : ''}` },
    el('input', { type: 'radio', name: 'tpl', checked: t.id === tpl.id, onchange: () => { tpl = t; roles = clone(t.roles); drawTpls(); drawRoles(); } }),
    el('b', { text: t.name }), el('div', { class: 'muted small', text: t.description }))));
  const drawRoles = () => rolesBox.replaceChildren(...roles.map((r, i) => el('div', { class: 'role-row' },
    r.template_id ? el('span', { class: 'lib-tag', title: `来自角色库 ${r.template_id}：职责和工作要求都带上了，可以在下面改`, text: '库' }) : el('span', { class: 'lib-tag blank', title: '新写的角色', text: '新' }),
    el('input', { value: r.name || '', placeholder: '名字', oninput: (e) => { r.name = e.target.value; } }),
    el('input', { value: r.duty || '', placeholder: '职责', class: 'grow', oninput: (e) => { r.duty = e.target.value; } }),
    el('select', { onchange: (e) => { r.workspace = e.target.value; } }, ...Object.entries(WS_LABEL).map(([k, v]) => el('option', { value: k, text: v, selected: (r.workspace || 'worktree') === k }))),
    el('label', { class: 'small', title: '协调者' }, el('input', { type: 'radio', name: 'lead', checked: !!r.coordinator, onchange: () => { roles.forEach((x) => { x.coordinator = false; }); r.coordinator = true; } }), '协调'),
    el('button', { type: 'button', class: 'small link', text: '✕', title: '去掉', onclick: () => { roles.splice(i, 1); drawRoles(); } }))),
  el('div', { class: 'row' },
    el('button', { type: 'button', class: 'small', text: '＋ 从角色库选', title: '系统内置的软硬件开发、设计、测试、交付角色，你自己的和大家共享的', onclick: async () => {
      const picked = await libraryDialog({ pick: 'many' });
      if (!picked) return;
      const hasLead = roles.some((x) => x.coordinator);
      for (const t of picked) roles.push({ template_id: t.id, name: t.name, title: t.title, duty: t.duty, instructions: t.instructions, workspace: t.workspace, model: t.model, effort: t.effort, color: t.color, coordinator: !hasLead && t.coordinator && !roles.some((x) => x.coordinator) });
      drawRoles();
    } }),
    el('button', { type: 'button', class: 'small', text: '＋ 新写一个角色', onclick: () => { roles.push({ name: '', duty: '', workspace: 'worktree' }); drawRoles(); } })));
  drawTpls();
  drawRoles();
  const browse = async (path) => {
    try {
      const d = await api('GET', `/fs/list?path=${enc(path || f.root.value || '')}`);
      f.root.value = d.path;
      browser.hidden = false;
      browser.replaceChildren(
        d.parent ? el('li', { text: '↑ 上一级', onclick: () => browse(d.parent) }) : null,
        ...d.entries.filter((x) => x.type === 'dir').map((x) => el('li', { text: `📁 ${x.name}`, onclick: () => browse(`${d.path.replace(/\/+$/, '')}/${x.name}`) })));
      if (!f.name.value) f.name.value = basename(d.path);
    } catch (e) { toast(errText(e), true); }
  };
  const remoteHint = el('p', { class: 'small warn-text', hidden: true, text: '这是远程目录（你电脑上的文件夹）：角色们共用这个文件夹干活（不建 git worktree，“子目录”方式的角色在里面各建一个文件夹），文件都直接写回你的电脑。共享期间要一直开着共享它的那个标签页；断开时角色会停下，消息先排着，重新共享后接着做。' });
  const checkRemote = () => { remoteHint.hidden = !isRemotePath(f.root.value.trim()); };
  f.root.addEventListener('input', checkRemote);
  checkRemote();
  const dlg = modal('新项目', el('div', { class: 'form' },
    el('p', { class: 'muted small', text: '一个项目 = 一个工程目录 + 几个长期在岗的角色。角色各自是一个 Claude Code 会话（git 仓库里各在自己的 worktree 分支上），通过项目信箱和看板协作；你主要跟协调者说话，要你定的事集中在“在你这”。' }),
    el('label', {}, '目录', el('div', { class: 'row' }, f.root, el('button', { type: 'button', text: '浏览…', onclick: () => browse() })), browser),
    remoteHint,
    el('label', {}, '名字', f.name), el('label', {}, '目标', f.goal),
    el('div', {}, el('div', { class: 'small', text: '怎么组队' }), tplBox),
    el('div', {}, el('div', { class: 'small', text: '角色（创建后也能在设置里改）' }), rolesBox),
    el('label', { class: 'small' }, f.start, ' 建好就开工：把目标发给协调者，让它先拆任务、派活')),
  [el('button', { type: 'submit', class: 'primary', text: '创建' })], async () => {
    const list = roles.filter((r) => r.name && r.name.trim()).map((r) => ({ ...r, template: r.template_id || undefined }));
    if (!list.length) throw new Error('至少要一个角色');
    const r = await api('POST', '/projects', { name: f.name.value.trim() || basename(f.root.value), root: f.root.value.trim(), goal: f.goal.value, template: tpl.id, roles: list, start: f.start.checked });
    if (r.start_error) toast(`项目建好了，但协调者没能开工：${r.start_error}`, true);
    else toast(f.start.checked ? '项目建好了，协调者开工了' : '项目建好了');
    PJ.list = await api('GET', '/projects');
    openProject(r.id);
    refreshSessions();
  }, 'wide');
  void dlg;
  setTimeout(() => f.root.focus(), 50);
}

const clone = (x) => JSON.parse(JSON.stringify(x));

// ---- projects in the other dialogs: new session, session settings -------------------------------------

/** A path inside one of the caller's connected remote directories (app.js keeps the list it last saw). */
function isRemotePath(p) {
  return !!p && (typeof lastMounts !== 'undefined') && lastMounts.some((m) => p === m.path || p.startsWith(`${m.path.replace(/\/+$/, '')}/`));
}

/** The project whose directories hold this path (its root or a role's worktree), for a sensible default. */
function projectForPath(path) {
  if (!path) return null;
  const inside = (dir) => dir && (path === dir || path.startsWith(`${dir.replace(/\/+$/, '')}/`));
  const p = PJ.list.find((x) => !x.archived && (inside(x.root) || x.roles.some((r) => inside(r.cwd))));
  return p ? p.id : null;
}

/** The new-session dialog's "加入项目" choice: shown when there are projects; preselected from the directory. */
function fillProjectSelect(sel, row, cwd, onlyIfUnset) {
  const list = PJ.list.filter((p) => !p.archived);
  row.hidden = !list.length;
  if (!list.length) { sel.value = ''; return; }
  const cur = sel.value;
  if (!onlyIfUnset || sel.options.length <= 1) {
    sel.replaceChildren(el('option', { value: '', text: '不加入（独立会话）' }), ...list.map((p) => el('option', { value: p.id, text: p.name })));
  }
  if (!onlyIfUnset || !cur) sel.value = projectForPath(cwd) || '';
  else sel.value = cur;
}

/** Session settings: which project (and role) the session belongs to. */
function fillMembership(st) {
  const box = $('#set-project-box');
  const ps = $('#set-project');
  const rs = $('#set-role');
  const info = st.project || null;
  const mine = PJ.list.filter((p) => !p.archived && p.owner === st.owner);
  box.hidden = !mine.length && !info;
  if (box.hidden) return;
  const fixed = info && (info.kind === 'worker' || info.kind === 'review' || info.past_shift);
  ps.replaceChildren(el('option', { value: '', text: '不属于任何项目' }), ...mine.map((p) => el('option', { value: p.id, text: p.name })));
  ps.value = info ? info.id : '';
  ps.disabled = false;
  const drawRoles = () => {
    const p = PJ.list.find((x) => x.id === ps.value);
    rs.disabled = !p || fixed;
    const kindText = info && info.kind === 'worker' ? '临时工' : info && info.kind === 'review' ? '验收员' : info && info.past_shift ? `「${info.role_name}」以前的班次` : null;
    rs.replaceChildren(...(kindText && p && info && p.id === info.id ? [el('option', { value: '__fixed', text: kindText })] : [
      el('option', { value: '', text: '成员（能看看板、给角色发消息）' }),
      ...(p ? p.roles.filter((r) => !r.archived).map((r) => el('option', { value: r.id, text: `「${r.name}」的当班${r.session && r.session.id !== st.id ? '（换掉现在那一班）' : ''}` })) : []),
    ]));
    rs.value = kindText && p && info && p.id === info.id ? '__fixed' : info && p && info.id === p.id && info.kind === 'role' ? info.role_id : '';
  };
  ps.onchange = drawRoles;
  drawRoles();
  $('#set-project-hint').textContent = fixed
    ? '临时工、验收员和以前的班次只能离开项目（选“不属于任何项目”），不能改身份。'
    : '加入项目后，下一轮起它的系统提示里有项目的角色卡和协作工具（看看板、给角色发消息……）。作为某个角色的当班，它就是那个角色：工作目录换到这个角色的目录（对话接着），原来那一班结束。';
}

/** What the settings dialog would change about the membership: a function doing it, or null. */
function saveMembership(st) {
  if ($('#set-project-box').hidden) return null;
  const info = st.project || null;
  const want = $('#set-project').value;
  const role = $('#set-role').value === '__fixed' ? null : $('#set-role').value;
  const same = info ? want === info.id && ($('#set-role').value === '__fixed' || (info.kind === 'role' ? role === info.role_id : !role)) : !want;
  if (same) return null;
  return async () => {
    if (info) await api('DELETE', `/projects/${enc(info.id)}/sessions/${enc(st.id)}`);
    if (want) await api('POST', `/projects/${enc(want)}/sessions`, role ? { session: st.id, role } : { session: st.id });
    refreshProjects();
  };
}

// ---- the role line above a project session's chat -----------------------------------------------------

function renderChatProject(st) {
  const box = $('#chat-project');
  const hb = $('#btn-handover');
  const info = st.project;
  if (!info) { box.hidden = true; hb.hidden = true; return; }
  box.hidden = false;
  const kind = { role: info.role_name ? `角色「${info.role_name}」${info.coordinator ? '（协调者）' : ''} · 第 ${info.shift_n} 班` : '角色', worker: '临时工', review: '验收员', solo: '接入的会话' }[info.kind];
  box.replaceChildren(...[
    el('span', { class: 'swatch', style: `background: ${info.role_color || 'var(--accent)'}` }),
    el('a', { href: `#p=${info.id}`, text: `项目「${info.name}」`, onclick: (e) => { e.preventDefault(); openProject(info.id); } }),
    ` · ${kind}`,
    info.past_shift ? el('span', { class: 'muted', text: '（以前的班次：这个角色已经换到新会话了）' }) : null].filter(Boolean));
  hb.hidden = !(info.kind === 'role' && !info.past_shift);
  hb.onclick = () => {
    const p = PJ.list.find((x) => x.id === info.id);
    const r = p && p.roles.find((x) => x.id === info.role_id);
    if (p && r) handoverDialog(p, r);
  };
}

// ---- the role library -----------------------------------------------------------------------------------

const LIB = { categories: null, pending: 0, tick: 0 };
const SHARE_TEXT = { pending: '待审核', approved: '已共享', rejected: '被驳回', withdrawn: '已下架' };

async function libraryCategories() {
  if (!LIB.categories) { try { LIB.categories = await api('GET', '/role-templates/categories'); } catch (e) { LIB.categories = {}; } }
  return LIB.categories;
}

/** The admin sees how many shared roles wait for review (on the 角色库 button). */
async function refreshLibraryBadge() {
  const b = $('#btn-roles');
  if (!b) return;
  if (!isAdmin()) { b.textContent = '角色库'; return; }
  try { LIB.pending = (await api('GET', '/role-templates?scope=pending')).length; } catch (e) { return; }
  b.textContent = LIB.pending ? `角色库 ⚑${LIB.pending}` : '角色库';
  b.title = LIB.pending ? `${LIB.pending} 个共享角色等你审核` : '系统内置的角色、你自己的角色模板、大家共享的角色';
}

/**
 * The library: browse, copy, edit, share, review. `pick: 'one' | 'many'` makes it a picker that resolves to the
 * chosen templates (null when cancelled).
 */
function libraryDialog(opts = {}) {
  return new Promise(async (resolve) => {
    const cats = await libraryCategories();
    const state = { tab: opts.pick ? 'all' : 'all', q: '', cat: '', rows: [], chosen: new Map() };
    const search = el('input', { placeholder: '搜名字、职责、标签', oninput: (e) => { state.q = e.target.value.trim().toLowerCase(); draw(); } });
    const catSel = el('select', { onchange: (e) => { state.cat = e.target.value; draw(); } }, el('option', { value: '', text: '全部分类' }), ...Object.entries(cats).map(([k, v]) => el('option', { value: k, text: v })));
    const tabs = el('div', { class: 'lib-tabs' });
    const list = el('div', { class: 'lib-list' });
    const count = el('span', { class: 'muted small' });
    const TABS = [['all', '全部可用'], ['system', '系统默认'], ['mine', '我的'], ['shared', '共享的'], ...(isAdmin() && !opts.pick ? [['pending', '待审核']] : [])];
    const load = async () => {
      try { state.rows = await api('GET', `/role-templates?scope=${state.tab}`); } catch (e) { toast(errText(e), true); state.rows = []; }
      if (isAdmin()) refreshLibraryBadge();
      draw();
    };
    const act = (fn, msg) => async () => { try { await fn(); if (msg) toast(msg); await load(); } catch (e) { toast(errText(e), true); } };
    const draw = () => {
      tabs.replaceChildren(...TABS.map(([k, label]) => el('button', { type: 'button', class: state.tab === k ? 'active' : '', text: k === 'pending' && LIB.pending ? `${label} ${LIB.pending}` : label, onclick: () => { state.tab = k; load(); } })));
      const rows = state.rows.filter((t) => (!state.cat || t.category === state.cat) && (!state.q || [t.name, t.title, t.duty, ...(t.tags || [])].join(' ').toLowerCase().includes(state.q)));
      count.textContent = opts.pick ? `已选 ${state.chosen.size} 个` : `${rows.length} 个`;
      if (!rows.length) { list.replaceChildren(el('p', { class: 'muted small', text: state.tab === 'mine' ? '你还没有自己的角色模板：从系统角色“复制为我的”改一改，或者“新建角色”。' : state.tab === 'pending' ? '没有等审核的。' : '没有。' })); return; }
      const groups = new Map();
      for (const t of rows) groups.set(t.category, [...(groups.get(t.category) || []), t]);
      list.replaceChildren(...[...groups.entries()].map(([cat, items]) => el('div', { class: 'lib-group' },
        el('div', { class: 'lib-group-head', text: `${cats[cat] || cat} · ${items.length}` }),
        ...items.map((t) => card(t)))));
    };
    const badge = (t) => {
      if (t.scope === 'system') return el('span', { class: 'lib-badge sys', text: '系统' });
      if (!t.mine) return el('span', { class: 'lib-badge shared', text: `${t.owner_label} 共享` });
      const st = SHARE_TEXT[t.share_status];
      return el('span', { class: `lib-badge mine ${t.share_status}`, title: t.review_note ? `管理员：${t.review_note}` : '', text: `我的${st ? ` · ${st}` : ''}${t.changed_since_published ? ' · 有改动未共享' : ''}` });
    };
    const card = (t) => {
      const f = state.tab === 'pending' && t.submitted ? { ...t, ...t.submitted } : t;
      const acts = [];
      if (opts.pick) {
        const on = state.chosen.has(t.id);
        acts.push(el('button', { type: 'button', class: `small${on ? ' primary' : ''}`, text: on ? '✓ 已选' : '选这个', onclick: () => {
          if (opts.pick === 'one') { done = true; dlg.close(); resolve([t]); return; }
          if (on) state.chosen.delete(t.id); else state.chosen.set(t.id, t);
          draw();
        } }));
      }
      if (state.tab === 'pending') {
        acts.push(el('button', { type: 'button', class: 'small primary', text: '通过', onclick: act(() => api('POST', `/role-templates/${enc(t.id)}/review`, { approve: true }), '通过了：所有用户都能选用') }));
        acts.push(el('button', { type: 'button', class: 'small', text: '驳回', onclick: async () => { const why = await askText(`驳回「${f.name}」`, '为什么（会告诉作者）', ''); if (why) act(() => api('POST', `/role-templates/${enc(t.id)}/review`, { approve: false, note: why }), '驳回了')(); } }));
      } else if (!opts.pick) {
        if (!t.mine) acts.push(el('button', { type: 'button', class: 'small', text: '复制为我的', title: '存一份到“我的”，可以随便改，不影响原来的', onclick: () => templateDialog(null, { from: t.id, prefill: { ...t, name: t.scope === 'system' ? t.name : `${t.name}（我的）` }, onSaved: load }) }));
        if (t.mine) {
          acts.push(el('button', { type: 'button', class: 'small', text: '编辑', onclick: () => templateDialog(t, { onSaved: load }) }));
          if (t.share_status !== 'pending' && (!t.published || t.changed_since_published)) {
            acts.push(el('button', { type: 'button', class: 'small', text: t.published ? '重新提交分享' : '分享', title: isAdmin() ? '共享给所有用户' : '提交给管理员审核，通过后其他用户也能选用', onclick: async () => {
              const note = isAdmin() ? '' : await askText(`分享「${t.name}」`, '一句话说明它适合什么项目（给管理员看，可以不写）', '', true);
              if (note !== null) act(() => api('POST', `/role-templates/${enc(t.id)}/share`, { note }), isAdmin() ? '共享了' : '提交了，等管理员审核')();
            } }));
          }
          if (t.published || t.share_status === 'pending') acts.push(el('button', { type: 'button', class: 'small', text: '撤回分享', onclick: act(() => api('POST', `/role-templates/${enc(t.id)}/unshare`, {}), '撤回了') }));
          acts.push(el('button', { type: 'button', class: 'small link', text: '删除', onclick: async () => { if (confirm(`删除角色模板「${t.name}」？\n用它建过的项目角色不受影响。`)) act(() => api('DELETE', `/role-templates/${enc(t.id)}`), '删了')(); } }));
        } else if (isAdmin() && t.scope === 'shared') {
          acts.push(el('button', { type: 'button', class: 'small link', text: '下架', onclick: async () => { const why = await askText(`下架「${t.name}」`, '为什么（会告诉作者）', '', true); if (why !== null) act(() => api('POST', `/role-templates/${enc(t.id)}/unshare`, { note: why }), '下架了')(); } }));
        }
      }
      return el('div', { class: `lib-card${state.chosen.has(t.id) ? ' on' : ''}`, style: `border-left-color: ${f.color || 'var(--border)'}` },
        el('div', { class: 'lib-top' }, el('b', { text: f.name }), f.title ? el('span', { class: 'muted small', text: f.title }) : null, badge(t),
          f.coordinator ? el('span', { class: 'lib-badge', text: '可当协调者' }) : null, el('span', { class: 'muted small', text: WS_LABEL[f.workspace] || f.workspace })),
        el('div', { class: 'small lib-duty', text: f.duty }),
        (f.tags || []).length ? el('div', { class: 'muted small', text: f.tags.map((x) => `#${x}`).join(' ') }) : null,
        t.share_note && (t.mine || state.tab === 'pending') ? el('div', { class: 'muted small', text: `分享说明：${t.share_note}` }) : null,
        t.review_note && t.mine ? el('div', { class: 'small warn-text', text: `管理员：${t.review_note}` }) : null,
        el('details', { class: 'small' }, el('summary', { text: '工作要求' }), el('div', { class: 'lib-instr', text: f.instructions || '（没写）' })),
        acts.length ? el('div', { class: 'ib-actions' }, ...acts) : null);
    };
    let done = false;
    const body = el('div', { class: 'form lib' },
      el('p', { class: 'muted small', text: '系统默认的角色谁都能用、不能改；“复制为我的”就成了你的模板，随便改。分享后经管理员审核通过，其他用户也能选用（你之后的改动要重新提交才会更新共享的版本）。项目用某个角色时会拷一份进项目，之后改模板不影响已有项目。' }),
      el('div', { class: 'row' }, search, catSel, opts.pick ? null : el('button', { type: 'button', class: 'small', text: '＋ 新建角色', onclick: () => templateDialog(null, { onSaved: load }) }), count),
      tabs, list);
    const buttons = opts.pick === 'many' ? [el('button', { type: 'submit', class: 'primary', text: '加入所选' })] : [];
    const dlg = modal(opts.pick ? '从角色库选角色' : '角色库', body, buttons, async () => {
      done = true;
      resolve([...state.chosen.values()]);
    }, 'wide');
    dlg.addEventListener('close', () => { if (!done) resolve(null); });
    await load();
  });
}

/** Create (from scratch or as a copy: `from`, `prefill`) or edit one of the caller's templates. */
async function templateDialog(t, o = {}) {
  const cats = await libraryCategories();
  const v = t || o.prefill || {};
  const f = {
    name: el('input', { value: v.name || '', placeholder: '例如：电源工程师' }),
    title: el('input', { value: v.title || '', placeholder: '头衔，例如：DC-DC / BMS' }),
    category: el('select', {}, ...Object.entries(cats).map(([k, label]) => el('option', { value: k, text: label }))),
    duty: el('textarea', { rows: 3, placeholder: '它负责什么（一两句话）' }),
    instructions: el('textarea', { rows: 8, placeholder: '具体的工作要求：交付什么、用什么格式、怎么自查、哪些事要先问负责人……' }),
    workspace: el('select', {}, ...Object.entries(WS_LABEL).map(([k, label]) => el('option', { value: k, text: label }))),
    model: el('select', {}, el('option', { value: '', text: '用项目默认' })),
    effort: el('select', {}, el('option', { value: '', text: '用项目默认' }), ...['low', 'medium', 'high', 'xhigh', 'max'].map((x) => el('option', { value: x, text: x }))),
    color: el('input', { type: 'color', value: /^#[0-9a-f]{6}$/i.test(v.color || '') ? v.color : '#90a4ae' }),
    coordinator: el('input', { type: 'checkbox' }),
    tags: el('input', { value: (v.tags || []).join(','), placeholder: '标签，逗号分开' }),
    share: el('input', { type: 'checkbox' }),
  };
  f.category.value = v.category || 'other';
  f.duty.value = v.duty || '';
  f.instructions.value = v.instructions || '';
  f.workspace.value = v.workspace || 'worktree';
  f.effort.value = v.effort || '';
  f.coordinator.checked = !!v.coordinator;
  loadModels().then(() => { for (const m of (S.catalog && S.catalog.models) || []) f.model.append(el('option', { value: m.value, text: m.display_name || m.value })); f.model.value = v.model || ''; });
  const shareLabel = isAdmin() ? ' 保存后共享给所有用户' : ' 保存后提交分享（管理员审核通过后，其他用户也能选用）';
  modal(t ? `编辑角色模板「${t.name}」` : o.from ? '复制为我的角色模板' : '新建角色模板', el('div', { class: 'form' },
    o.from ? el('p', { class: 'muted small', text: `从 ${o.from} 复制：存成你自己的一份，原来的不变。` }) : null,
    t && t.published ? el('p', { class: 'muted small', text: '这个模板已经共享：你的改动先只对你生效，重新提交分享、审核通过后才更新共享的版本。' }) : null,
    el('div', { class: 'row' }, el('label', { class: 'grow' }, '名字', f.name), el('label', { class: 'grow' }, '头衔', f.title), el('label', { class: 'grow' }, '分类', f.category)),
    el('label', {}, '职责', f.duty), el('label', {}, '工作要求（会写进角色卡）', f.instructions),
    el('div', { class: 'row' }, el('label', { class: 'grow' }, '工作方式', f.workspace), el('label', { class: 'grow' }, '模型', f.model), el('label', { class: 'grow' }, '思考', f.effort), el('label', {}, '颜色', f.color)),
    el('label', {}, '标签', f.tags),
    el('label', { class: 'small' }, f.coordinator, ' 适合当协调者'),
    !t || !t.published || t.changed_since_published ? el('label', { class: 'small' }, f.share, shareLabel) : null),
  [el('button', { type: 'submit', class: 'primary', text: '保存' })], async () => {
    const body = { name: f.name.value, title: f.title.value, category: f.category.value, duty: f.duty.value, instructions: f.instructions.value, workspace: f.workspace.value, model: f.model.value || null, effort: f.effort.value || null, color: f.color.value, coordinator: f.coordinator.checked, tags: f.tags.value.split(/[,，\s]+/).filter(Boolean) };
    let saved;
    if (t) saved = await api('PATCH', `/role-templates/${enc(t.id)}`, body);
    else saved = await api('POST', '/role-templates', { ...body, from: o.from || undefined });
    if (f.share.checked) saved = await api('POST', `/role-templates/${enc(saved.id)}/share`, {});
    toast(f.share.checked ? (isAdmin() ? '保存并共享了' : '保存了，已提交给管理员审核') : '保存到“我的”了');
    if (o.onSaved) o.onSaved(saved);
    refreshLibraryBadge();
  }, 'wide');
}

$('#btn-roles').addEventListener('click', () => libraryDialog());

// ---- small dialogs -------------------------------------------------------------------------------------

/** A dialog with a form; `onSubmit` may throw (the error shows and the dialog stays). */
function modal(title, body, buttons, onSubmit, cls) {
  const err = el('p', { class: 'error', hidden: true });
  const form = el('form', { method: 'dialog' },
    el('h3', { text: title }), body, err,
    el('div', { class: 'dialog-actions' }, el('button', { type: 'button', text: buttons.length ? '取消' : '关闭', onclick: () => dlg.close() }), ...buttons));
  const dlg = el('dialog', { class: `dialog ${cls || ''}` }, form);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const sub = e.submitter;
    if (sub) sub.disabled = true;
    err.hidden = true;
    try { await onSubmit(); dlg.close(); }
    catch (x) { err.textContent = errText(x); err.hidden = false; }
    finally { if (sub) sub.disabled = false; }
  });
  dlg.addEventListener('close', () => dlg.remove());
  document.body.append(dlg);
  dlg.showModal();
  return dlg;
}

/** Ask for a line (or a paragraph) of text: resolves to the text, or null when cancelled. */
function askText(title, placeholder, value, allowEmpty, multi) {
  return new Promise((resolve) => {
    const input = multi || (value || '').length > 60 ? el('textarea', { rows: 4, placeholder }) : el('textarea', { rows: 2, placeholder });
    input.value = value || '';
    let done = false;
    const dlg = modal(title, el('div', { class: 'form' }, input), [el('button', { type: 'submit', class: 'primary', text: '确定' })], async () => {
      if (!allowEmpty && !input.value.trim()) throw new Error('写点内容');
      done = true;
      resolve(input.value.trim());
    });
    dlg.addEventListener('close', () => { if (!done) resolve(null); });
    setTimeout(() => input.focus(), 50);
  });
}

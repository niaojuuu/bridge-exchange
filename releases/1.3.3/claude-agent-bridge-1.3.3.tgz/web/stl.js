'use strict';
/*
 * 3D preview of an STL file (binary or ASCII) for the file preview dialog: plain WebGL, no library.
 * The model is centred and scaled into a unit sphere, Z up (how CAD and slicers export it), flat
 * shaded with face normals computed from the vertices (the file's own are often zero or wrong) and
 * lit from the side facing the camera, so inconsistent winding still looks solid.
 * Drag to rotate, wheel or pinch to zoom, double-click to reset.
 *
 *   const view = StlViewer.show(container, arrayBuffer);   // throws Error with a message to show
 *   view.destroy();                                         // frees the GL context
 */
const StlViewer = (() => {
  const FOV = (35 * Math.PI) / 180;
  const HOME = { yaw: -0.6, pitch: 0.45, zoom: 1 };

  /** → { pos, nor } (9 floats per triangle each), triangle count and the model's size in file units. */
  function parse(buf) {
    const dv = new DataView(buf);
    const n = buf.byteLength >= 84 ? dv.getUint32(80, true) : -1;
    // A binary file may also start with "solid" (SolidWorks does): the exact length decides.
    const binary = n >= 0 && 84 + n * 50 === buf.byteLength;
    const head = new TextDecoder().decode(new Uint8Array(buf, 0, Math.min(buf.byteLength, 256)));
    let pos;
    if (binary || !/^\s*solid\b/.test(head)) {
      if (n <= 0 || 84 + n * 50 > buf.byteLength) throw new Error('不是有效的 STL 文件（或者是空模型）');
      pos = new Float32Array(n * 9);
      for (let i = 0; i < n; i++) {
        const o = 84 + i * 50 + 12; // after the stored normal
        for (let j = 0; j < 9; j++) pos[i * 9 + j] = dv.getFloat32(o + j * 4, true);
      }
    } else {
      const text = new TextDecoder().decode(buf);
      const re = /vertex\s+(\S+)\s+(\S+)\s+(\S+)/g;
      const out = [];
      let m;
      while ((m = re.exec(text))) out.push(+m[1], +m[2], +m[3]);
      if (!out.length || out.length % 9) throw new Error('不是有效的 STL 文件（或者是空模型）');
      pos = new Float32Array(out);
    }

    const min = [Infinity, Infinity, Infinity];
    const max = [-Infinity, -Infinity, -Infinity];
    for (let i = 0; i < pos.length; i += 3) {
      for (let k = 0; k < 3; k++) {
        const v = pos[i + k];
        if (!Number.isFinite(v)) throw new Error('STL 文件里有无效的坐标');
        if (v < min[k]) min[k] = v;
        if (v > max[k]) max[k] = v;
      }
    }
    const size = [0, 1, 2].map((k) => max[k] - min[k]);
    const r = Math.hypot(...size) / 2 || 1;
    for (let i = 0; i < pos.length; i += 3) {
      for (let k = 0; k < 3; k++) pos[i + k] = (pos[i + k] - (min[k] + max[k]) / 2) / r;
    }

    const nor = new Float32Array(pos.length);
    for (let i = 0; i < pos.length; i += 9) {
      const ux = pos[i + 3] - pos[i], uy = pos[i + 4] - pos[i + 1], uz = pos[i + 5] - pos[i + 2];
      const vx = pos[i + 6] - pos[i], vy = pos[i + 7] - pos[i + 1], vz = pos[i + 8] - pos[i + 2];
      let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      const len = Math.hypot(nx, ny, nz) || 1;
      nx /= len; ny /= len; nz /= len;
      for (let j = 0; j < 9; j += 3) { nor[i + j] = nx; nor[i + j + 1] = ny; nor[i + j + 2] = nz; }
    }
    return { pos, nor, triangles: pos.length / 9, size };
  }

  // ---- 4×4 matrices, column-major as WebGL wants them ----

  function mul(a, b) {
    const o = new Float32Array(16);
    for (let c = 0; c < 4; c++) {
      for (let r = 0; r < 4; r++) {
        let s = 0;
        for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k];
        o[c * 4 + r] = s;
      }
    }
    return o;
  }
  const rotX = (t) => { const c = Math.cos(t), s = Math.sin(t); return new Float32Array([1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]); };
  const rotY = (t) => { const c = Math.cos(t), s = Math.sin(t); return new Float32Array([c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1]); };
  const moveZ = (z) => new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, z, 1]);
  function perspective(aspect, near, far) {
    const f = 1 / Math.tan(FOV / 2);
    return new Float32Array([f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) / (near - far), -1, 0, 0, (2 * far * near) / (near - far), 0]);
  }

  const VS = `
    attribute vec3 p; attribute vec3 n;
    uniform mat4 mv; uniform mat4 proj;
    varying vec3 vn; varying vec3 vp;
    void main() {
      vec4 q = mv * vec4(p, 1.0);
      vp = q.xyz;
      vn = (mv * vec4(n, 0.0)).xyz;
      gl_Position = proj * q;
    }`;
  const FS = `
    precision mediump float;
    uniform vec3 color;
    varying vec3 vn; varying vec3 vp;
    void main() {
      vec3 n = normalize(vn);
      if (dot(n, vp) > 0.0) n = -n; // face the camera whatever the winding
      float key = max(dot(n, normalize(vec3(0.4, 0.7, 1.0))), 0.0);
      float fill = max(dot(n, normalize(vec3(-0.7, -0.3, 0.5))), 0.0);
      gl_FragColor = vec4(color * (0.25 + 0.65 * key + 0.25 * fill), 1.0);
    }`;

  function program(gl) {
    const prog = gl.createProgram();
    for (const [type, src] of [[gl.VERTEX_SHADER, VS], [gl.FRAGMENT_SHADER, FS]]) {
      const sh = gl.createShader(type);
      gl.shaderSource(sh, src);
      gl.compileShader(sh);
      if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(`WebGL 着色器编译失败：${gl.getShaderInfoLog(sh)}`);
      gl.attachShader(prog, sh);
    }
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(`WebGL 程序链接失败：${gl.getProgramInfoLog(prog)}`);
    return prog;
  }

  function show(container, buf) {
    const model = parse(buf);
    const canvas = document.createElement('canvas');
    canvas.className = 'stl-canvas';
    const gl = canvas.getContext('webgl', { antialias: true, alpha: true });
    if (!gl) throw new Error('这个浏览器不支持 WebGL，没法显示 3D 模型，可以下载下来看');
    const prog = program(gl);
    gl.useProgram(prog);
    for (const [name, data] of [['p', model.pos], ['n', model.nor]]) {
      gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
      gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
      const loc = gl.getAttribLocation(prog, name);
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, 3, gl.FLOAT, false, 0, 0);
    }
    const u = { mv: gl.getUniformLocation(prog, 'mv'), proj: gl.getUniformLocation(prog, 'proj'), color: gl.getUniformLocation(prog, 'color') };
    gl.uniform3f(u.color, 0.62, 0.7, 0.8);
    gl.enable(gl.DEPTH_TEST);
    gl.clearColor(0, 0, 0, 0);

    const view = { ...HOME };
    let queued = false;
    function render() {
      queued = false;
      const w = canvas.width, h = canvas.height;
      if (!w || !h) return;
      gl.viewport(0, 0, w, h);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      const dist = (1.08 / Math.sin(FOV / 2)) / view.zoom;
      // Z up → Y up, then turn, then step back.
      const mv = mul(moveZ(-dist), mul(rotX(view.pitch), mul(rotY(view.yaw), rotX(-Math.PI / 2))));
      gl.uniformMatrix4fv(u.mv, false, mv);
      gl.uniformMatrix4fv(u.proj, false, perspective(w / h, dist * 0.01, dist + 2));
      gl.drawArrays(gl.TRIANGLES, 0, model.pos.length / 3);
    }
    const draw = () => { if (!queued) { queued = true; requestAnimationFrame(render); } };

    const ro = new ResizeObserver(() => {
      const dpr = window.devicePixelRatio || 1;
      canvas.width = Math.round(canvas.clientWidth * dpr);
      canvas.height = Math.round(canvas.clientHeight * dpr);
      draw();
    });

    const pts = new Map();
    let pinch = 0;
    const spread = () => { const [a, b] = [...pts.values()]; return Math.hypot(a[0] - b[0], a[1] - b[1]); };
    canvas.addEventListener('pointerdown', (e) => { canvas.setPointerCapture(e.pointerId); pts.set(e.pointerId, [e.clientX, e.clientY]); pinch = 0; });
    canvas.addEventListener('pointermove', (e) => {
      const prev = pts.get(e.pointerId);
      if (!prev) return;
      pts.set(e.pointerId, [e.clientX, e.clientY]);
      if (pts.size === 1) {
        view.yaw += (e.clientX - prev[0]) * 0.01;
        view.pitch = Math.max(-1.55, Math.min(1.55, view.pitch + (e.clientY - prev[1]) * 0.01));
      } else if (pts.size === 2) {
        const d = spread();
        if (pinch) view.zoom = Math.max(0.2, Math.min(50, view.zoom * (d / pinch)));
        pinch = d;
      }
      draw();
    });
    const lift = (e) => { pts.delete(e.pointerId); pinch = 0; };
    canvas.addEventListener('pointerup', lift);
    canvas.addEventListener('pointercancel', lift);
    canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      view.zoom = Math.max(0.2, Math.min(50, view.zoom * Math.exp(-e.deltaY * 0.0015)));
      draw();
    }, { passive: false });
    canvas.addEventListener('dblclick', () => { Object.assign(view, HOME); draw(); });

    const fmt = (v) => (v >= 100 ? Math.round(v) : +v.toPrecision(3)).toLocaleString();
    const info = document.createElement('div');
    info.className = 'stl-info';
    info.textContent = `${model.triangles.toLocaleString()} 个三角形 · 尺寸 ${model.size.map(fmt).join(' × ')} · 拖动旋转，滚轮缩放，双击复原`;
    const wrap = document.createElement('div');
    wrap.className = 'stl-view';
    wrap.append(canvas, info);
    container.replaceChildren(wrap);
    ro.observe(canvas);

    return {
      destroy() {
        ro.disconnect();
        const lose = gl.getExtension('WEBGL_lose_context');
        if (lose) lose.loseContext();
      },
    };
  }

  return { show, parse };
})();

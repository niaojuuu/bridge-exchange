'use strict';
/*
 * Remote directories: a folder on the user's computer, shared straight from this page — nothing
 * to install. The user picks a folder (File System Access API: Chrome / Edge on a computer, https
 * or localhost); the page asks for a ticket (with the login cookie), opens the WebSocket on the
 * same origin (so a GitHub Codespaces login comes along) and answers the SFTP requests of sshfs
 * on the server from the folder (src/mounts). The server sees only the chosen folder: no `..`, no
 * symlinks, excluded names invisible; requests are answered strictly in order (sshfs pipelines
 * them and relies on that: an OPEN that creates a file, then an LSTAT of it, back to back).
 *
 * What a browser cannot do: set modification times or permissions (silently ignored), make
 * symlinks, show folders' times. A browser writes to a scratch copy that replaces the file when
 * it is closed; sshfs closes files after the program did (FUSE release is asynchronous), so before
 * anything else looks at a file with unsaved writes they are saved first (`settle`) — a write
 * followed by a read always reads what was written. Saving copies the file: big files are slow.
 *
 * Two extensions of our own help the server's cache (src/mounts/mirror.ts), which answers most requests
 * without asking here: cab-read gives a whole small file in one round trip (or a handle when it is big), and
 * cab-watch means this page tells the server what changed in the folder on this computer (`Watcher`: the
 * browser's FileSystemObserver where there is one, otherwise a walk of the folder every few seconds).
 *
 * Exposes `CabRemote` (BrowserSftp, PacketSplitter, Share, Watcher). No dependencies; also loaded by the
 * tests in Node with a stand-in for the directory handle.
 */
(function (global) {
  const FXP = {
    INIT: 1, VERSION: 2, OPEN: 3, CLOSE: 4, READ: 5, WRITE: 6, LSTAT: 7, FSTAT: 8, SETSTAT: 9, FSETSTAT: 10,
    OPENDIR: 11, READDIR: 12, REMOVE: 13, MKDIR: 14, RMDIR: 15, REALPATH: 16, STAT: 17, RENAME: 18, READLINK: 19, SYMLINK: 20,
    STATUS: 101, HANDLE: 102, DATA: 103, NAME: 104, ATTRS: 105, EXTENDED: 200, EXTENDED_REPLY: 201,
  };
  const FX = { OK: 0, EOF: 1, NO_SUCH_FILE: 2, PERMISSION_DENIED: 3, FAILURE: 4, BAD_MESSAGE: 5, OP_UNSUPPORTED: 8 };
  const PF = { READ: 0x01, WRITE: 0x02, APPEND: 0x04, CREAT: 0x08, TRUNC: 0x10, EXCL: 0x20 };
  const ATTR = { SIZE: 0x01, UIDGID: 0x02, PERMISSIONS: 0x04, ACMODTIME: 0x08, EXTENDED: 0x80000000 };
  const S_IFDIR = 0o040000;
  const S_IFREG = 0o100000;
  const MAX_READ = 4 * 1024 * 1024;
  const MAX_PACKET = 8 * 1024 * 1024;
  const MAX_HANDLES = 4096;
  const READDIR_BATCH = 100;
  const EXT_READ = 'cab-read@claude-agent-bridge';
  const EXT_WATCH = 'cab-watch@claude-agent-bridge';
  const enc = new TextEncoder();
  const dec = new TextDecoder();

  function sftpError(status, message) {
    const e = new Error(message);
    e.sftpStatus = status;
    return e;
  }

  /** DOMExceptions of the File System Access API → SFTP status. */
  function fsError(e) {
    if (e && e.sftpStatus !== undefined) return e;
    const name = e && e.name;
    const msg = (e && e.message) || String(e);
    if (name === 'NotFoundError' || name === 'TypeMismatchError') return sftpError(FX.NO_SUCH_FILE, msg);
    if (name === 'NotAllowedError' || name === 'SecurityError') return sftpError(FX.PERMISSION_DENIED, msg);
    if (name === 'TypeError') return sftpError(FX.PERMISSION_DENIED, `name not allowed here: ${msg}`);
    if (name === 'InvalidModificationError') return sftpError(FX.FAILURE, `folder not empty: ${msg}`);
    return sftpError(FX.FAILURE, msg);
  }

  class Reader {
    constructor(u8, off) {
      this.b = u8;
      this.v = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
      this.o = off;
    }
    need(n) { if (this.o + n > this.b.length) throw sftpError(FX.BAD_MESSAGE, 'truncated packet'); }
    left() { return this.b.length - this.o; }
    u8() { this.need(1); return this.b[this.o++]; }
    u32() { this.need(4); const x = this.v.getUint32(this.o); this.o += 4; return x; }
    u64() { this.need(8); const x = Number(this.v.getBigUint64(this.o)); this.o += 8; return x; }
    bytes() { const n = this.u32(); this.need(n); const x = this.b.subarray(this.o, this.o + n); this.o += n; return x; }
    str() { return dec.decode(this.bytes()); }
    attrs() {
      const flags = this.u32();
      const a = {};
      if (flags & ATTR.SIZE) a.size = this.u64();
      if (flags & ATTR.UIDGID) { a.uid = this.u32(); a.gid = this.u32(); }
      if (flags & ATTR.PERMISSIONS) a.perm = this.u32();
      if (flags & ATTR.ACMODTIME) { a.atime = this.u32(); a.mtime = this.u32(); }
      if (flags & ATTR.EXTENDED) { const n = this.u32(); for (let i = 0; i < n; i++) { this.bytes(); this.bytes(); } }
      return a;
    }
  }

  class Writer {
    constructor() { this.parts = []; this.len = 0; }
    push(u8) { this.parts.push(u8); this.len += u8.length; return this; }
    u8(x) { return this.push(Uint8Array.of(x)); }
    u32(x) { const b = new Uint8Array(4); new DataView(b.buffer).setUint32(0, x >>> 0); return this.push(b); }
    u64(x) { const b = new Uint8Array(8); new DataView(b.buffer).setBigUint64(0, BigInt(Math.max(0, Math.floor(x)))); return this.push(b); }
    bytes(x) { const b = typeof x === 'string' ? enc.encode(x) : x; this.u32(b.length); return this.push(b); }
    attrs(a) {
      let flags = 0;
      if (a.size !== undefined) flags |= ATTR.SIZE;
      if (a.uid !== undefined && a.gid !== undefined) flags |= ATTR.UIDGID;
      if (a.perm !== undefined) flags |= ATTR.PERMISSIONS;
      if (a.atime !== undefined && a.mtime !== undefined) flags |= ATTR.ACMODTIME;
      this.u32(flags);
      if (a.size !== undefined) this.u64(a.size);
      if (flags & ATTR.UIDGID) { this.u32(a.uid); this.u32(a.gid); }
      if (a.perm !== undefined) this.u32(a.perm);
      if (flags & ATTR.ACMODTIME) { this.u32(a.atime); this.u32(a.mtime); }
      return this;
    }
    /** Length-prefixed packet. */
    packet() {
      const out = new Uint8Array(4 + this.len);
      new DataView(out.buffer).setUint32(0, this.len);
      let o = 4;
      for (const p of this.parts) { out.set(p, o); o += p.length; }
      return out;
    }
  }

  /** The byte stream → SFTP packets (type byte + payload, length prefix removed). */
  class PacketSplitter {
    constructor() { this.buf = new Uint8Array(0); }
    push(chunk) {
      if (this.buf.length) { const b = new Uint8Array(this.buf.length + chunk.length); b.set(this.buf); b.set(chunk, this.buf.length); this.buf = b; }
      else this.buf = chunk;
      const out = [];
      while (this.buf.length >= 4) {
        const n = new DataView(this.buf.buffer, this.buf.byteOffset, 4).getUint32(0);
        if (n < 1 || n > MAX_PACKET) throw new Error(`bad SFTP packet length ${n}`);
        if (this.buf.length < 4 + n) break;
        out.push(this.buf.slice(4, 4 + n));
        this.buf = this.buf.subarray(4 + n);
      }
      return out;
    }
  }

  function globToRegExp(glob) {
    const re = glob.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.');
    return new RegExp(`^${re}$`, 'i');
  }

  const secs = (ms) => Math.min(0xffffffff, Math.max(0, Math.floor(ms / 1000)));

  /**
   * An SFTP server on a FileSystemDirectoryHandle. `handle(packet)` takes one request (type byte +
   * payload) and resolves to the length-prefixed reply, strictly in order.
   */
  class BrowserSftp {
    constructor(root, opts = {}) {
      this.root = root;
      this.readOnly = !!opts.readOnly;
      this.excludes = (opts.exclude || []).map((g) => g.trim()).filter(Boolean).map(globToRegExp);
      this.uid = opts.uid || 0;
      this.gid = opts.gid || 0;
      this.handles = new Map();
      this.nextHandle = 1;
      this.tail = Promise.resolve();
      this.dirs = new Map(); // path → directory handle
      this.pending = new Map(); // path → handles with unsaved writes
      this.started = secs(Date.now()); // folders have no times in this API: show when sharing began
    }

    handle(pkt) {
      const run = this.tail.then(() => this.process(pkt));
      this.tail = run.catch(() => {});
      return run;
    }

    /** The connection ended: files being written are abandoned (nothing half-written is kept). */
    async close() {
      const all = [...this.handles.values()];
      this.handles.clear();
      this.pending.clear();
      for (const h of all) if (h.writable) { try { await h.writable.abort(); } catch (e) { /* gone */ } }
    }

    async process(pkt) {
      const type = pkt[0];
      const r = new Reader(pkt, 1);
      if (type === FXP.INIT) {
        return new Writer().u8(FXP.VERSION).u32(3)
          .bytes('posix-rename@openssh.com').bytes('1')
          .bytes('statvfs@openssh.com').bytes('2')
          .bytes('fsync@openssh.com').bytes('1')
          .bytes(EXT_READ).bytes('1')
          .bytes(EXT_WATCH).bytes('1')
          .packet();
      }
      let id = 0;
      try {
        id = r.u32();
        return await this.dispatch(type, id, r);
      } catch (e) {
        const err = fsError(e);
        if (err.sftpStatus === FX.NO_SUCH_FILE || err.sftpStatus === FX.FAILURE) this.dirs.clear(); // a cached folder may be gone
        return this.status(id, err.sftpStatus, err.message);
      }
    }

    async dispatch(type, id, r) {
      switch (type) {
        case FXP.STAT:
        case FXP.LSTAT: {
          const p = r.str();
          await this.settle(p);
          return this.attrsReply(id, await this.attrsOf(await this.entry(p)));
        }
        case FXP.FSTAT: {
          const h = this.fileHandle(r.bytes());
          if (h.writable) return this.attrsReply(id, { size: h.size, uid: this.uid, gid: this.gid, perm: S_IFREG | 0o644, atime: secs(Date.now()), mtime: secs(Date.now()) });
          return this.attrsReply(id, await this.attrsOf({ kind: 'file', handle: h.fh }));
        }
        case FXP.OPEN: return this.open(id, r.str(), r.u32(), r.attrs());
        case FXP.CLOSE: {
          const key = hex(r.bytes());
          const h = this.handles.get(key);
          if (!h) throw sftpError(FX.FAILURE, 'unknown handle');
          this.handles.delete(key);
          this.forget(h);
          if (h.writable) await h.writable.close(); // commits what was written
          return this.status(id, FX.OK);
        }
        case FXP.READ: {
          const h = this.fileHandle(r.bytes());
          const offset = r.u64();
          const len = r.u32();
          if (len > MAX_READ) throw sftpError(FX.FAILURE, 'read too large');
          if (h.writable && h.dirty) await this.save(h); // reading back what this handle wrote
          const data = await this.readAt(h, offset, len);
          if (!data.length) return this.status(id, FX.EOF, 'end of file');
          return new Writer().u8(FXP.DATA).u32(id).bytes(data).packet();
        }
        case FXP.WRITE: {
          const h = this.fileHandle(r.bytes());
          const offset = r.u64();
          const data = r.bytes().slice();
          if (!h.writable) throw sftpError(FX.PERMISSION_DENIED, 'not opened for writing');
          const position = h.append ? h.size : offset;
          await h.writable.write({ type: 'write', position, data });
          h.size = Math.max(h.size, position + data.length);
          h.dirty = true;
          return this.status(id, FX.OK);
        }
        case FXP.SETSTAT: {
          const sp = r.str();
          await this.settle(sp);
          const e = await this.entry(sp);
          const a = r.attrs();
          this.writeAllowed();
          // Times and permissions cannot be set from a browser: accepted and ignored, so cp -p, tar, touch carry on.
          if (a.size !== undefined && e.kind === 'file') {
            const w = await e.handle.createWritable({ keepExistingData: true });
            await w.truncate(a.size);
            await w.close();
          }
          return this.status(id, FX.OK);
        }
        case FXP.FSETSTAT: {
          const h = this.fileHandle(r.bytes());
          const a = r.attrs();
          this.writeAllowed();
          if (a.size !== undefined) {
            if (h.writable) { await h.writable.truncate(a.size); h.size = a.size; }
            else { const w = await h.fh.createWritable({ keepExistingData: true }); await w.truncate(a.size); await w.close(); }
          }
          return this.status(id, FX.OK);
        }
        case FXP.OPENDIR: {
          const e = await this.entry(r.str());
          if (e.kind !== 'dir') throw sftpError(FX.NO_SUCH_FILE, 'not a folder');
          return this.handleReply(id, { kind: 'dir', dh: e.handle, list: null, pos: 0 });
        }
        case FXP.READDIR: {
          const h = this.handles.get(hex(r.bytes()));
          if (!h || h.kind !== 'dir') throw sftpError(FX.FAILURE, 'unknown handle');
          return this.readdir(id, h);
        }
        case FXP.REMOVE: {
          const p = r.str();
          this.writeAllowed();
          await this.settle(p);
          const e = await this.entry(p);
          if (e.kind === 'dir') throw sftpError(FX.FAILURE, 'is a folder');
          await e.parent.removeEntry(e.name);
          return this.status(id, FX.OK);
        }
        case FXP.MKDIR: {
          const p = r.str();
          r.attrs();
          this.writeAllowed();
          const { parent, name } = await this.creatable(p);
          if (await kindOf(parent, name)) throw sftpError(FX.FAILURE, 'already exists');
          await parent.getDirectoryHandle(name, { create: true });
          return this.status(id, FX.OK);
        }
        case FXP.RMDIR: {
          const p = r.str();
          this.writeAllowed();
          const e = await this.entry(p);
          if (!e.parent) throw sftpError(FX.PERMISSION_DENIED, 'the shared folder itself');
          if (e.kind !== 'dir') throw sftpError(FX.FAILURE, 'not a folder');
          await e.parent.removeEntry(e.name);
          this.dirs.clear();
          return this.status(id, FX.OK);
        }
        case FXP.REALPATH: {
          const p = `/${this.segments(r.str(), false).join('/')}`;
          return new Writer().u8(FXP.NAME).u32(id).u32(1).bytes(p).bytes(p).attrs({}).packet();
        }
        case FXP.RENAME: return this.rename(id, r.str(), r.str(), false);
        case FXP.READLINK: throw sftpError(FX.NO_SUCH_FILE, 'no symlinks here');
        case FXP.SYMLINK: throw sftpError(FX.OP_UNSUPPORTED, 'symlinks cannot be created in a remote directory');
        case FXP.EXTENDED: {
          const name = r.str();
          if (name === 'posix-rename@openssh.com') return this.rename(id, r.str(), r.str(), true);
          if (name === 'fsync@openssh.com') { this.fileHandle(r.bytes()); return this.status(id, FX.OK); } // committed at close
          if (name === EXT_READ) {
            const p = r.str();
            const max = r.u32();
            // a copy on the server: its size and time (ms), so "unchanged" can be said instead of sending it again
            const have = r.left() >= 16 ? { size: r.u64(), mtimeMs: r.u64() } : null;
            return this.readWhole(id, p, max, have);
          }
          if (name === 'statvfs@openssh.com') {
            // A browser does not tell how big the disk is: report plenty of room.
            const w = new Writer().u8(FXP.EXTENDED_REPLY).u32(id);
            const blocks = 2 ** 28;
            for (const v of [4096, 4096, blocks, blocks, blocks, 2 ** 24, 2 ** 24, 2 ** 24, 0, this.readOnly ? 1 : 0, 255]) w.u64(v);
            return w.packet();
          }
          throw sftpError(FX.OP_UNSUPPORTED, `extension ${name} not supported`);
        }
        default:
          throw sftpError(FX.OP_UNSUPPORTED, `request type ${type} not supported`);
      }
    }

    // ---- paths --------------------------------------------------------------------------------

    segments(p, forCreate) {
      const segs = p.split('/').filter((s) => s && s !== '.');
      for (const s of segs) {
        if (s === '..') throw sftpError(FX.PERMISSION_DENIED, '".." is not allowed');
        if (s.includes('\0') || s.includes('\\')) throw sftpError(forCreate ? FX.PERMISSION_DENIED : FX.NO_SUCH_FILE, `"${s}" is not a valid name`);
        if (this.excludes.some((re) => re.test(s))) throw sftpError(forCreate ? FX.PERMISSION_DENIED : FX.NO_SUCH_FILE, `"${s}" is excluded from sharing`);
      }
      return segs;
    }

    async dirAt(segs) {
      let cur = this.root;
      for (let i = 0; i < segs.length; i++) {
        const key = segs.slice(0, i + 1).join('/');
        let next = this.dirs.get(key);
        if (!next) {
          try { next = await cur.getDirectoryHandle(segs[i]); } catch (e) { throw fsError(e); }
          this.dirs.set(key, next);
        }
        cur = next;
      }
      return cur;
    }

    /** An existing entry: { kind: 'file' | 'dir', handle, parent, name } (parent null for the root). */
    async entry(p) {
      const segs = this.segments(p, false);
      if (!segs.length) return { kind: 'dir', handle: this.root, parent: null, name: '' };
      const parent = await this.dirAt(segs.slice(0, -1));
      const name = segs[segs.length - 1];
      const kind = await kindOf(parent, name);
      if (!kind) throw sftpError(FX.NO_SUCH_FILE, `no ${p}`);
      const handle = kind === 'file' ? await parent.getFileHandle(name) : await parent.getDirectoryHandle(name);
      return { kind, handle, parent, name };
    }

    /** Where a new entry named by `p` goes: an existing parent folder, an allowed name. */
    async creatable(p) {
      const segs = this.segments(p, true);
      if (!segs.length) throw sftpError(FX.PERMISSION_DENIED, 'the shared folder itself');
      return { parent: await this.dirAt(segs.slice(0, -1)), name: segs[segs.length - 1] };
    }

    writeAllowed() {
      if (this.readOnly) throw sftpError(FX.PERMISSION_DENIED, 'this folder is shared read-only');
    }

    // ---- requests -----------------------------------------------------------------------------

    async open(id, p, pflags, a) {
      const write = (pflags & (PF.WRITE | PF.APPEND | PF.CREAT | PF.TRUNC)) !== 0;
      if (write) this.writeAllowed();
      await this.settle(p);
      let fh;
      try {
        const e = await this.entry(p);
        if (e.kind === 'dir') throw sftpError(FX.FAILURE, 'is a folder');
        if (pflags & PF.CREAT && pflags & PF.EXCL) throw sftpError(FX.FAILURE, 'already exists');
        fh = e.handle;
      } catch (e) {
        if (e.sftpStatus !== FX.NO_SUCH_FILE || !(pflags & PF.CREAT)) throw e;
        const { parent, name } = await this.creatable(p);
        try { fh = await parent.getFileHandle(name, { create: true }); } catch (err) { throw fsError(err); }
      }
      const h = { kind: 'file', fh, file: null, writable: null, size: 0, append: (pflags & PF.APPEND) !== 0 };
      if (write) {
        const keep = !(pflags & PF.TRUNC);
        h.size = keep ? (await fh.getFile()).size : 0;
        h.writable = await fh.createWritable({ keepExistingData: keep });
        h.key = this.segments(p, false).join('/');
        h.dirty = !keep; // a truncation is a change too
        if (!this.pending.has(h.key)) this.pending.set(h.key, new Set());
        this.pending.get(h.key).add(h);
      }
      void a;
      return this.handleReply(id, h);
    }

    /** Save what handles still hold for `p` (see the top of this file), so it can be looked at. */
    async settle(p) {
      let key;
      try { key = this.segments(p, false).join('/'); } catch (e) { return; } // the request itself reports that
      for (const h of this.pending.get(key) || []) if (h.dirty) await this.save(h);
    }

    /** Commit a handle's writes and go on with a fresh scratch copy of the saved file. */
    async save(h) {
      await h.writable.close();
      h.writable = await h.fh.createWritable({ keepExistingData: true });
      h.dirty = false;
      h.file = null;
    }

    forget(h) {
      const set = h.key !== undefined && this.pending.get(h.key);
      if (!set) return;
      set.delete(h);
      if (!set.size) this.pending.delete(h.key);
    }

    /** Bytes [offset, offset+len) of the file as it was when first read through this handle. */
    async readAt(h, offset, len) {
      for (let attempt = 0; ; attempt++) {
        if (!h.file) h.file = await h.fh.getFile();
        try {
          return new Uint8Array(await h.file.slice(offset, offset + len).arrayBuffer());
        } catch (e) {
          // changed on disk since: read the new version
          if (attempt > 0 || (e && e.name !== 'NotReadableError')) throw e;
          h.file = null;
        }
      }
    }

    async readdir(id, h) {
      if (!h.list) {
        h.list = [];
        for await (const [name, handle] of h.dh.entries()) {
          if (this.excludes.some((re) => re.test(name))) continue;
          h.list.push({ name, handle });
        }
      }
      const w = new Writer();
      let count = 0;
      while (h.pos < h.list.length && count === 0) {
        // the browser looks a batch up at once: several times faster than one by one
        const batch = h.list.slice(h.pos, h.pos + READDIR_BATCH);
        h.pos += batch.length;
        const all = await Promise.all(batch.map(({ handle }) => this.attrsOf({ kind: handle.kind === 'directory' ? 'dir' : 'file', handle }).catch(() => null)));
        batch.forEach(({ name }, i) => {
          if (!all[i]) return; // gone meanwhile
          w.bytes(name).bytes(longname(name, all[i])).attrs(all[i]);
          count++;
        });
      }
      if (!count) return this.status(id, FX.EOF, 'end of folder');
      const head = new Writer().u8(FXP.NAME).u32(id).u32(count);
      for (const part of w.parts) head.push(part);
      return head.packet();
    }

    async rename(id, from, to, overwrite) {
      this.writeAllowed();
      await this.settle(from);
      await this.settle(to);
      const src = await this.entry(from);
      if (!src.parent) throw sftpError(FX.PERMISSION_DENIED, 'the shared folder itself');
      const { parent: dst, name } = await this.creatable(to);
      const there = await kindOf(dst, name);
      if (there && !overwrite) throw sftpError(FX.FAILURE, 'the target already exists');
      if (there) {
        if (there !== src.kind) throw sftpError(FX.FAILURE, there === 'dir' ? 'the target is a folder' : 'the target is a file');
        await dst.removeEntry(name); // a folder only when empty, like rename(2)
      }
      this.dirs.clear();
      if (typeof src.handle.move === 'function') {
        try { await src.handle.move(dst, name); return this.status(id, FX.OK); } catch (e) { if (e && e.name === 'NotFoundError') throw e; /* not supported here: copy below */ }
      }
      await copyEntry(src, dst, name);
      await src.parent.removeEntry(src.name, { recursive: true });
      return this.status(id, FX.OK);
    }

    async attrsOf(e) {
      if (e.kind === 'dir') return { size: 4096, uid: this.uid, gid: this.gid, perm: S_IFDIR | 0o755, atime: this.started, mtime: this.started };
      return this.fileAttrs(await e.handle.getFile());
    }

    fileAttrs(f) {
      return { size: f.size, uid: this.uid, gid: this.gid, perm: S_IFREG | (this.readOnly ? 0o444 : 0o644), atime: secs(f.lastModified), mtime: secs(f.lastModified) };
    }

    /**
     * cab-read: the whole file when it is at most `max` bytes (kind 1), else a handle to read it with, as
     * OPEN would give (kind 2), or — `have` (the server's copy) still matching size and time — kind 3,
     * "unchanged", without content. Its attributes either way, then its time in ms (the server keeps that
     * with a copy). In order with everything else, like OPEN.
     */
    async readWhole(id, p, max, have = null) {
      await this.settle(p);
      const e = await this.entry(p);
      if (e.kind === 'dir') throw sftpError(FX.FAILURE, 'is a folder');
      for (let attempt = 0; ; attempt++) {
        const f = await e.handle.getFile();
        const ms = Math.floor(f.lastModified);
        const w = new Writer().u8(FXP.EXTENDED_REPLY).u32(id);
        if (have && have.size === f.size && have.mtimeMs === ms) return w.u8(3).attrs(this.fileAttrs(f)).bytes(new Uint8Array(0)).u64(ms).packet();
        if (f.size > Math.min(max, MAX_READ)) {
          const key = this.addHandle({ kind: 'file', fh: e.handle, file: f, writable: null, size: 0, append: false });
          return w.u8(2).attrs(this.fileAttrs(f)).bytes(key).u64(ms).packet();
        }
        try {
          return w.u8(1).attrs(this.fileAttrs(f)).bytes(new Uint8Array(await f.arrayBuffer())).u64(ms).packet();
        } catch (err) {
          // changed on disk while being read: once more with the new version
          if (attempt > 0 || (err && err.name !== 'NotReadableError')) throw err;
        }
      }
    }

    attrsReply(id, a) { return new Writer().u8(FXP.ATTRS).u32(id).attrs(a).packet(); }
    status(id, code, msg = '') { return new Writer().u8(FXP.STATUS).u32(id).u32(code).bytes(msg).bytes('').packet(); }

    handleReply(id, h) {
      return new Writer().u8(FXP.HANDLE).u32(id).bytes(this.addHandle(h)).packet();
    }

    addHandle(h) {
      if (this.handles.size >= MAX_HANDLES) throw sftpError(FX.FAILURE, 'too many open files');
      const key = new Uint8Array(4);
      new DataView(key.buffer).setUint32(0, this.nextHandle++ >>> 0);
      this.handles.set(hex(key), h);
      return key;
    }

    fileHandle(raw) {
      const h = this.handles.get(hex(raw));
      if (!h || h.kind !== 'file') throw sftpError(FX.FAILURE, 'unknown handle');
      return h;
    }
  }

  /** 'file' | 'dir' | null */
  async function kindOf(parent, name) {
    try { await parent.getFileHandle(name); return 'file'; } catch (e) {
      if (e && e.name === 'TypeMismatchError') return 'dir';
      if (e && (e.name === 'NotFoundError' || e.name === 'TypeError')) return null;
      throw fsError(e);
    }
  }

  /** Where move() is not available: copy (a folder recursively). */
  async function copyEntry(src, dst, name) {
    if (src.kind === 'file') {
      const out = await dst.getFileHandle(name, { create: true });
      const w = await out.createWritable();
      await w.write(await src.handle.getFile());
      await w.close();
      return;
    }
    const d = await dst.getDirectoryHandle(name, { create: true });
    for await (const [n, h] of src.handle.entries()) {
      await copyEntry({ kind: h.kind === 'directory' ? 'dir' : 'file', handle: h }, d, n);
    }
  }

  function hex(u8) { let s = ''; for (const b of u8) s += b.toString(16).padStart(2, '0'); return s; }

  function longname(name, a) {
    const p = a.perm || 0;
    const bits = 'rwxrwxrwx'.split('').map((c, i) => (p & (1 << (8 - i)) ? c : '-')).join('');
    return `${p & S_IFDIR ? 'd' : '-'}${bits} 1 ${a.uid} ${a.gid} ${a.size} ${new Date(a.mtime * 1000).toISOString().slice(0, 16).replace('T', ' ')} ${name}`;
  }

  // ---- changes on this computer ------------------------------------------------------------------

  const POLL_MIN_MS = 3000;
  const POLL_MAX_MS = 60000;
  // with an observer the walk is only a safety net (see Watcher)
  const SAFETY_MIN_MS = 30000;
  const SAFETY_MAX_MS = 600000;
  const FLUSH_MS = 100;
  const MAX_PATHS = 1000;

  /**
   * Tells the server what changed in the shared folder on this computer, so its cache does not serve old
   * content: `send({ type: 'changed', paths: [[path, 'm' | 's']] })` — 'm' a file's content or size, 's'
   * something appeared, went or moved (its folder gets listed again) — or `{ all: true }` when it cannot
   * tell. The browser's FileSystemObserver where there is one; otherwise the folder is walked every few
   * seconds (longer for big folders) and compared. Excluded names are left out, as everywhere.
   *
   * The folder is walked with an observer too, just rarely: an observer that stays silent (a network
   * drive, say) would otherwise leave the server serving old content for as long as the folder is shared,
   * with nobody the wiser. This puts a limit on that.
   */
  class Watcher {
    constructor(root, opts) {
      this.root = root;
      this.excludes = (opts.exclude || []).map((g) => g.trim()).filter(Boolean).map(globToRegExp);
      this.send = opts.send;
      this.pollMin = opts.pollMinMs || POLL_MIN_MS;
      this.safetyMin = opts.safetyMinMs || SAFETY_MIN_MS;
      this.mode = null;
      this.pending = new Map();
      this.all = false;
      this.flushTimer = null;
      this.pollTimer = null;
      this.snapshot = null;
      this.stopped = false;
    }

    async start() {
      const Observer = typeof FileSystemObserver === 'function' ? FileSystemObserver : null;
      if (Observer) {
        try {
          this.observer = new Observer((records) => this.onRecords(records));
          await this.observer.observe(this.root, { recursive: true });
          if (this.stopped) { this.observer.disconnect(); return; }
          this.mode = 'observer';
          void this.poll();
          return;
        } catch (e) { this.observer = null; /* not for this folder: walk it instead */ }
      }
      this.mode = 'poll';
      void this.poll();
    }

    stop() {
      this.stopped = true;
      clearTimeout(this.flushTimer);
      clearTimeout(this.pollTimer);
      if (this.observer) { try { this.observer.disconnect(); } catch (e) { /* gone */ } }
    }

    excluded(parts) { return parts.some((s) => this.excludes.some((re) => re.test(s))); }

    onRecords(records) {
      for (const r of records) {
        if (r.type === 'unknown') { this.all = true; continue; }
        if (r.type === 'errored') {
          // the browser stopped watching: walk the folder from now on
          this.all = true;
          if (this.observer) { try { this.observer.disconnect(); } catch (e) { /* gone */ } this.observer = null; }
          if (this.mode !== 'poll' && !this.stopped) {
            this.mode = 'poll';
            // the next walk comes soon now, not after the long wait of the safety net
            if (this.pollTimer) { clearTimeout(this.pollTimer); this.pollTimer = null; void this.poll(); }
          }
          continue;
        }
        const parts = r.relativePathComponents || [];
        if (this.excluded(parts)) continue;
        const kind = r.type === 'modified' && r.changedHandle && r.changedHandle.kind === 'file' ? 'm' : 's';
        this.note(`/${parts.join('/')}`, kind);
        if (r.type === 'moved' && r.relativePathMovedFrom && !this.excluded(r.relativePathMovedFrom)) this.note(`/${r.relativePathMovedFrom.join('/')}`, 's');
      }
      this.schedule();
    }

    note(path, kind) {
      if (this.pending.get(path) !== 's') this.pending.set(path, kind);
    }

    schedule() {
      if (this.flushTimer || this.stopped) return;
      this.flushTimer = setTimeout(() => { this.flushTimer = null; this.flush(); }, FLUSH_MS);
    }

    flush() {
      if (this.stopped || (!this.all && !this.pending.size)) return;
      const msg = this.all || this.pending.size > MAX_PATHS ? { type: 'changed', all: true } : { type: 'changed', paths: [...this.pending] };
      this.all = false;
      this.pending.clear();
      try { this.send(msg); } catch (e) { /* the link is gone; the server starts over when it comes back */ }
    }

    /** path → 'd' (folder) or 'size:time' (file), everything not excluded. */
    async walk() {
      const out = new Map();
      const visit = async (dir, prefix) => {
        const files = [];
        const dirs = [];
        for await (const [name, handle] of dir.entries()) {
          if (this.excludes.some((re) => re.test(name))) continue;
          if (handle.kind === 'directory') dirs.push([name, handle]); else files.push([name, handle]);
        }
        const sigs = await Promise.all(files.map(([, h]) => h.getFile().then((f) => `${f.size}:${f.lastModified}`, () => null)));
        files.forEach(([name], i) => { if (sigs[i]) out.set(`${prefix}/${name}`, sigs[i]); });
        for (const [name, h] of dirs) {
          out.set(`${prefix}/${name}`, 'd');
          await visit(h, `${prefix}/${name}`);
        }
      };
      await visit(this.root, '');
      return out;
    }

    async poll() {
      if (this.stopped) return;
      const t0 = Date.now();
      let now = null;
      try { now = await this.walk(); } catch (e) { this.all = true; }
      if (this.stopped) return;
      if (now && this.snapshot) {
        for (const [p, sig] of now) {
          const was = this.snapshot.get(p);
          if (was === undefined || (was === 'd') !== (sig === 'd')) this.note(p, 's');
          else if (was !== sig) this.note(p, 'm');
        }
        for (const p of this.snapshot.keys()) if (!now.has(p)) this.note(p, 's');
      }
      if (now) this.snapshot = now;
      this.flush();
      const took = Date.now() - t0;
      const wait = this.mode === 'poll'
        ? Math.min(POLL_MAX_MS, Math.max(this.pollMin, took * 10))
        : Math.min(SAFETY_MAX_MS, Math.max(this.safetyMin, took * 20));
      this.pollTimer = setTimeout(() => { this.pollTimer = null; void this.poll(); }, wait);
    }
  }

  // ---- the link ------------------------------------------------------------------------------

  const CLOSE_UNMOUNTED = 4001;
  const CLOSE_REPLACED = 4002;
  const CLOSE_REVOKED = 4007;
  const BACKOFF_S = [1, 2, 4, 8, 15, 30];

  /**
   * One folder shared from this page while the page is open: ticket → WebSocket → SFTP, reconnecting
   * by itself. `opts`: root (directory handle), name, readOnly, exclude, gitContext (Claude reads the
   * folder's git status when it starts; off = faster), prefetch (the server caches small files as soon
   * as it knows them), cacheId (the server keeps copies of fetched files on its disk under this id, across
   * connections; none = memory only), clientId, origin (http(s)://…), fetch (for the ticket; sends the
   * login cookie), onchange(state, detail). After connecting, `diskCache` says whether the server keeps them.
   * States: connecting · online · retrying · stopped · failed.
   */
  class Share {
    constructor(opts) {
      this.o = opts;
      this.state = 'stopped';
      this.detail = '';
      this.path = null;
      this.ws = null;
      this.sftp = null;
      this.stopped = false;
      this.attempt = 0;
      this.timer = null;
      this.watcher = null;
    }

    set(state, detail = '') {
      this.state = state;
      this.detail = detail;
      try { this.o.onchange && this.o.onchange(state, detail); } catch (e) { /* the page's problem */ }
    }

    start() {
      this.stopped = false;
      void this.connect();
    }

    stop(reason = 'stopped from this page') {
      this.stopped = true;
      clearTimeout(this.timer);
      if (this.ws) { try { this.ws.close(1000, reason); } catch (e) { /* closing */ } }
      this.cleanup();
      this.set('stopped');
    }

    cleanup() {
      clearInterval(this.watch);
      if (this.watcher) { this.watcher.stop(); this.watcher = null; }
      if (this.sftp) { void this.sftp.close(); this.sftp = null; }
      this.ws = null;
    }

    retry(why) {
      this.cleanup();
      if (this.stopped) return;
      const wait = BACKOFF_S[Math.min(this.attempt++, BACKOFF_S.length - 1)];
      this.set('retrying', `${why}；${wait} 秒后重连`);
      this.timer = setTimeout(() => { void this.connect(); }, wait * 1000);
    }

    async connect() {
      if (this.stopped) return;
      this.set('connecting');
      let t;
      try {
        const res = await this.o.fetch('/mounts/ticket', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ name: this.o.name, read_only: !!this.o.readOnly, git_context: !!this.o.gitContext, prefetch: !!this.o.prefetch, cache_id: this.o.cacheId || undefined, client_id: this.o.clientId, client: this.o.client || {} }),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          const msg = (data.error && data.error.message) || `HTTP ${res.status}`;
          // A 5xx that is not the bridge's own answer (no error code): a reverse proxy while the service restarts or
          // upgrades (nginx's 502 / 503 / 504 page). Temporary, like a network error: try again, backing off.
          if (res.status >= 500 && !(data.error && data.error.code)) return this.retry(`服务暂时不可用（HTTP ${res.status}，可能正在重启）`);
          if (res.status >= 500 && /shutting down/.test(msg)) return this.retry('服务正在重启');
          if (res.status === 401) { this.stopped = true; return this.set('failed', '登录已失效：重新登录后再共享'); }
          this.stopped = true;
          return this.set('failed', msg);
        }
        t = data;
      } catch (e) {
        return this.retry('连不上服务');
      }
      if (this.stopped) return;
      this.diskCache = !!t.disk_cache;
      const sftp = new BrowserSftp(this.o.root, { readOnly: this.o.readOnly, exclude: this.o.exclude, uid: t.uid, gid: t.gid });
      const ws = new WebSocket(`${this.o.origin.replace(/^http/i, 'ws')}${t.connect}`);
      ws.binaryType = 'arraybuffer';
      this.ws = ws;
      this.sftp = sftp;
      const split = new PacketSplitter();
      let last = Date.now();
      const silence = (Math.max(1, t.heartbeat_s || 15) * 2 + 10) * 1000;
      clearInterval(this.watch);
      this.watch = setInterval(() => {
        if (Date.now() - last > silence) { try { ws.close(4005, 'no answer from the server'); } catch (e) { /* closing */ } }
      }, 2000);
      ws.onopen = () => { last = Date.now(); this.attempt = 0; };
      ws.onmessage = (ev) => {
        last = Date.now();
        if (typeof ev.data === 'string') {
          let m;
          try { m = JSON.parse(ev.data); } catch (e) { return; }
          if (m.type === 'ping') ws.send(JSON.stringify({ type: 'pong', t: m.t }));
          else if (m.type === 'mounted') { this.path = m.path; this.set('online', m.path); }
          else if (m.type === 'watch' && !this.watcher && this.ws === ws) {
            // the server keeps a cache of this folder: tell it what changes here
            this.watcher = new Watcher(this.o.root, { exclude: this.o.exclude, pollMinMs: this.o.pollMinMs, send: (msg) => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg)); } });
            void this.watcher.start();
          }
          return;
        }
        let pkts;
        try { pkts = split.push(new Uint8Array(ev.data)); } catch (e) { try { ws.close(4006, 'bad data'); } catch (x) { /* closing */ } return; }
        for (const p of pkts) {
          void sftp.handle(p).then((reply) => { if (ws.readyState === WebSocket.OPEN) ws.send(reply); });
        }
      };
      ws.onclose = (ev) => {
        if (this.ws !== ws) return;
        if (ev.code === CLOSE_UNMOUNTED) { this.cleanup(); this.stopped = true; return this.set('stopped', '已在网页上断开'); }
        if (ev.code === CLOSE_REPLACED) { this.cleanup(); this.stopped = true; return this.set('stopped', '另一个页面接管了这个名字'); }
        if (ev.code === CLOSE_REVOKED) { this.cleanup(); this.stopped = true; return this.set('failed', ev.reason || '权限被收回'); }
        if (this.stopped) { this.cleanup(); return; }
        this.retry(ev.reason || '连接断开');
      };
    }
  }

  global.CabRemote = { BrowserSftp, PacketSplitter, Share, Watcher, FX };
})(typeof window !== 'undefined' ? window : globalThis);
